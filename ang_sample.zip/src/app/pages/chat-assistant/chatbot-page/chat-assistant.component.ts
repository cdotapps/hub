import { Component, OnInit, ViewChild, ElementRef, AfterViewChecked, ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { BreadcrumbComponent } from '../../../components/breadcrumb/breadcrumb.component';

interface ChatMessage {
  id: string;
  content: string;
  timestamp: Date;
  isUser: boolean;
  liked?: boolean;
  disliked?: boolean;
  sources?: Source[];
}

interface Source {
  title: string;
  url: string;
  relevance: number;
}

interface ChatHistory {
  id: string;
  title: string;
  date: Date;
  department: string;
  messageCount: number;
}

interface SavedLibrary {
  id: string;
  title: string;
  content: string;
  category: string;
  savedDate: Date;
}

@Component({
  selector: 'app-chat-assistant',
  standalone: true,
  imports: [CommonModule, FormsModule, BreadcrumbComponent],
  templateUrl: './chat-assistant.component.html',
  styleUrls: ['./chat-assistant.component.scss']
})
export class ChatAssistantComponent implements OnInit, AfterViewChecked {
  @ViewChild('chatArea') private chatArea!: ElementRef;
  @ViewChild('fileInput') private fileInput!: ElementRef;

  // Main state
  currentMessage = '';
  selectedDepartment = 'controllers'; // Default to Controllers
  chatMessages: ChatMessage[] = [];
  isTyping = false;
  searchQuery = '';

  // Attachment state
  attachedFile: File | null = null;

  // Sidebar state
  showHistory = true;
  showLibrary = false;
  selectedHistoryId = '';

  // Auto-scroll flag
  private shouldScrollToBottom = false;

  // Chat history and library
  chatHistories: ChatHistory[] = [
    {
      id: '1',
      title: 'Q4 Financial Planning Discussion',
      date: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000),
      department: 'FP&A',
      messageCount: 12
    },
    {
      id: '2',
      title: 'Tax Strategy for 2026',
      date: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000),
      department: 'Corporate Tax',
      messageCount: 8
    },
    {
      id: '3',
      title: 'M&A Valuation Models',
      date: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000),
      department: 'Corporate Finance',
      messageCount: 15
    }
  ];

  savedLibrary: SavedLibrary[] = [
    {
      id: '1',
      title: 'Financial Reporting Best Practices',
      content: 'Key points on GAAP compliance and statement preparation...',
      category: 'Controllers',
      savedDate: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000)
    },
    {
      id: '2',
      title: 'DCF Valuation Model Template',
      content: 'Complete template for building DCF models with sensitivity analysis...',
      category: 'Corporate Finance',
      savedDate: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000)
    },
    {
      id: '3',
      title: 'Tax Credit Documentation Guide',
      content: 'Documentation requirements for R&D tax credits and state incentives...',
      category: 'Corporate Tax',
      savedDate: new Date(Date.now() - 12 * 24 * 60 * 60 * 1000)
    }
  ];

  departments = [
    { id: 'controllers', name: 'Controllers' },
    { id: 'corp-finance', name: 'Corp Finance Management' },
    { id: 'corporate-tax', name: 'Corporate Tax' },
    { id: 'strategy-ir', name: 'Economics, Strategy & Investor Relations (ESIR)' },
    { id: 'modeling-analytics', name: 'Enterprise Modeling & Analytics' },
    { id: 'fp-a', name: 'Financial Planning & Analysis' },
    { id: 'sox-pmo', name: 'SOX & Risk Management (PMO)' }
  ];

  constructor(private router: Router, private cdr: ChangeDetectorRef) {}

  ngOnInit() {
    this.initializeChat();
  }

  ngAfterViewChecked() {
    if (this.shouldScrollToBottom) {
      this.scrollToBottom();
      this.shouldScrollToBottom = false;
    }
  }

  private scrollToBottom(): void {
    try {
      if (this.chatArea) {
        this.chatArea.nativeElement.scrollTop = this.chatArea.nativeElement.scrollHeight;
      }
    } catch (err) {
      console.error('Scroll error:', err);
    }
  }

  private initializeChat() {
    this.chatMessages = [
      {
        id: '1',
        content: 'Welcome to FinanceHub AI! I\'m here to help with comprehensive financial analysis, reporting, and strategic planning. You\'re currently connected to the Controllers department.',
        timestamp: new Date(),
        isUser: false,
        sources: []
      }
    ];
  }

  goBack() {
    this.router.navigate(['/']);
  }

  // Department change
  onDepartmentChange() {
    if (this.selectedDepartment) {
      const dept = this.departments.find(d => d.id === this.selectedDepartment);
      // Clear existing messages and start fresh
      this.chatMessages = [
        {
          id: Date.now().toString(),
          content: `Connected to ${dept?.name} department. How can I assist you?`,
          timestamp: new Date(),
          isUser: false,
          sources: []
        }
      ];
      this.shouldScrollToBottom = true;
    }
  }

  // Attachment methods
  triggerFileInput(): void {
    this.fileInput.nativeElement.click();
  }

  onFileSelected(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files.length > 0) {
      this.attachedFile = input.files[0];
      this.addMessage(`File attached: ${this.attachedFile.name}`, true);
    }
  }

  removeAttachment(): void {
    this.attachedFile = null;
    if (this.fileInput) {
      this.fileInput.nativeElement.value = '';
    }
  }

  // Keyboard handling
  handleKeydown(event: KeyboardEvent): void {
    if (event.key === 'Enter' && !event.shiftKey) {
      event.preventDefault();
      this.sendMessage();
    }
  }

  // Message handling
  sendMessage() {
    if (this.currentMessage.trim() || this.attachedFile) {
      let messageContent = this.currentMessage;
      if (this.attachedFile) {
        messageContent += `\n[Attached: ${this.attachedFile.name}]`;
      }
      
      this.addMessage(messageContent, true);
      this.processAIResponse(this.currentMessage);
      
      this.currentMessage = '';
      this.removeAttachment();
    }
  }

  private addMessage(content: string, isUser: boolean, sources: Source[] = []) {
    this.chatMessages.push({
      id: Date.now().toString(),
      content,
      timestamp: new Date(),
      isUser,
      sources
    });

    this.shouldScrollToBottom = true;
  }

  private processAIResponse(userMessage: string) {
    this.isTyping = true;

    setTimeout(() => {
      this.isTyping = false;
      let response = '';
      const sources: Source[] = [];

      if (!this.selectedDepartment) {
        response = 'Please select a department first for more targeted assistance.';
      } else {
        response = this.generateDetailedResponse(userMessage);
        sources.push(
          { title: 'Financial Analysis Guide', url: '#', relevance: 95 },
          { title: 'Reporting Standards', url: '#', relevance: 87 },
          { title: 'Industry Best Practices', url: '#', relevance: 78 }
        );
      }

      this.addMessage(response, false, sources);
      this.cdr.detectChanges(); // Trigger change detection
    }, 1200);
  }

  private generateDetailedResponse(message: string): string {
    const lowerMessage = message.toLowerCase();
    const dept = this.departments.find(d => d.id === this.selectedDepartment)?.name;

    if (lowerMessage.includes('help') || lowerMessage.includes('what')) {
      return `I can provide comprehensive assistance with ${dept} activities including analysis, reporting, planning, and automation. Feel free to ask specific questions about financial metrics, strategies, or methodologies. You can save important responses to your library, copy content, and explore related sources.`;
    }

    if (lowerMessage.includes('report') || lowerMessage.includes('statement')) {
      return `For ${dept}, I can help generate detailed reports with multiple visualization options, comparative analysis, and insights. The reports can be exported, shared, and include comprehensive source documentation and compliance certifications.`;
    }

    if (lowerMessage.includes('forecast') || lowerMessage.includes('model')) {
      return `I can build comprehensive ${dept} models with scenario analysis, sensitivity testing, and what-if simulations. These models integrate with your existing data sources and provide real-time updates with detailed supporting documentation.`;
    }

    if (lowerMessage.includes('save') || lowerMessage.includes('library')) {
      return `You can save important conversations and responses to your personal library. Organize them by category, add custom tags, and search across all saved items. Access your library anytime to reference or build upon previous analysis.`;
    }

    return `I'm ready to assist with ${dept} tasks. Specific questions yield better results - feel free to ask about metrics, methodologies, strategies, or specific scenarios you're working on.`;
  }

  // Message reactions
  likeMessage(message: ChatMessage) {
    if (!message.isUser) {
      message.liked = !message.liked;
      if (message.liked) {
        message.disliked = false;
      }
    }
  }

  dislikeMessage(message: ChatMessage) {
    if (!message.isUser) {
      message.disliked = !message.disliked;
      if (message.disliked) {
        message.liked = false;
      }
    }
  }

  // Copy functionality
  copyMessage(content: string) {
    navigator.clipboard.writeText(content).then(() => {
      // alert('Copied to clipboard!');
    });
  }

  // Search functionality
  searchMessages(): ChatMessage[] {
    if (!this.searchQuery.trim()) {
      return this.chatMessages;
    }
    const query = this.searchQuery.toLowerCase();
    return this.chatMessages.filter(msg =>
      msg.content.toLowerCase().includes(query)
    );
  }

  // History management
  loadHistory(history: ChatHistory) {
    this.selectedHistoryId = history.id;
    this.addMessage(`Loaded conversation: ${history.title}`, false);
  }

  deleteHistory(id: string) {
    this.chatHistories = this.chatHistories.filter(h => h.id !== id);
    if (this.selectedHistoryId === id) {
      this.selectedHistoryId = '';
    }
  }

  newChat() {
    this.chatMessages = [
      {
        id: '1',
        content: 'New conversation started. Select a department to begin.',
        timestamp: new Date(),
        isUser: false
      }
    ];
    this.selectedDepartment = '';
    this.searchQuery = '';
    this.selectedHistoryId = '';
  }

  // Library management
  saveToLibrary(message: ChatMessage) {
    const newItem: SavedLibrary = {
      id: Date.now().toString(),
      title: `Saved: ${message.content.substring(0, 50)}...`,
      content: message.content,
      category: this.departments.find(d => d.id === this.selectedDepartment)?.name || 'General',
      savedDate: new Date()
    };
    this.savedLibrary.unshift(newItem);
    alert('Added to library!');
  }

  deleteFromLibrary(id: string) {
    this.savedLibrary = this.savedLibrary.filter(item => item.id !== id);
  }

  loadFromLibrary(item: SavedLibrary) {
    this.addMessage(`Loaded from library: ${item.title}\n\n${item.content}`, false);
  }

  // Export functionality
  exportChat() {
    const content = this.chatMessages.map(m =>
      `${m.isUser ? 'You' : 'AI'}: ${m.content}`
    ).join('\n\n');

    const element = document.createElement('a');
    element.setAttribute('href', 'data:text/plain;charset=utf-8,' + encodeURIComponent(content));
    element.setAttribute('download', `chat-${new Date().toISOString()}.txt`);
    element.style.display = 'none';
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
  }

  // Filter library
  getFilteredLibrary(): SavedLibrary[] {
    if (!this.searchQuery.trim()) {
      return this.savedLibrary;
    }
    const query = this.searchQuery.toLowerCase();
    return this.savedLibrary.filter(item =>
      item.title.toLowerCase().includes(query) ||
      item.content.toLowerCase().includes(query) ||
      item.category.toLowerCase().includes(query)
    );
  }
}

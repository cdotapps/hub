import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { BreadcrumbComponent } from '../../components/breadcrumb/breadcrumb.component';

export interface Notification {
  id: string;
  title: string;
  message: string;
  type: 'info' | 'success' | 'warning' | 'error';
  timestamp: Date;
  read: boolean;
  icon?: string;
  category?: string;
  actionUrl?: string;
}

export interface NotificationFilter {
  type?: string;
  category?: string;
  read?: boolean;
  dateRange?: 'today' | 'week' | 'month' | 'all';
}

@Component({
  selector: 'app-notifications-page',
  standalone: true,
  imports: [CommonModule, FormsModule, BreadcrumbComponent],
  templateUrl: './notifications-page.component.html',
  styleUrls: ['./notifications-page.component.scss']
})
export class NotificationsPageComponent implements OnInit {
  notifications: Notification[] = [
    {
      id: '1',
      title: 'New Message from Chat Assistant',
      message: 'You have received a new response from the AI assistant regarding your financial query about Q4 projections.',
      type: 'info',
      timestamp: new Date(Date.now() - 1000 * 60 * 5),
      read: false,
      category: 'Chat',
      actionUrl: '/chat-assistant'
    },
    {
      id: '2',
      title: 'Financial Report Generated',
      message: 'Your Q4 2025 financial report has been successfully generated and is ready for review.',
      type: 'success',
      timestamp: new Date(Date.now() - 1000 * 60 * 30),
      read: false,
      category: 'Reports'
    },
    {
      id: '3',
      title: 'Action Required: Pending Transactions',
      message: 'There are 5 pending transactions that require your immediate attention and approval.',
      type: 'warning',
      timestamp: new Date(Date.now() - 1000 * 60 * 60 * 2),
      read: true,
      category: 'Transactions',
      actionUrl: '/dashboard'
    },
    {
      id: '4',
      title: 'System Maintenance Scheduled',
      message: 'Scheduled system maintenance will occur tonight from 2:00 AM to 4:00 AM EST.',
      type: 'info',
      timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24),
      read: true,
      category: 'System'
    },
    {
      id: '5',
      title: 'Security Alert',
      message: 'A new device has been detected logging into your account. Please verify if this was you.',
      type: 'error',
      timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24 * 2),
      read: false,
      category: 'Security',
      actionUrl: '/settings'
    },
    {
      id: '6',
      title: 'Monthly Report Available',
      message: 'Your monthly financial summary for December 2025 is now available for download.',
      type: 'success',
      timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24 * 3),
      read: true,
      category: 'Reports'
    },
    {
      id: '7',
      title: 'Budget Threshold Alert',
      message: 'Your marketing department budget has exceeded 90% of the allocated amount.',
      type: 'warning',
      timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24 * 5),
      read: true,
      category: 'Budget'
    },
    {
      id: '8',
      title: 'New Feature Available',
      message: 'Enhanced AI chat capabilities are now available. Try the new financial forecasting feature.',
      type: 'info',
      timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24 * 7),
      read: true,
      category: 'Features'
    }
  ];

  filteredNotifications: Notification[] = [];
  searchQuery = '';
  selectedFilter: NotificationFilter = { dateRange: 'all' };
  showFilters = false;
  selectedNotifications: string[] = [];

  notificationTypes = [
    { value: '', label: 'All Types' },
    { value: 'info', label: 'Information' },
    { value: 'success', label: 'Success' },
    { value: 'warning', label: 'Warning' },
    { value: 'error', label: 'Error' }
  ];

  notificationCategories = [
    { value: '', label: 'All Categories' },
    { value: 'Chat', label: 'Chat' },
    { value: 'Reports', label: 'Reports' },
    { value: 'Transactions', label: 'Transactions' },
    { value: 'System', label: 'System' },
    { value: 'Security', label: 'Security' },
    { value: 'Budget', label: 'Budget' },
    { value: 'Features', label: 'Features' }
  ];

  constructor(private router: Router) {}

  ngOnInit() {
    this.applyFilters();
  }

  get unreadCount(): number {
    return this.notifications.filter(n => !n.read).length;
  }

  get selectedCount(): number {
    return this.selectedNotifications.length;
  }

  applyFilters() {
    let filtered = [...this.notifications];

    // Apply search filter
    if (this.searchQuery.trim()) {
      const query = this.searchQuery.toLowerCase();
      filtered = filtered.filter(n => 
        n.title.toLowerCase().includes(query) || 
        n.message.toLowerCase().includes(query) ||
        (n.category && n.category.toLowerCase().includes(query))
      );
    }

    // Apply type filter
    if (this.selectedFilter.type) {
      filtered = filtered.filter(n => n.type === this.selectedFilter.type);
    }

    // Apply category filter
    if (this.selectedFilter.category) {
      filtered = filtered.filter(n => n.category === this.selectedFilter.category);
    }

    // Apply read status filter
    if (this.selectedFilter.read !== undefined) {
      filtered = filtered.filter(n => n.read === this.selectedFilter.read);
    }

    // Apply date range filter
    if (this.selectedFilter.dateRange && this.selectedFilter.dateRange !== 'all') {
      const now = new Date();
      const cutoff = new Date();
      
      switch (this.selectedFilter.dateRange) {
        case 'today':
          cutoff.setHours(0, 0, 0, 0);
          break;
        case 'week':
          cutoff.setDate(now.getDate() - 7);
          break;
        case 'month':
          cutoff.setDate(now.getDate() - 30);
          break;
      }
      
      filtered = filtered.filter(n => n.timestamp >= cutoff);
    }

    // Sort by timestamp (newest first)
    filtered.sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime());

    this.filteredNotifications = filtered;
  }

  onSearchChange() {
    this.applyFilters();
  }

  onFilterChange() {
    this.applyFilters();
  }

  toggleFilters() {
    this.showFilters = !this.showFilters;
  }

  clearFilters() {
    this.selectedFilter = { dateRange: 'all' };
    this.searchQuery = '';
    this.applyFilters();
  }

  markAsRead(notification: Notification) {
    notification.read = true;
    this.applyFilters();
  }

  markAllAsRead() {
    this.notifications.forEach(n => n.read = true);
    this.applyFilters();
  }

  markSelectedAsRead() {
    this.notifications.forEach(n => {
      if (this.selectedNotifications.includes(n.id)) {
        n.read = true;
      }
    });
    this.selectedNotifications = [];
    this.applyFilters();
  }

  deleteNotification(id: string, event?: Event) {
    if (event) event.stopPropagation();
    this.notifications = this.notifications.filter(n => n.id !== id);
    this.selectedNotifications = this.selectedNotifications.filter(nId => nId !== id);
    this.applyFilters();
  }

  deleteSelected() {
    this.notifications = this.notifications.filter(n => !this.selectedNotifications.includes(n.id));
    this.selectedNotifications = [];
    this.applyFilters();
  }

  toggleSelectAll() {
    if (this.selectedNotifications.length === this.filteredNotifications.length) {
      this.selectedNotifications = [];
    } else {
      this.selectedNotifications = this.filteredNotifications.map(n => n.id);
    }
  }

  toggleSelectNotification(id: string) {
    const index = this.selectedNotifications.indexOf(id);
    if (index > -1) {
      this.selectedNotifications.splice(index, 1);
    } else {
      this.selectedNotifications.push(id);
    }
  }

  isSelected(id: string): boolean {
    return this.selectedNotifications.includes(id);
  }

  handleNotificationClick(notification: Notification) {
    this.markAsRead(notification);
    if (notification.actionUrl) {
      this.router.navigate([notification.actionUrl]);
    }
  }

  getRelativeTime(date: Date): string {
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(minutes / 60);
    const days = Math.floor(hours / 24);

    if (minutes < 1) return 'Just now';
    if (minutes < 60) return `${minutes}m ago`;
    if (hours < 24) return `${hours}h ago`;
    if (days < 7) return `${days}d ago`;
    return date.toLocaleDateString();
  }

  getNotificationIcon(type: string): string {
    switch (type) {
      case 'success': return '✓';
      case 'warning': return '⚠';
      case 'error': return '✕';
      default: return 'i';
    }
  }

  goBack() {
    this.router.navigate(['/dashboard']);
  }

  trackByNotificationId(index: number, notification: Notification): string {
    return notification.id;
  }
}
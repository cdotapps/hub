import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { NewsTicker, NewsTickerItem } from '../../components/news-ticker/news-ticker';
import { ChatbotComponent } from '../../components/chatbot/chatbot.component';

interface NewsItem {
  title: string;
  description: string;
  date: string;
}

interface WeeklyWin {
  title: string;
  metric: string;
  icon: string;
}

interface Initiative {
  title: string;
  status: string;
  progress: number;
}

interface TickerNewsItem {
  text: string;
  urgent?: boolean;
}

interface Department {
  id: string;
  name: string;
  description: string;
}

interface AgentOption {
  id: string;
  label: string;
  description: string;
}

interface QuickAction {
  label: string;
  message: string;
}

interface ChatMessage {
  content: string;
  timestamp: Date;
  isUser: boolean;
}

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [CommonModule, NewsTicker, ChatbotComponent],
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {
  newsList = [
    { id: 1, title: 'Market Trends 2026', description: 'Analyzing the latest financial market trends and opportunities.', date: '2026-01-24' },
    { id: 2, title: 'Investment Strategies', description: 'Smart strategies for maximizing your investment returns.', date: '2026-01-23' },
    { id: 3, title: 'Economic Forecast', description: 'Expert predictions for the upcoming quarter.', date: '2026-01-22' }
  ];

  weeklyWins = [
    { id: 1, title: 'Portfolio Growth', metric: '+12.5%', icon: 'chart' },
    { id: 2, title: 'New Clients', metric: '47', icon: 'users' },
    { id: 3, title: 'Revenue Increase', metric: '+$25K', icon: 'dollar' }
  ];

  initiatives = [
    { id: 1, title: 'Digital Banking Launch', status: 'In Progress', progress: 75 },
    { id: 2, title: 'AI Risk Assessment', status: 'Planning', progress: 30 },
    { id: 3, title: 'Customer Portal Update', status: 'In Progress', progress: 60 }
  ];

  tickerNews: NewsTickerItem[] = [
    { text: 'Q4 2025 earnings exceed expectations by 15% - Record-breaking quarter for FinanceHub', id: 1 },
    { text: 'New AI-powered investment tools launching next week - Enhanced portfolio management', id: 2 },
    { text: 'Partnership announced with major global banks - Expanding international reach', id: 3 },
    { text: 'Customer satisfaction rating reaches all-time high of 98%', id: 4 },
    { text: 'Mobile app downloads surpass 1 million milestone - Growing digital presence', id: 5 },
    { text: 'Introducing zero-fee trading for premium members - More value for customers', id: 6 }
  ];

  showChatbot = false;
  selectedDepartment = '';
  selectedAgentOption = '';
  currentMessage = '';
  chatMessages: ChatMessage[] = [];

  departments: Department[] = [
    {
      id: 'controllers',
      name: 'Controllers',
      description: 'Financial reporting and accounting oversight'
    },
    {
      id: 'corp-finance',
      name: 'Corporate Finance',
      description: 'Capital structure and strategic finance'
    },
    {
      id: 'corporate-tax',
      name: 'Corporate Tax',
      description: 'Tax compliance and strategic planning'
    },
    {
      id: 'strategy-ir',
      name: 'Strategy & Investor Relations',
      description: 'Strategic planning and investor communications'
    },
    {
      id: 'modeling-analytics',
      name: 'Enterprise Modeling & Analytics',
      description: 'Data modeling and business intelligence'
    },
    {
      id: 'fp-a',
      name: 'Financial Planning & Analysis',
      description: 'Budgeting, forecasting, and analysis'
    },
    {
      id: 'sox-pmo',
      name: 'SOX & Risk Management',
      description: 'Compliance and risk controls'
    },
    {
      id: 'treasury',
      name: 'Treasury Operations',
      description: 'Cash management and liquidity planning'
    },
    {
      id: 'technology',
      name: 'Technology',
      description: 'IT infrastructure and digital solutions'
    }
  ];

  private agentOptions: { [key: string]: AgentOption[] } = {
    'controllers': [
      { id: 'financial-reports', label: 'Financial Reports', description: 'Generate and analyze financial statements' },
      { id: 'compliance-check', label: 'Compliance Check', description: 'Review regulatory compliance status' },
      { id: 'audit-prep', label: 'Audit Preparation', description: 'Prepare documentation for audits' },
      { id: 'month-end-close', label: 'Month-End Close', description: 'Streamline closing procedures' }
    ],
    'corp-finance': [
      { id: 'capital-analysis', label: 'Capital Analysis', description: 'Analyze capital structure options' },
      { id: 'investment-eval', label: 'Investment Evaluation', description: 'Assess investment opportunities' },
      { id: 'valuation-models', label: 'Valuation Models', description: 'Build financial valuation models' },
      { id: 'merger-analysis', label: 'M&A Analysis', description: 'Evaluate merger & acquisition deals' }
    ],
    'corporate-tax': [
      { id: 'tax-planning', label: 'Tax Planning', description: 'Strategic tax optimization' },
      { id: 'compliance-filing', label: 'Filing Compliance', description: 'Automated tax filing assistance' },
      { id: 'transfer-pricing', label: 'Transfer Pricing', description: 'Inter-company pricing analysis' },
      { id: 'tax-provision', label: 'Tax Provision', description: 'Calculate tax provisions' }
    ],
    'strategy-ir': [
      { id: 'market-research', label: 'Market Research', description: 'Industry and competitive analysis' },
      { id: 'investor-materials', label: 'Investor Materials', description: 'Create presentation materials' },
      { id: 'scenario-planning', label: 'Scenario Planning', description: 'Strategic scenario modeling' },
      { id: 'peer-benchmarking', label: 'Peer Benchmarking', description: 'Compare against industry peers' }
    ],
    'modeling-analytics': [
      { id: 'predictive-models', label: 'Predictive Models', description: 'Build forecasting models' },
      { id: 'data-visualization', label: 'Data Visualization', description: 'Create interactive dashboards' },
      { id: 'trend-analysis', label: 'Trend Analysis', description: 'Identify business trends' },
      { id: 'risk-modeling', label: 'Risk Modeling', description: 'Quantify business risks' }
    ],
    'fp-a': [
      { id: 'budget-planning', label: 'Budget Planning', description: 'Annual budget preparation' },
      { id: 'variance-analysis', label: 'Variance Analysis', description: 'Compare actual vs. planned' },
      { id: 'forecast-models', label: 'Forecast Models', description: 'Build financial forecasts' },
      { id: 'kpi-dashboard', label: 'KPI Dashboard', description: 'Monitor key metrics' }
    ],
    'sox-pmo': [
      { id: 'control-testing', label: 'Control Testing', description: 'Test internal controls' },
      { id: 'risk-assessment', label: 'Risk Assessment', description: 'Evaluate business risks' },
      { id: 'documentation', label: 'Documentation', description: 'Maintain compliance docs' },
      { id: 'remediation', label: 'Remediation', description: 'Fix control deficiencies' }
    ],
    'treasury': [
      { id: 'cash-forecast', label: 'Cash Forecasting', description: 'Predict cash flows' },
      { id: 'liquidity-analysis', label: 'Liquidity Analysis', description: 'Monitor cash positions' },
      { id: 'fx-hedging', label: 'FX Hedging', description: 'Foreign exchange risk management' },
      { id: 'investment-tracking', label: 'Investment Tracking', description: 'Monitor investment portfolio' }
    ],
    'technology': [
      { id: 'system-integration', label: 'System Integration', description: 'Connect financial systems' },
      { id: 'automation-setup', label: 'Process Automation', description: 'Automate manual processes' },
      { id: 'data-migration', label: 'Data Migration', description: 'Migrate to new systems' },
      { id: 'security-review', label: 'Security Review', description: 'Assess system security' }
    ]
  };

  private quickActions: { [key: string]: QuickAction[] } = {
    'controllers': [
      { label: 'Generate P&L', message: 'Generate profit and loss statement for current period' },
      { label: 'Balance Sheet', message: 'Create balance sheet with current data' },
      { label: 'Cash Flow', message: 'Generate cash flow statement' }
    ],
    'corp-finance': [
      { label: 'DCF Model', message: 'Build discounted cash flow model' },
      { label: 'ROI Analysis', message: 'Calculate return on investment' },
      { label: 'Capital Structure', message: 'Analyze optimal capital structure' }
    ],
    'corporate-tax': [
      { label: 'Tax Estimate', message: 'Calculate current tax liability' },
      { label: 'Deduction Review', message: 'Review available tax deductions' },
      { label: 'Credits Analysis', message: 'Analyze applicable tax credits' }
    ],
    'strategy-ir': [
      { label: 'Market Size', message: 'Calculate addressable market size' },
      { label: 'Competitive Analysis', message: 'Analyze competitive landscape' },
      { label: 'Growth Scenarios', message: 'Model growth scenarios' }
    ],
    'modeling-analytics': [
      { label: 'Trend Forecast', message: 'Forecast business trends' },
      { label: 'Regression Model', message: 'Build regression analysis model' },
      { label: 'Data Insights', message: 'Extract key data insights' }
    ],
    'fp-a': [
      { label: 'Monthly Forecast', message: 'Update monthly financial forecast' },
      { label: 'Budget vs Actual', message: 'Compare budget to actual performance' },
      { label: 'Expense Analysis', message: 'Analyze expense categories' }
    ],
    'sox-pmo': [
      { label: 'Control Matrix', message: 'Create control testing matrix' },
      { label: 'Risk Register', message: 'Update risk register' },
      { label: 'Deficiency Report', message: 'Generate deficiency report' }
    ],
    'treasury': [
      { label: '13-Week Cash', message: 'Generate 13-week cash forecast' },
      { label: 'Bank Reconciliation', message: 'Reconcile bank accounts' },
      { label: 'Investment Summary', message: 'Summarize investment positions' }
    ],
    'technology': [
      { label: 'API Status', message: 'Check system API status' },
      { label: 'Data Quality', message: 'Run data quality checks' },
      { label: 'Performance Monitor', message: 'Monitor system performance' }
    ]
  };

  constructor(private router: Router) {}

  toggleChatbot() {
    // Navigate to chat assistant instead of showing popup
    this.router.navigate(['/chat-assistant']);
  }

  onChatbotVisibilityChange(isVisible: boolean) {
    this.showChatbot = isVisible;
  }

  ngOnInit() {
    // Component initialization logic
  }
}

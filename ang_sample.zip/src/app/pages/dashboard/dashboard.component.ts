import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BreadcrumbComponent } from '../../components/breadcrumb/breadcrumb.component';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule, BreadcrumbComponent],
  templateUrl: './dashboard.component.html',
  styleUrl: './dashboard.component.scss'
})
export class DashboardComponent {
  stats = [
    { title: 'Total Revenue', value: '$125,430', change: '+12.5%', positive: true },
    { title: 'Active Users', value: '8,542', change: '+8.2%', positive: true },
    { title: 'Pending Tasks', value: '24', change: '-15%', positive: false },
    { title: 'Conversion Rate', value: '3.24%', change: '+2.1%', positive: true }
  ];

  recentActivity = [
    { action: 'New transaction processed', time: '5 minutes ago', type: 'success' },
    { action: 'Report generated', time: '1 hour ago', type: 'info' },
    { action: 'User registered', time: '2 hours ago', type: 'success' },
    { action: 'System update completed', time: '3 hours ago', type: 'info' }
  ];

  quickActions = [
    { title: 'Generate Report', icon: 'document', color: '#2563eb' },
    { title: 'Add Transaction', icon: 'plus', color: '#10b981' },
    { title: 'View Analytics', icon: 'chart', color: '#f59e0b' },
    { title: 'Manage Users', icon: 'users', color: '#8b5cf6' }
  ];
}

import { Component, HostListener } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';

interface MenuItem {
  title: string;
  icon: string;
  items: SubMenuItem[];
}

interface SubMenuItem {
  title: string;
  description: string;
  link: string;
}

@Component({
  selector: 'app-mega-menu',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './mega-menu.html',
  styleUrl: './mega-menu.scss',
})
export class MegaMenu {
  activeMenu: string | null = null;
  private hideTimeout: any;

  menuItems: MenuItem[] = [
    {
      title: 'Departments',
      icon: 'M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-5 14H7v-5h2v3h3v2zm2-6H8V8h8v3zm2 6h-2v-2h2v2z',
      items: [
        { title: 'Controllers', description: 'Financial reporting and accounting oversight', link: '/departments/controllers' },
        { title: 'Corp Finance Management', description: 'Capital structure and strategic finance', link: '/departments/corp-finance' },
        { title: 'Corporate Tax', description: 'Tax compliance and strategic tax planning', link: '/departments/corporate-tax' },
        { title: 'Economics, Strategy & Investor Relations (ESIR)', description: 'Economics, Strategic planning and investor communications', link: '/departments/strategy-ir' },
        { title: 'Enterprise Modeling & Analytics', description: 'Data modeling and business intelligence', link: '/departments/modeling-analytics' },
        { title: 'Financial Planning & Analysis', description: 'Budgeting, forecasting, and financial analysis', link: '/departments/fp-a' },
        { title: 'SOX & Risk Management (PMO)', description: 'Sarbanes-Oxley compliance and controls', link: '/departments/sox-pmo' },
      ]
    },
    {
      title: 'Technology',
      icon: 'M20.5 6c-2.61.7-5.67 1-8.5 1s-5.89-.3-8.5-1L3 8c0 .55.45 1 1 1h1v5c0 .55.45 1 1 1s1-.45 1-1V9h2v5c0 .55.45 1 1 1s1-.45 1-1V9h2v5c0 .55.45 1 1 1s1-.45 1-1V9h2v5c0 .55.45 1 1 1s1-.45 1-1V9h1c.55 0 1-.45 1-1l-.5-2z',
      items: [
        { title: 'Cloud Infrastructure', description: 'Modern cloud solutions and architecture', link: '/technology/cloud' },
        { title: 'Data Analytics Platform', description: 'Advanced analytics and business intelligence', link: '/technology/analytics' },
        { title: 'Cybersecurity', description: 'Enterprise security and threat protection', link: '/technology/security' },
        { title: 'API Management', description: 'Secure and scalable API infrastructure', link: '/technology/apis' },
        { title: 'DevOps & Automation', description: 'Continuous integration and deployment', link: '/technology/devops' },
        { title: 'Mobile Applications', description: 'Cross-platform mobile solutions', link: '/technology/mobile' },
        { title: 'AI & Machine Learning', description: 'Intelligent automation and insights', link: '/technology/ai-ml' },
        { title: 'Blockchain Solutions', description: 'Distributed ledger and smart contracts', link: '/technology/blockchain' }
      ]
    },
    {
      title: 'Resources',
      icon: 'M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zM9 17H7v-7h2v7zm4 0h-2V7h2v10zm4 0h-2v-4h2v4z',
      items: [
        { title: 'Financial Education', description: 'Comprehensive learning resources', link: '/resources/education' },
        { title: 'Market Research', description: 'Industry insights and market analysis', link: '/resources/research' },
        { title: 'Calculators & Tools', description: 'Interactive financial planning tools', link: '/resources/calculators' },
        { title: 'Documentation Hub', description: 'Complete technical documentation', link: '/resources/docs' },
        { title: 'Training Center', description: 'Professional development programs', link: '/resources/training' },
        { title: 'Blog & Insights', description: 'Latest trends and expert insights', link: '/resources/blog' },
        { title: 'Downloads', description: 'Forms, templates, and resources', link: '/resources/downloads' },
        { title: 'Support Center', description: '24/7 help and customer support', link: '/resources/support' }
      ]
    },
    {
      title: 'About',
      icon: 'M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-6h2v6zm0-8h-2V7h2v2z',
      items: [
        { title: 'Our Story', description: 'Mission, vision, and company heritage', link: '/about/story' },
        { title: 'Leadership Team', description: 'Executive leadership and board', link: '/about/team' },
        { title: 'Global Offices', description: 'Worldwide presence and locations', link: '/about/locations' },
        { title: 'Careers', description: 'Join our innovative team', link: '/about/careers' },
        { title: 'Awards & Recognition', description: 'Industry achievements and honors', link: '/about/awards' },
        { title: 'Press & Media', description: 'News, press releases, and media kit', link: '/about/press' },
        { title: 'Investor Relations', description: 'Financial reports and investor info', link: '/about/investors' },
        { title: 'Contact Us', description: 'Get in touch with our team', link: '/about/contact' }
      ]
    }
  ];

  @HostListener('document:click', ['$event'])
  onDocumentClick(event: MouseEvent) {
    const target = event.target as HTMLElement;
    const megaMenuContainer = target.closest('.mega-menu-container');
    
    if (!megaMenuContainer && this.activeMenu) {
      this.closeMenu();
    }
  }

  showMenu(menuTitle: string) {
    if (this.hideTimeout) {
      clearTimeout(this.hideTimeout);
    }
    this.activeMenu = menuTitle;
  }

  hideMenu() {
    this.hideTimeout = setTimeout(() => {
      this.activeMenu = null;
    }, 200);
  }

  cancelHide() {
    if (this.hideTimeout) {
      clearTimeout(this.hideTimeout);
    }
  }

  closeMenu() {
    if (this.hideTimeout) {
      clearTimeout(this.hideTimeout);
    }
    this.activeMenu = null;
  }
}

import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';

export interface NewsTickerItem {
  text: string;
  id?: number;
}

@Component({
  selector: 'app-news-ticker',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './news-ticker.html',
  styleUrl: './news-ticker.scss',
})
export class NewsTicker {
  @Input() items: NewsTickerItem[] = [];
  @Input() direction: 'horizontal' | 'vertical' = 'horizontal';
  @Input() speed: number = 60; // Animation duration in seconds
  @Input() pauseOnHover: boolean = true;
  @Input() showLabel: boolean = true;
  @Input() label: string = 'LATEST';
  @Input() labelIcon: boolean = true;
  @Input() height: string = '50px'; // For horizontal mode
}

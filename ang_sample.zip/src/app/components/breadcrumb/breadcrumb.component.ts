import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, NavigationEnd, RouterModule, ActivatedRoute } from '@angular/router';
import { filter } from 'rxjs/operators';

interface Breadcrumb {
  label: string;
  url: string;
  icon?: string;
}

@Component({
  selector: 'app-breadcrumb',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './breadcrumb.component.html',
  styleUrl: './breadcrumb.component.scss',
})
export class BreadcrumbComponent implements OnInit {
  breadcrumbs: Breadcrumb[] = [];

  constructor(
    private router: Router,
    private activatedRoute: ActivatedRoute
  ) {}

  ngOnInit() {
    this.router.events
      .pipe(filter((event) => event instanceof NavigationEnd))
      .subscribe(() => {
        this.breadcrumbs = this.createBreadcrumbs(this.activatedRoute.root);
      });
    
    // Initialize breadcrumbs on load
    this.breadcrumbs = this.createBreadcrumbs(this.activatedRoute.root);
  }

  private createBreadcrumbs(
    route: ActivatedRoute,
    url: string = '',
    breadcrumbs: Breadcrumb[] = []
  ): Breadcrumb[] {
    // Always add home as the first breadcrumb
    if (breadcrumbs.length === 0) {
      breadcrumbs.push({
        label: 'Home',
        url: '/',
        icon: 'M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z'
      });
    }

    const children: ActivatedRoute[] = route.children;

    if (children.length === 0) {
      return breadcrumbs;
    }

    for (const child of children) {
      const routeURL: string = child.snapshot.url
        .map((segment) => segment.path)
        .join('/');
      
      if (routeURL !== '') {
        url += `/${routeURL}`;
        
        // Create a readable label from the URL
        const label = this.formatLabel(routeURL);
        
        breadcrumbs.push({
          label,
          url
        });
      }

      return this.createBreadcrumbs(child, url, breadcrumbs);
    }

    return breadcrumbs;
  }

  private formatLabel(url: string): string {
    // Convert URL segments to readable labels
    const labelMap: { [key: string]: string } = {
      'dashboard': 'Dashboard',
      'products': 'Products',
      'checking': 'Checking Accounts',
      'savings': 'Savings Accounts',
      'credit-cards': 'Credit Cards',
      'loans': 'Loans',
      'services': 'Services',
      'investments': 'Investment Services',
      'insurance': 'Insurance',
      'wealth': 'Wealth Management',
      'business': 'Business Banking',
      'resources': 'Resources',
      'education': 'Financial Education',
      'calculators': 'Calculators',
      'blog': 'Blog',
      'support': 'Support Center',
      'about': 'About',
      'story': 'Our Story',
      'team': 'Leadership Team',
      'careers': 'Careers',
      'contact': 'Contact Us'
    };

    return labelMap[url] || url.charAt(0).toUpperCase() + url.slice(1).replace(/-/g, ' ');
  }
}

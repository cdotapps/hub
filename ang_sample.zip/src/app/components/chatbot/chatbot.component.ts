import { Component, OnInit, Input, Output, EventEmitter, ViewChild, ElementRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';

interface Department {
  id: string;
  name: string;
}

interface ChatMessage {
  id: string;
  content: string;
  timestamp: Date;
  isUser: boolean;
  sources?: string[];
  hasContext?: boolean;
  hasAttachment?: boolean;
}

@Component({
  selector: 'app-chatbot',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './chatbot.component.html',
  styleUrls: ['./chatbot.component.scss']
})
export class ChatbotComponent implements OnInit {
  @Input() isVisible = false;
  @Output() visibilityChange = new EventEmitter<boolean>();
  @ViewChild('fileInput') fileInput!: ElementRef;

  selectedDepartment = '';
  currentMessage = '';
  chatMessages: ChatMessage[] = [];
  isTyping = false;
  includeContext = false;
  attachedFile: File | null = null;

  departments: Department[] = [
    { id: 'controllers', name: 'Controllers' },
    { id: 'corp-finance', name: 'Corporate Finance' },
    { id: 'corporate-tax', name: 'Corporate Tax' },
    { id: 'strategy-ir', name: 'Strategy & IR' },
    { id: 'modeling-analytics', name: 'Analytics' },
    { id: 'fp-a', name: 'FP&A' },
    { id: 'sox-pmo', name: 'SOX & Risk' },
    { id: 'treasury', name: 'Treasury' },
    { id: 'technology', name: 'Technology' }
  ];

  constructor(private router: Router) {}

  ngOnInit() {
    this.initializeChat();
  }

  private initializeChat() {
    this.chatMessages = [
      {
        id: '1',
        content: 'Hello! I\'m your FinanceHub AI Assistant. Select a department and start chatting, or open full view for advanced features.',
        timestamp: new Date(),
        isUser: false
      }
    ];
  }

  closeChatbot() {
    this.visibilityChange.emit(false);
  }

  openFullView() {
    this.router.navigate(['/chatbot']);
    this.closeChatbot();
  }

  onDepartmentChange() {
    if (this.selectedDepartment) {
      const dept = this.departments.find(d => d.id === this.selectedDepartment);
      this.addMessage(`Connected to ${dept?.name} department. How can I help?`, false);
    }
  }

  handleKeydown(event: KeyboardEvent) {
    // Send message on Ctrl+Enter or Cmd+Enter
    if ((event.ctrlKey || event.metaKey) && event.key === 'Enter') {
      event.preventDefault();
      this.sendMessage();
    }
  }

  triggerFileInput() {
    this.fileInput.nativeElement.click();
  }

  onFileSelected(event: any) {
    const file = event.target.files[0];
    if (file) {
      const maxSize = 5 * 1024 * 1024; // 5MB
      if (file.size > maxSize) {
        alert('File size should not exceed 5MB');
        return;
      }
      this.attachedFile = file;
    }
  }

  removeAttachment() {
    this.attachedFile = null;
    if (this.fileInput) {
      this.fileInput.nativeElement.value = '';
    }
  }

  sendMessage() {
    if (this.currentMessage.trim()) {
      const message = this.currentMessage;
      const hasFile = this.attachedFile !== null;
      const hasContext = this.includeContext;

      this.addMessage(message, true, hasContext, hasFile);
      this.processAIResponse(message, hasContext, hasFile);
      this.currentMessage = '';
      this.removeAttachment();
      this.includeContext = false;
    }
  }

  private addMessage(content: string, isUser: boolean, hasContext: boolean = false, hasAttachment: boolean = false) {
    this.chatMessages.push({
      id: Date.now().toString(),
      content,
      timestamp: new Date(),
      isUser,
      hasContext,
      hasAttachment
    });

    setTimeout(() => {
      const chatBody = document.querySelector('.chatbot-body');
      if (chatBody) {
        chatBody.scrollTop = chatBody.scrollHeight;
      }
    }, 100);
  }

  private processAIResponse(userMessage: string, hasContext: boolean, hasFile: boolean) {
    this.isTyping = true;

    setTimeout(() => {
      this.isTyping = false;
      let response = '';

      if (!this.selectedDepartment) {
        response = 'Please select a department to get started.';
      } else {
        response = this.generateResponse(userMessage, hasContext, hasFile);
      }

      this.addMessage(response, false);
    }, 1000);
  }

  private generateResponse(message: string, hasContext: boolean, hasFile: boolean): string {
    const lowerMessage = message.toLowerCase();
    let contextInfo = hasContext ? ' (with document context)' : '';
    let fileInfo = hasFile ? ' and file analysis' : '';
    
    if (lowerMessage.includes('help') || lowerMessage.includes('what can')) {
      return `I can help with ${this.departments.find(d => d.id === this.selectedDepartment)?.name} queries${contextInfo}${fileInfo}. For more advanced features like history, search, and detailed analysis, please open the full view.`;
    }
    
    if (lowerMessage.includes('report') || lowerMessage.includes('analysis')) {
      return `I can help generate reports and analysis${contextInfo}${fileInfo}. For detailed options and full capabilities, please use the Full View.`;
    }

    return `I'm here to help! Open the Full View for comprehensive features including chat history, saved conversations, and advanced tools${contextInfo}${fileInfo}.`;
  }
}
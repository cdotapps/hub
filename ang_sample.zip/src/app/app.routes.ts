import { Routes } from '@angular/router';
import { HomeComponent } from './pages/home/home.component';
import { DashboardComponent } from './pages/dashboard/dashboard.component';
import { ChatAssistantComponent } from './pages/chat-assistant/chatbot-page/chat-assistant.component';
import { NotificationsPageComponent } from './pages/notifications-page/notifications-page.component';

export const routes: Routes = [
  { path: '', component: HomeComponent },
  { path: 'dashboard', component: DashboardComponent },
  { path: 'chatbot', redirectTo: 'chat-assistant', pathMatch: 'full' }, // Redirect old route
  { path: 'chat-assistant', component: ChatAssistantComponent },
  { path: 'notifications', component: NotificationsPageComponent },
  { path: '**', redirectTo: '' }
];

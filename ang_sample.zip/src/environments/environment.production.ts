export const environment = {
  production: true,
  apiUrl: 'https://api.yourcompany.com/api',
  apiTimeout: 30000,
  tokenKey: 'auth_token',
  refreshTokenKey: 'refresh_token'
};

import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../../core/auth.service';

@Component({
  selector: 'app-login-page',
  templateUrl: './login-page.component.html',
  styleUrls: ['./login-page.component.scss']
})
export class LoginPageComponent {
  email = '';

  constructor(private auth: AuthService, private router: Router) {}

  onSubmit() {
    this.auth.login({
      id: 'user-1',
      name: 'Learning Space User',
      initials: 'LS'
    });
    this.router.navigate(['/']);
  }
}

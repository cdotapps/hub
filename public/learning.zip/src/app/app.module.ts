import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AppShellComponent } from './ui/ls-shell/ls-shell.component';
import { GoalCardComponent } from './ui/ls-goal-card/ls-goal-card.component';
import { CategoryTileComponent } from './ui/ls-category-tile/ls-category-tile.component';
import { DashboardPageComponent } from './pages/dashboard/dashboard-page.component';
import { TransactionsPageComponent } from './pages/transactions/transactions-page.component';
import { GoalsPageComponent } from './pages/goals/goals-page.component';
import { InsightsPageComponent } from './pages/insights/insights-page.component';
import { LoginPageComponent } from './pages/login/login-page.component';
import { HeaderComponent } from './components/layout/header/header.component';
import { FooterComponent } from './components/layout/footer/footer.component';
import { ButtonComponent } from './components/ui/button/button.component';
import { CardComponent } from './components/ui/card/card.component';
import { AlertComponent } from './components/ui/alert/alert.component';
import { LoaderComponent } from './components/ui/loader/loader.component';
import { DataTableComponent } from './components/ui/data-table/data-table.component';

@NgModule({
  declarations: [
    AppComponent,
    AppShellComponent,
    GoalCardComponent,
    CategoryTileComponent,
    DashboardPageComponent,
    TransactionsPageComponent,
    GoalsPageComponent,
    InsightsPageComponent,
    LoginPageComponent,
    HeaderComponent,
    FooterComponent,
    ButtonComponent,
    CardComponent,
    AlertComponent,
    LoaderComponent,
    DataTableComponent
  ],
  imports: [
    BrowserModule,
    CommonModule,
    RouterModule,
    FormsModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }

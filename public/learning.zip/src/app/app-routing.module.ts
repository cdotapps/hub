import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DashboardPageComponent } from './pages/dashboard/dashboard-page.component';
import { TransactionsPageComponent } from './pages/transactions/transactions-page.component';
import { GoalsPageComponent } from './pages/goals/goals-page.component';
import { InsightsPageComponent } from './pages/insights/insights-page.component';
import { LoginPageComponent } from './pages/login/login-page.component';
import { AuthGuard } from './core/auth.guard';

const routes: Routes = [
  { path: '', component: DashboardPageComponent, canActivate: [AuthGuard] },
  { path: 'login', component: LoginPageComponent },
  { path: 'transactions', component: TransactionsPageComponent, canActivate: [AuthGuard] },
  { path: 'goals', component: GoalsPageComponent, canActivate: [AuthGuard] },
  { path: 'insights', component: InsightsPageComponent, canActivate: [AuthGuard] }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

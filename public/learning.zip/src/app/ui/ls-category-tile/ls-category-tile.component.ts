import { Component, Input } from '@angular/core';

@Component({
  selector: 'category-tile',
  templateUrl: './ls-category-tile.component.html',
  styleUrls: ['./ls-category-tile.component.scss']
})
export class CategoryTileComponent {
  @Input() label = '';
  @Input() active = false;
  @Input() icon: string = '';
}

import { Component, Input } from '@angular/core';

@Component({
  selector: 'goal-card',
  templateUrl: './ls-goal-card.component.html',
  styleUrls: ['./ls-goal-card.component.scss']
})
export class GoalCardComponent {
  @Input() label = '';
  @Input() amount = '';
  @Input() total = '';
  @Input() timeLeft = '';
  @Input() accent = '#2563eb';
}

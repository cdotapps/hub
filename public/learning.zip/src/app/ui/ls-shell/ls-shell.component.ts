import { Component } from '@angular/core';

@Component({
  selector: 'app-shell',
  templateUrl: './ls-shell.component.html',
  styleUrls: ['./ls-shell.component.scss']
})
export class AppShellComponent {}

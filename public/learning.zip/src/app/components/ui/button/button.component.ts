import { Component, EventEmitter, Input, Output } from '@angular/core';

@Component({
  selector: 'ui-button',
  templateUrl: './button.component.html',
  styleUrls: ['./button.component.scss']
})
export class ButtonComponent {
  @Input() kind: 'primary' | 'secondary' | 'ghost' = 'primary';
  @Input() disabled = false;
  @Input() fullWidth = false;
  @Output() pressed = new EventEmitter<void>();

  onClick() {
    if (!this.disabled) {
      this.pressed.emit();
    }
  }
}

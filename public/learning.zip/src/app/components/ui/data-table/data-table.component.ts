import { Component } from '@angular/core';

interface TransactionRow {
  date: string;
  description: string;
  category: string;
  amount: string;
}

@Component({
  selector: 'data-table',
  templateUrl: './data-table.component.html',
  styleUrls: ['./data-table.component.scss']
})
export class DataTableComponent {
  rows: TransactionRow[] = [
    { date: 'Oct 9', description: 'Groceries', category: 'Groceries', amount: '-$52.40' },
    { date: 'Oct 8', description: 'Figma', category: 'Software', amount: '-$29.99' },
    { date: 'Oct 7', description: 'Salary', category: 'Income', amount: '+$2,400.00' }
  ];
}

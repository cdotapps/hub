import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';

export interface UserProfile {
  id: string;
  name: string;
  initials: string;
}

@Injectable({ providedIn: 'root' })
export class AuthService {
  private readonly userSubject = new BehaviorSubject<UserProfile | null>(null);

  readonly user$: Observable<UserProfile | null> = this.userSubject.asObservable();

  get currentUser(): UserProfile | null {
    return this.userSubject.value;
  }

  login(profile?: Partial<UserProfile>): void {
    const base: UserProfile = {
      id: 'demo',
      name: 'Demo User',
      initials: 'DU'
    };
    this.userSubject.next({ ...base, ...profile });
  }

  logout(): void {
    this.userSubject.next(null);
  }
}

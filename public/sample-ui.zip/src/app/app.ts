import { Component, signal, inject, OnInit } from '@angular/core';
import { RouterOutlet, Router, NavigationEnd } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Header } from './components/header/header';
import { Footer } from './components/footer/footer';
import { filter } from 'rxjs/operators';
import { AuthService } from './services/auth.service';
import { CatalogService, CatalogCreate } from './services/catalog.service';
import { IconComponent } from './components/icon/icon.component';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet, Header, Footer, CommonModule, FormsModule, IconComponent],
  templateUrl: './app.html',
  styleUrl: './app.scss'
})
export class App implements OnInit {
  protected readonly title = signal('mypa-v0');
  showHeaderFooter = signal(true);
  isFeedbackExpanded = false;
  feedbackText = '';
  feedbackTitle = '';

  private authService = inject(AuthService);
  private router = inject(Router);
  private catalogService = inject(CatalogService);

  constructor() {
    // Check initial route
    this.checkRoute(this.router.url);

    // Listen to route changes
    this.router.events
      .pipe(filter(event => event instanceof NavigationEnd))
      .subscribe((event: NavigationEnd) => {
        this.checkRoute(event.urlAfterRedirects);
      });
  }

  ngOnInit() {
    // Initialize authentication on app startup
    this.authService.initializeAuth();
  }

  private checkRoute(url: string) {
    // Hide header/footer on login and register pages
    const hideRoutes = ['/login', '/register'];
    this.showHeaderFooter.set(!hideRoutes.includes(url));
  }

  toggleFeedback() {
    this.isFeedbackExpanded = !this.isFeedbackExpanded;
    if (!this.isFeedbackExpanded) {
      this.feedbackText = '';
      this.feedbackTitle = '';
    }
  }

  submitFeedback() {
    if (!this.feedbackText.trim()) {
      return;
    }

    // Close immediately for responsive UI; keep data until success
    this.isFeedbackExpanded = false;

    let category = 'User Feedback';
    if (this.feedbackTitle === 'Not working') {
      category = 'defect';
    } else if (this.feedbackTitle === 'New Idea') {
      category = 'Idea';
    }

    const feedbackItem: CatalogCreate = {
      type: 'Feedback',
      category: category,
      title: this.feedbackTitle || 'General Feedback',
      content: this.feedbackText,
      status: 'Draft',
      is_private: true
    };

    this.catalogService.createCatalogItem(feedbackItem).subscribe({
      next: () => {
        this.feedbackText = '';
        this.feedbackTitle = '';
        this.catalogService.notifyCatalogChanged('feedback');
        // Optionally show a success message
      },
      error: (error) => {
        console.error('Error submitting feedback:', error);
        // Reopen so user can retry without losing input
        this.isFeedbackExpanded = true;
      }
    });
  }
}

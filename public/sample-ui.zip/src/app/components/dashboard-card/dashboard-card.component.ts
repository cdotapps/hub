import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IconComponent } from '../icon/icon.component';

@Component({
  selector: 'app-dashboard-card',
  standalone: true,
  imports: [CommonModule, IconComponent],
  templateUrl: './dashboard-card.component.html',
  styleUrls: ['./dashboard-card.component.scss']
})
export class DashboardCardComponent {
  @Input() title: string = '';
  @Input() count: number | string = 0;
  @Input() label: string = '';
  @Input() icon: string = 'tasks';
  @Input() clickable: boolean = false;
  @Input() size: 'small' | 'medium' | 'large' = 'medium';
  
  getIconName(): string {
    const iconMap: Record<string, string> = {
      // Direct icon names (preferred)
      'check-circle': 'check-circle',
      'calendar': 'calendar',
      'meeting': 'meeting',
      'message': 'message',
      'file': 'file',
      'layers': 'layers',
      'bell': 'bell',
      'link': 'link',
      'alert-circle': 'alert-circle',

      // Legacy/semantic keys
      'tasks': 'check-circle',
      'events': 'calendar',
      'notes': 'message',
      'projects': 'layers',
      'reminder': 'bell',
      'news': 'file',
      'alert': 'alert-circle',
      'document': 'file',

      // App type keys used by pages
      'task': 'check-circle',
      'note': 'message'
    };
    return iconMap[this.icon] || 'grid';
  }
}

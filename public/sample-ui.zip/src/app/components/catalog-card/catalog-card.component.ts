import { Component, Input, Output, EventEmitter, HostListener, inject } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
import { CatalogItem, AgentRequestType } from '../../services/catalog.service';
import { CatalogService } from '../../services/catalog.service';
import { IconComponent } from '../icon/icon.component';
import { MarkdownPipe } from '../../pipes/markdown.pipe';
import { TimeAgoPipe } from '../../pipes/time-ago.pipe';

@Component({
  selector: 'app-catalog-card',
  standalone: true,
  imports: [CommonModule, IconComponent, MarkdownPipe, TimeAgoPipe],
  templateUrl: './catalog-card.component.html',
  styleUrls: ['./catalog-card.component.scss']
})
export class CatalogCardComponent {
  @Input() item: CatalogItem | null = null;
  @Input() isFlipped = false;
  @Input() isFullView = false;
  @Input() isLoading = false; // Add loading state input

  @Output() flip = new EventEmitter<string>();
  @Output() showDetail = new EventEmitter<CatalogItem>();
  @Output() edit = new EventEmitter<CatalogItem>();
  @Output() delete = new EventEmitter<CatalogItem>();
  @Output() toggleFavorite = new EventEmitter<CatalogItem>();
  @Output() toggleArchive = new EventEmitter<CatalogItem>();

  isHovered = false;
  showAgentMenu = false;
  showDeleteConfirm = false;

  private catalogService = inject(CatalogService);

  getIconForType(type: string): string {
    const map: Record<string, string> = {
      'Task': 'check-circle',
      'Note': 'message',
      'Document': 'file',
      'Meeting': 'calendar',
      'Project': 'folder',
      'Idea': 'lightbulb',
      'Contact': 'user',
      'Event': 'calendar',
      'Resource': 'bookmark'
    };
    return map[type] || 'file';
  }

  getStatusColor(status: string): string {
    const map: Record<string, string> = {
      'active': 'success',
      'completed': 'success',
      'in-progress': 'warning',
      'pending': 'warning',
      'cancelled': 'error',
      'archived': 'muted'
    };
    return map[status] || 'muted';
  }

  getPriorityColor(priority: string): string {
    const map: Record<string, string> = {
      'high': 'error',
      'urgent': 'error',
      'medium': 'warning',
      'low': 'success',
      'normal': 'muted'
    };
    return map[priority] || 'muted';
  }

  onCardClick() {
    if (this.item?.id) {
      this.flip.emit(this.item.id);
    }
  }

  onCloseFlip(event: Event) {
    event.stopPropagation();
    if (this.item?.id) {
      this.flip.emit(this.item.id);
    }
  }

  onShowDetail(event: Event) {
    event.stopPropagation();
    if (this.item) {
      this.showDetail.emit(this.item);
    }
  }

  onEdit(event: Event) {
    event.stopPropagation();
    if (this.item) {
      this.edit.emit(this.item);
    }
  }

  onDelete(event: Event) {
    event.stopPropagation();
    this.showDeleteConfirm = true;
  }

  onConfirmDelete() {
    if (this.item) {
      this.delete.emit(this.item);
    }
    this.showDeleteConfirm = false;
  }

  onCancelDelete() {
    this.showDeleteConfirm = false;
  }

  getDeleteMessage(): string {
    const title = this.item?.title || 'this item';
    return `Are you sure you want to delete "${title}"? This action cannot be undone.`;
  }

  onToggleFavorite(event: Event) {
    event.stopPropagation();
    if (this.item) {
      this.toggleFavorite.emit(this.item);
    }
  }

  @HostListener('document:click', ['$event'])
  onDocumentClick(event: Event) {
    // Close the agent menu when clicking outside
    const target = event.target as HTMLElement;
    if (!target.closest('.agent-menu-container')) {
      this.showAgentMenu = false;
    }
  }

  onToggleAgentMenu(event: Event) {
    event.stopPropagation();
    this.showAgentMenu = !this.showAgentMenu;
  }

  onAiRequest(event: Event, requestType: AgentRequestType) {
    event.stopPropagation();
    this.showAgentMenu = false;

    const catalogId = this.item?.id;
    if (!catalogId) {
      return;
    }

    this.catalogService.createAgentRequest(catalogId, requestType, {}).subscribe({
      next: () => {
        // Intentionally no UI mutation here; parent page can refresh if needed.
        // Keeping minimal side effects in this component.
      },
      error: (error) => {
        console.error('Error creating agent request:', error);
        alert('Failed to create AI request. Please try again.');
      }
    });
  }

  onToggleArchive(event: Event) {
    event.stopPropagation();
    if (this.item) {
      this.toggleArchive.emit(this.item);
    }
  }

  formatDate(date: Date | string | undefined): string {
    if (!date) return '';
    const d = typeof date === 'string' ? new Date(date) : date;
    return d.toLocaleDateString();
  }

  truncateText(text: string | undefined, maxLength: number): string {
    if (!text) return '';
    return text.length > maxLength ? text.substring(0, maxLength) + '...' : text;
  }

  truncateTitle(title: string | undefined, maxWords: number = 4): string {
    if (!title) return '';
    const words = title.split(/\s+/).filter(word => word.length > 0);
    if (words.length <= maxWords) return title;
    return words.slice(0, maxWords).join(' ') + '...';
  }

  getFirstThreeLines(text: string | undefined): string {
    if (!text) return '';
    const words = text.split(/\s+/).filter(word => word.length > 0);
    const firstTwenty = words.slice(0, 25);
    return firstTwenty.join(' ') + (words.length > 25 ? '...' : '');
  }

  getTagsArray(): string[] {
    return this.item?.tags || [];
  }

  getLinksArray(): string[] {
    return this.item?.links || [];
  }

  hasLinks(): boolean {
    return this.getLinksArray().length > 0;
  }

  hasTags(): boolean {
    return this.getTagsArray().length > 0;
  }

  isImportant(): boolean {
    return this.item?.is_important || false;
  }

  isUrgent(): boolean {
    return this.item?.is_urgent || false;
  }

  isPrivate(): boolean {
    return this.item?.is_private || false;
  }

  isFavorite(): boolean {
    return this.item?.is_favorite || false;
  }

  isArchived(): boolean {
    return this.item?.is_archived || false;
  }

  getProgressPercentage(): number {
    return this.item?.progress || 0;
  }

  hasProgress(): boolean {
    return typeof this.item?.progress === 'number' && this.item.progress > 0;
  }

  getAssignedToArray(): string[] {
    return this.item?.assigned_to || [];
  }

  hasAssignedTo(): boolean {
    return this.getAssignedToArray().length > 0;
  }

  getSeverityColor(severity: string): string {
    const map: Record<string, string> = {
      'critical': 'error',
      'high': 'error',
      'medium': 'warning',
      'low': 'success',
      'info': 'muted'
    };
    return map[severity] || 'muted';
  }

  isShared(): boolean {
    return !!(this.item?.shared_with && this.item.shared_with.length > 0);
  }
}

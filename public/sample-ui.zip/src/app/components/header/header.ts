import { Component, signal, inject, OnInit, HostListener } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { IconComponent } from '../icon/icon.component';
import { AuthService, User } from '../../services/auth.service';
import { NotificationService, Notification } from '../../services/notification.service';
import { WebhookService, WebhookEvent } from '../../services/webhook.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-header',
  imports: [CommonModule, FormsModule, RouterLink, IconComponent],
  templateUrl: './header.html',
  styleUrl: './header.scss',
})
export class Header implements OnInit {
  leftMenuOpen = signal(false);
  notificationsOpen = signal(false);
  currentUser = signal<User | null>(null);
  userDropdownOpen = signal(false);
  notificationCount = signal(0);
  notifications = signal<Notification[]>([]);
  filteredNotifications = signal<Notification[]>([]);
  currentFilter: 'all' | 'unread' | 'read' = 'unread';
  searchQuery = '';

  private authService = inject(AuthService);
  private router = inject(Router);
  private notificationService = inject(NotificationService);
  private webhookService = inject(WebhookService);
  
  private subscriptions: Subscription[] = [];

  ngOnInit() {
    // Subscribe to current user changes
    this.authService.currentUser$.subscribe(user => {
      this.currentUser.set(user);
    });
    
    // Subscribe to unread count changes
    const unreadSub = this.notificationService.unreadCount$.subscribe(count => {
      this.notificationCount.set(count);
    });
    
    // Subscribe to notifications changes
    const notificationsSub = this.notificationService.notifications$.subscribe(notifications => {
      this.notifications.set(notifications);
    });
    
    // Subscribe to webhook notification events
    const webhookSub = this.webhookService.getNotificationEvents().subscribe(
      (event: WebhookEvent) => {
        console.log('Header received notification webhook event:', event);
        const user = this.currentUser();
        if (user) {
          // Always refresh unread count when notification events occur
          this.notificationService.getUnreadNotificationCount(user.id.toString()).subscribe();
          
          // Refresh notifications panel if it's open
          if (this.notificationsOpen()) {
            this.loadNotifications();
          }
        }
      }
    );
    
    this.subscriptions.push(unreadSub, notificationsSub, webhookSub);
  }

  ngOnDestroy() {
    this.subscriptions.forEach(sub => sub.unsubscribe());
  }

  toggleLeftMenu() {
    this.leftMenuOpen.update(value => !value);
    // Close notifications if opening user menu
    if (this.leftMenuOpen()) {
      this.notificationsOpen.set(false);
    }
  }

  closeLeftMenu() {
    this.leftMenuOpen.set(false);
  }

  toggleNotifications() {
    this.notificationsOpen.update(value => !value);
    // Close user menu if opening notifications
    if (this.notificationsOpen()) {
      this.leftMenuOpen.set(false);
      // Load notifications when opening dropdown
      const user = this.currentUser();
      if (user) {
        this.loadNotifications();
      }
    }
  }

  loadNotifications() {
    const user = this.currentUser();
    if (!user) return;

    this.notificationService.getAllNotifications(
      user.id.toString(),
      0,
      20,
      this.currentFilter
    ).subscribe({
      next: (notifications) => {
        this.notifications.set(notifications);
        this.filterNotifications();
      },
      error: (error) => {
        console.error('Error loading notifications:', error);
      }
    });
  }

  filterNotifications() {
    let filtered = this.notifications();

    // Apply read/unread filter
    if (this.currentFilter === 'unread') {
      filtered = filtered.filter(n => !n.is_read);
    } else if (this.currentFilter === 'read') {
      filtered = filtered.filter(n => n.is_read);
    }

    // Apply search filter
    if (this.searchQuery.trim()) {
      const searchLower = this.searchQuery.toLowerCase();
      filtered = filtered.filter(n => 
        n.title?.toLowerCase().includes(searchLower) ||
        n.description?.toLowerCase().includes(searchLower) ||
        n.content?.toLowerCase().includes(searchLower)
      );
    }

    this.filteredNotifications.set(filtered);
  }

  closeNotifications() {
    this.notificationsOpen.set(false);
  }

  markAsRead(notificationId: string) {
    this.notificationService.markAsRead(notificationId).subscribe();
  }

  markAllAsRead() {
    const user = this.currentUser();
    if (user) {
      this.notificationService.markAllAsRead(user.id.toString()).subscribe();
    }
  }

  deleteNotification(notificationId: string) {
    this.notificationService.deleteNotification(notificationId).subscribe({
      next: () => {
        // Refresh notifications after deletion
        const user = this.currentUser();
        if (user) {
          this.loadNotifications();
        }
      },
      error: (error) => {
        console.error('Error deleting notification:', error);
      }
    });
  }

  getNotificationIcon(notification: Notification): string {
    // Use the same logic as the deleted NotificationDropdownComponent
    if (notification.category === 'AI Action') {
      return 'zap';
    }
    
    const content = notification.content?.toLowerCase() || '';
    const title = notification.title?.toLowerCase() || '';
    
    if (content.includes('meeting') || title.includes('meeting')) {
      return 'calendar';
    }
    if (content.includes('grammar') || title.includes('grammar')) {
      return 'check-circle';
    }
    if (content.includes('summarize') || title.includes('summarize')) {
      return 'file-text';
    }
    if (content.includes('expand') || title.includes('expand')) {
      return 'maximize-2';
    }
    if (content.includes('research') || title.includes('research')) {
      return 'search';
    }
    
    return 'bell';
  }

  getRelativeTime(date?: Date): string {
    if (!date) return '';
    
    const now = new Date();
    const notificationDate = new Date(date);
    const diffInMs = now.getTime() - notificationDate.getTime();
    const diffInMins = Math.floor(diffInMs / 60000);
    const diffInHours = Math.floor(diffInMs / 3600000);
    const diffInDays = Math.floor(diffInMs / 86400000);

    if (diffInMins < 1) return 'Just now';
    if (diffInMins < 60) return `${diffInMins}m ago`;
    if (diffInHours < 24) return `${diffInHours}h ago`;
    if (diffInDays < 7) return `${diffInDays}d ago`;
    
    return notificationDate.toLocaleDateString();
  }

  toggleUserDropdown() {
    this.userDropdownOpen.update(value => !value);
  }

  closeUserDropdown() {
    this.userDropdownOpen.set(false);
  }

  getUserDisplayName(): string {
    const user = this.currentUser();
    if (user?.full_name) {
      return user.full_name;
    }
    if (user?.email) {
      return user.email.split('@')[0];
    }
    return 'User';
  }

  getUserInitial(): string {
    const user = this.currentUser();
    if (user?.full_name) {
      return user.full_name.charAt(0).toUpperCase();
    }
    if (user?.email) {
      return user.email.charAt(0).toUpperCase();
    }
    return 'U';
  }

  onLogout() {
    this.authService.logout();
  }

  onProfileClick() {
    this.closeLeftMenu();
    this.closeUserDropdown();
    // Navigate to profile page - adjust route as needed
    this.router.navigate(['/profile']);
  }

  onSettingsClick() {
    this.closeLeftMenu();
    this.closeUserDropdown();
    // Navigate to settings page - adjust route as needed
    this.router.navigate(['/settings']);
  }

  @HostListener('document:click', ['$event'])
  onDocumentClick(event: MouseEvent) {
    const target = event.target as Element;
    const userProfile = document.querySelector('.user-profile');
    const rightSidebar = document.querySelector('.right-sidebar');
    const notificationsPanel = document.querySelector('.notifications-panel');
    
    if (this.userDropdownOpen() && userProfile && !userProfile.contains(target)) {
      this.closeUserDropdown();
    }
    
    if (this.leftMenuOpen() && rightSidebar && !rightSidebar.contains(target)) {
      const userAvatar = document.querySelector('.user-avatar');
      if (!userAvatar || !userAvatar.contains(target)) {
        this.closeLeftMenu();
      }
    }
    
    if (this.notificationsOpen() && notificationsPanel && !notificationsPanel.contains(target)) {
      const notificationBell = document.querySelector('.notification-bell');
      if (!notificationBell || !notificationBell.contains(target)) {
        this.closeNotifications();
      }
    }
  }
}

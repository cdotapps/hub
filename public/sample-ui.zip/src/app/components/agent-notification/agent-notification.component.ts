import { Component, OnInit, OnDestroy, Input } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-agent-notification',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './agent-notification.component.html',
  styleUrl: './agent-notification.component.scss',
})
export class AgentNotificationComponent implements OnInit, OnDestroy {
  @Input() message: string = '';

  agentMessages: string[] = [
    "I'm analyzing your tasks right now...",
    "Let me generate some insights for you...",
    "Great news! I've completed 3 tasks today",
    "I'm scheduling your meetings as we speak...",
    "I found some optimization opportunities",
    "Processing your automation workflows...",
    "I'm organizing your emails for you...",
    "Let me prioritize your urgent items...",
    "I'm setting up reminders for you...",
    "Just updating your notes...",
    "I'm checking your calendar...",
    "Working on your data analysis...",
    "I'm syncing everything up...",
    "Let me help you stay on track..."
  ];

  currentMessage: string = '';
  private currentIndex = 0;
  private messageInterval: any;
  isFading = false;

  ngOnInit() {
    if (this.message) {
      this.currentMessage = this.message;
      // Start fading after 3 seconds
      setTimeout(() => {
        this.isFading = true;
      }, 3000);
    } else {
      this.startMessageRotation();
    }
  }

  ngOnDestroy() {
    if (this.messageInterval) {
      clearInterval(this.messageInterval);
    }
  }

  startMessageRotation() {
    // Show first message immediately
    this.currentMessage = this.agentMessages[0];
    this.currentIndex = 0;

    // Rotate messages every 4 seconds
    this.messageInterval = setInterval(() => {
      this.currentIndex = (this.currentIndex + 1) % this.agentMessages.length;
      this.currentMessage = this.agentMessages[this.currentIndex];
    }, 4000);
  }
}

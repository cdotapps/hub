import { Component, Input, Output, EventEmitter, HostListener, inject, OnInit, OnChanges, ChangeDetectorRef } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { CatalogItem, CatalogService } from '../../services/catalog.service';
import { IconComponent } from '../icon/icon.component';
import { MarkdownPipe } from '../../pipes/markdown.pipe';
import { UserSelectorComponent, SharePermission } from '../user-selector/user-selector';
import { ConfirmationDialogComponent } from '../confirmation-dialog/confirmation-dialog.component';
import { finalize } from 'rxjs/operators';

@Component({
  selector: 'app-catalog-detail-card',
  standalone: true,
  imports: [CommonModule, FormsModule, IconComponent, MarkdownPipe, UserSelectorComponent, ConfirmationDialogComponent],
  templateUrl: './catalog-detail-card.component.html',
  styleUrls: ['./catalog-detail-card.component.scss']
})
export class CatalogDetailCardComponent implements OnInit, OnChanges {
  @Input() item: CatalogItem | null = null;
  @Input() 
  get isVisible(): boolean {
    return this._isVisible;
  }
  set isVisible(value: boolean) {
    this._isVisible = value;
    if (value) {
      // Reset to content tab when modal opens
      this.activeTab = 'content';
    }
  }
  private _isVisible = false;

  @Output() close = new EventEmitter<void>();
  @Output() edit = new EventEmitter<CatalogItem>();
  @Output() delete = new EventEmitter<CatalogItem>();
  @Output() toggleFavorite = new EventEmitter<CatalogItem>();
  @Output() toggleArchive = new EventEmitter<CatalogItem>();
  @Output() save = new EventEmitter<CatalogItem>();

  isEditing = false;
  editedItem: CatalogItem | null = null;
  activeTab = 'content';

  // Sharing properties
  selectedUsers: SharePermission[] = [];
  isSharing = false;
  canEditSharing = false;
  canViewSharing = false;
  canEditItem = true; // Can edit the item content
  showOwnerChange = false;
  showDeleteConfirm = false;

  // Assignment properties
  selectedAssignee: { userId: string; email: string; fullName: string } | null = null;
  isAssigning = false;

  private catalogService = inject(CatalogService);
  private cdr = inject(ChangeDetectorRef);

  @HostListener('document:keydown.escape')
  onEscapeKey() {
    if (this._isVisible) {
      this.onClose();
    }
  }

  @HostListener('document:keydown', ['$event'])
  onKeyDown(event: KeyboardEvent) {
    if (this._isVisible && event.key === 'Enter' && event.ctrlKey) {
      this.onSave();
    }
  }

  getIconForType(type: string): string {
    const map: Record<string, string> = {
      'Task': 'check-circle',
      'Note': 'message',
      'Document': 'file',
      'Meeting': 'calendar',
      'Project': 'folder',
      'Idea': 'lightbulb',
      'Contact': 'user',
      'Event': 'calendar',
      'Resource': 'bookmark'
    };
    return map[type] || 'file';
  }

  getStatusColor(status: string): string {
    const map: Record<string, string> = {
      'active': 'success',
      'completed': 'success',
      'in-progress': 'warning',
      'pending': 'warning',
      'cancelled': 'error',
      'archived': 'muted'
    };
    return map[status] || 'muted';
  }

  getPriorityColor(priority: string): string {
    const map: Record<string, string> = {
      'high': 'error',
      'urgent': 'error',
      'medium': 'warning',
      'low': 'success',
      'normal': 'muted'
    };
    return map[priority] || 'muted';
  }

  getSeverityColor(severity: string): string {
    const map: Record<string, string> = {
      'critical': 'error',
      'high': 'error',
      'medium': 'warning',
      'low': 'success',
      'info': 'muted'
    };
    return map[severity] || 'muted';
  }

  onClose() {
    if (this.isEditing) {
      this.cancelEdit();
    }
    this.close.emit();
  }

  onEdit() {
    this.startEdit();
  }

  onDelete() {
    this.showDeleteConfirm = true;
  }

  onConfirmDelete() {
    if (this.item) {
      this.delete.emit(this.item);
      this.onClose();
    }
    this.showDeleteConfirm = false;
  }

  onCancelDelete() {
    this.showDeleteConfirm = false;
  }

  getDeleteMessage(): string {
    const title = this.item?.title || 'this item';
    return `Are you sure you want to delete "${title}"? This action cannot be undone.`;
  }

  onToggleFavorite() {
    if (this.item) {
      this.toggleFavorite.emit(this.item);
    }
  }

  onToggleArchive() {
    if (this.item) {
      this.toggleArchive.emit(this.item);
    }
  }

  startEdit() {
    this.isEditing = true;
    this.editedItem = { 
      type: this.item?.type || '',
      title: this.item?.title || '',
      ...this.item 
    };
    this.activeTab = 'edit';
  }

  cancelEdit() {
    this.isEditing = false;
    this.editedItem = null;
    this.activeTab = 'details';
  }

  onSave() {
    if (this.editedItem) {
      this.save.emit(this.editedItem);
      this.isEditing = false;
      this.editedItem = null;
      this.activeTab = 'details';
    }
  }

  switchTab(tab: string) {
    if (!this.isEditing) {
      this.activeTab = tab;
    }
  }

  formatDate(date: Date | string | undefined): string {
    if (!date) return '';
    const d = typeof date === 'string' ? new Date(date) : date;
    return d.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  }

  formatRelativeDate(date: Date | string | undefined): string {
    if (!date) return '';
    const d = typeof date === 'string' ? new Date(date) : date;
    const now = new Date();
    const diffMs = now.getTime() - d.getTime();
    const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));
    
    if (diffDays === 0) return 'Today';
    if (diffDays === 1) return 'Yesterday';
    if (diffDays < 7) return `${diffDays} days ago`;
    if (diffDays < 30) return `${Math.floor(diffDays / 7)} weeks ago`;
    if (diffDays < 365) return `${Math.floor(diffDays / 30)} months ago`;
    return `${Math.floor(diffDays / 365)} years ago`;
  }

  getTagsArray(): string[] {
    return this.item?.tags || [];
  }

  getLinksArray(): string[] {
    return this.item?.links || [];
  }

  hasLinks(): boolean {
    return this.getLinksArray().length > 0;
  }

  hasTags(): boolean {
    return this.getTagsArray().length > 0;
  }

  isImportant(): boolean {
    return this.item?.is_important || false;
  }

  isUrgent(): boolean {
    return this.item?.is_urgent || false;
  }

  isPrivate(): boolean {
    return this.item?.is_private || false;
  }

  isFavorite(): boolean {
    return this.item?.is_favorite || false;
  }

  isArchived(): boolean {
    return this.item?.is_archived || false;
  }

  getProgressPercentage(): number {
    return this.item?.progress || 0;
  }

  hasProgress(): boolean {
    return typeof this.item?.progress === 'number' && this.item.progress > 0;
  }

  getAssignedToArray(): string[] {
    return this.item?.assigned_to || [];
  }

  hasAssignedTo(): boolean {
    return this.getAssignedToArray().length > 0;
  }

  hasContent(): boolean {
    return !!(this.item?.content || this.item?.content_html);
  }

  hasAiSummary(): boolean {
    return !!this.item?.ai_summary;
  }

  hasAiData(): boolean {
    return !!this.item?.ai_data;
  }

  hasItemData(): boolean {
    return !!this.item?.item_data;
  }

  onOverlayClick(event: MouseEvent) {
    if (event.target === event.currentTarget) {
      this.onClose();
    }
  }

  onModalClick(event: MouseEvent) {
    event.stopPropagation();
  }

  addTag(event: Event) {
    event.preventDefault();
    const input = event.target as HTMLInputElement;
    const value = input.value.trim();
    
    if (value && this.editedItem) {
      if (!this.editedItem.tags) {
        this.editedItem.tags = [];
      }
      if (!this.editedItem.tags.includes(value)) {
        this.editedItem.tags.push(value);
      }
      input.value = '';
    }
  }

  removeTag(tag: string) {
    if (this.editedItem && this.editedItem.tags) {
      this.editedItem.tags = this.editedItem.tags.filter(t => t !== tag);
    }
  }

  addLink(event: Event) {
    event.preventDefault();
    const input = event.target as HTMLInputElement;
    const value = input.value.trim();
    
    if (value && this.editedItem) {
      if (!this.editedItem.links) {
        this.editedItem.links = [];
      }
      if (!this.editedItem.links.includes(value)) {
        this.editedItem.links.push(value);
      }
      input.value = '';
    }
  }

  removeLink(link: string) {
    if (this.editedItem && this.editedItem.links) {
      this.editedItem.links = this.editedItem.links.filter(l => l !== link);
    }
  }

  getItemAsJson(): string {
    return JSON.stringify(this.item, null, 2);
  }

  async copyJsonToClipboard(): Promise<void> {
    try {
      const jsonContent = this.getItemAsJson();
      await navigator.clipboard.writeText(jsonContent);
      // You could add a toast notification here
      console.log('JSON copied to clipboard');
    } catch (err) {
      console.error('Failed to copy JSON:', err);
      // Fallback for older browsers
      const textArea = document.createElement('textarea');
      textArea.value = this.getItemAsJson();
      document.body.appendChild(textArea);
      textArea.select();
      document.execCommand('copy');
      document.body.removeChild(textArea);
    }
  }

  // Sharing methods
  ngOnInit() {
    // Initialize sharing data when item changes
  }

  ngOnChanges() {
    if (this.item) {
      this.initializeSharing();
    }
  }

  private initializeSharing() {
    if (this.item?.shared_with) {
      this.selectedUsers = this.item.shared_with.map((share: any) => ({
        userId: share.userId,
        email: share.email,
        fullName: share.fullName,
        permission: share.permission || 'view'
      }));
    } else {
      this.selectedUsers = [];
    }

    // Check if current user can edit sharing (owner or has edit permission)
    this.canEditSharing = !this.item?.user_permission || this.item.user_permission === 'edit';

    // Allow viewing sharing info if item is shared or user can edit sharing
    this.canViewSharing = this.canEditSharing || (this.selectedUsers?.length || 0) > 0;
    
    // Check if current user can edit the item (owner or has edit permission)
    this.canEditItem = !this.item?.user_permission || this.item.user_permission === 'edit';
  }

  onSharingChanged(selectedUsers: SharePermission[]) {
    this.selectedUsers = selectedUsers;
  }

  saveSharing() {
    if (!this.item?.id || !this.canEditSharing) return;

    this.isSharing = true;
    console.log('Saving sharing with users:', this.selectedUsers);
    
    this.catalogService.shareCatalogItem(this.item.id, this.selectedUsers).pipe(
      finalize(() => {
        this.isSharing = false;
        console.log('Sharing save completed, isSharing:', this.isSharing);
      })
    ).subscribe({
      next: (updatedItem) => {
        console.log('Sharing updated successfully:', updatedItem);
        // Update the item with complete data from server
        if (this.item) {
          Object.assign(this.item, updatedItem);
          this.selectedUsers = updatedItem.shared_with?.map((share: any) => ({
            userId: share.userId,
            email: share.email,
            fullName: share.fullName,
            permission: share.permission || 'view'
          })) || [];
          // Recalculate permissions
          this.initializeSharing();
        }
        this.catalogService.notifyCatalogChanged('shared');
        this.cdr.markForCheck();
      },
      error: (error) => {
        console.error('Failed to update sharing:', error);
        this.cdr.markForCheck();
      }
    });
  }

  assignItem() {
    if (!this.item?.id || !this.selectedAssignee || !this.canEditSharing) return;

    this.isAssigning = true;
    this.catalogService.assignCatalogItem(this.item.id, this.selectedAssignee.userId).subscribe({
      next: (updatedItem) => {
        // Update the item with new ownership
        if (this.item) {
          Object.assign(this.item, updatedItem);
          this.selectedAssignee = null;
        }
        this.isAssigning = false;
        this.catalogService.notifyCatalogChanged('assigned');
        // Could add success notification here
      },
      error: (error) => {
        console.error('Failed to assign item:', error);
        this.isAssigning = false;
        // Could add error notification here
      }
    });
  }

  onAssigneeChanged(selectedUsers: SharePermission[]) {
    if (selectedUsers && selectedUsers.length > 0) {
      const selectedUser = selectedUsers[0];
      // Don't assign if the selected user is already the owner
      if (selectedUser.userId === this.item?.owner_id) {
        this.selectedAssignee = null;
        return;
      }
      this.selectedAssignee = {
        userId: selectedUser.userId,
        email: selectedUser.email,
        fullName: selectedUser.fullName || ''
      };
    } else {
      this.selectedAssignee = null;
    }
  }

  onOwnerSelected(selectedUsers: SharePermission[]) {
    if (!selectedUsers || selectedUsers.length === 0 || !this.item?.id) return;

    const selectedUser = selectedUsers[0];
    
    // Don't assign if the selected user is already the owner
    if (selectedUser.userId === this.item?.owner_id) {
      this.showOwnerChange = false;
      return;
    }

    if (confirm(`Transfer ownership to ${selectedUser.fullName || selectedUser.email}?`)) {
      this.isAssigning = true;
      this.catalogService.assignCatalogItem(this.item.id, selectedUser.userId).subscribe({
        next: (updatedItem) => {
          if (this.item) {
            Object.assign(this.item, updatedItem);
          }
          this.isAssigning = false;
          this.showOwnerChange = false;
          this.catalogService.notifyCatalogChanged('assigned');
        },
        error: (error) => {
          console.error('Failed to change owner:', error);
          this.isAssigning = false;
        }
      });
    } else {
      this.showOwnerChange = false;
    }
  }

  getSharedUsersText(): string {
    if (!this.selectedUsers || this.selectedUsers.length === 0) {
      return 'Not shared';
    }
    if (this.selectedUsers.length === 1) {
      return `Shared with 1 person`;
    }
    return `Shared with ${this.selectedUsers.length} people`;
  }
}

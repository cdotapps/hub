import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-icon',
  standalone: true,
  
  imports: [CommonModule],
  template: `
    <svg [attr.width]="size" [attr.height]="size" [attr.viewBox]="viewBox" fill="none" xmlns="http://www.w3.org/2000/svg" [ngClass]="className">
      <ng-container [ngSwitch]="name">
        <!-- Grid/Dashboard -->
        <g *ngSwitchCase="'grid'">
          <rect x="3" y="3" width="7" height="7" rx="1" [attr.stroke]="color" stroke-width="2"/>
          <rect x="14" y="3" width="7" height="7" rx="1" [attr.stroke]="color" stroke-width="2"/>
          <rect x="3" y="14" width="7" height="7" rx="1" [attr.stroke]="color" stroke-width="2"/>
          <rect x="14" y="14" width="7" height="7" rx="1" [attr.stroke]="color" stroke-width="2"/>
        </g>
        
        <!-- Meeting -->
        <g *ngSwitchCase="'meeting'">
          <rect x="3" y="4" width="18" height="18" rx="2" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          <line x1="16" y1="2" x2="16" y2="6" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          <line x1="8" y1="2" x2="8" y2="6" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          <line x1="3" y1="10" x2="21" y2="10" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          <circle cx="12" cy="15" r="2" [attr.stroke]="color" stroke-width="2"/>
          <path d="M8 19c0-1.1 0.9-2 2-2h4c1.1 0 2 0.9 2 2" [attr.stroke]="color" stroke-width="2" stroke-linecap="round"/>
        </g>
        
        <!-- Message -->
        <g *ngSwitchCase="'message'">
          <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        </g>
        
        <!-- Wallet -->
        <g *ngSwitchCase="'wallet'">
          <path d="M21 12V7a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-5" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          <path d="M21 12h-6a2 2 0 0 0 0 4h6" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        </g>
        
        <!-- Chart -->
        <g *ngSwitchCase="'chart'">
          <path d="M3 3v18h18" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          <path d="M18 9l-5 5-4-4-4 4" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        </g>
        
        <!-- Chart Bar -->
        <g *ngSwitchCase="'chart-bar'">
          <rect x="3" y="16" width="4" height="5" rx="1" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          <rect x="10" y="12" width="4" height="9" rx="1" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          <rect x="17" y="8" width="4" height="13" rx="1" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        </g>
        
        <!-- Layers -->
        <g *ngSwitchCase="'layers'">
          <path d="M12 2L2 7l10 5 10-5-10-5z" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          <path d="M2 17l10 5 10-5" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          <path d="M2 12l10 5 10-5" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        </g>
        
        <!-- Users -->
        <g *ngSwitchCase="'users'">
          <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          <circle cx="9" cy="7" r="4" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          <path d="M23 21v-2a4 4 0 0 0-3-3.87" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          <path d="M16 3.13a4 4 0 0 1 0 7.75" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        </g>
        
        <!-- Settings -->
        <g *ngSwitchCase="'settings'">
          <circle cx="12" cy="12" r="3" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        </g>
        
        <!-- Shield -->
        <g *ngSwitchCase="'shield'">
          <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        </g>
        
        <!-- User -->
        <g *ngSwitchCase="'user'">
          <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          <circle cx="12" cy="7" r="4" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        </g>
        
        <!-- Lock -->
        <g *ngSwitchCase="'lock'">
          <rect x="3" y="11" width="18" height="11" rx="2" ry="2" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          <path d="M7 11V7a5 5 0 0 1 10 0v4" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        </g>
        
        <!-- Bell -->
        <g *ngSwitchCase="'bell'">
          <path d="M6 8a6 6 0 0 1 12 0c0 4 2 6 2 6H4s2-2 2-6" [attr.stroke]="color" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" fill="none"/>
          <path d="M10.5 21a1.5 1.5 0 0 0 3 0" [attr.stroke]="color" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" fill="none"/>
        </g>
        
        <!-- Link -->
        <g *ngSwitchCase="'link'">
          <path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          <path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        </g>
        
        <!-- Dollar/Currency -->
        <g *ngSwitchCase="'dollar'">
          <circle cx="12" cy="12" r="10" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          <path d="M16 8h-6a2 2 0 1 0 0 4h4a2 2 0 1 1 0 4H8" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          <path d="M12 18V6" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        </g>
        
        <!-- Ethereum -->
        <g *ngSwitchCase="'ethereum'">
          <path d="M12 2L4 12l8 5 8-5-8-10z" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          <path d="M4 12l8 10 8-10-8 5-8-5z" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        </g>
        
        <!-- Star -->
        <g *ngSwitchCase="'star'">
          <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" [attr.stroke]="color" [attr.fill]="filled ? color : 'none'" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        </g>
        
        <!-- Clock -->
        <g *ngSwitchCase="'clock'">
          <circle cx="12" cy="12" r="10" [attr.stroke]="color" stroke-width="2"/>
          <polyline points="12 6 12 12 16 14" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        </g>
        
        <!-- Paperclip/Attach -->
        <g *ngSwitchCase="'paperclip'">
          <path d="M21.44 11.05l-9.19 9.19a6 6 0 0 1-8.49-8.49l9.19-9.19a4 4 0 0 1 5.66 5.66l-9.2 9.19a2 2 0 0 1-2.83-2.83l8.49-8.48" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        </g>
        
        <!-- Smile/Emoji -->
        <g *ngSwitchCase="'smile'">
          <circle cx="12" cy="12" r="10" [attr.stroke]="color" stroke-width="2"/>
          <path d="M8 14s1.5 2 4 2 4-2 4-2" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          <line x1="9" y1="9" x2="9.01" y2="9" [attr.stroke]="color" stroke-width="2" stroke-linecap="round"/>
          <line x1="15" y1="9" x2="15.01" y2="9" [attr.stroke]="color" stroke-width="2" stroke-linecap="round"/>
        </g>
        
        <!-- Arrow Left -->
        <g *ngSwitchCase="'arrow-left'">
          <line x1="19" y1="12" x2="5" y2="12" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          <polyline points="12 19 5 12 12 5" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        </g>
        
        <!-- X/Close -->
        <g *ngSwitchCase="'x'">
          <line x1="18" y1="6" x2="6" y2="18" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          <line x1="6" y1="6" x2="18" y2="18" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        </g>
        
        <!-- More Vertical -->
        <g *ngSwitchCase="'more-vertical'">
          <circle cx="12" cy="12" r="1" [attr.fill]="color"/>
          <circle cx="12" cy="5" r="1" [attr.fill]="color"/>
          <circle cx="12" cy="19" r="1" [attr.fill]="color"/>
        </g>
        
        <!-- Plus -->
        <g *ngSwitchCase="'plus'">
          <line x1="12" y1="5" x2="12" y2="19" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          <line x1="5" y1="12" x2="19" y2="12" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        </g>
        
        <!-- Credit Card -->
        <g *ngSwitchCase="'credit-card'">
          <rect x="1" y="4" width="22" height="16" rx="2" ry="2" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          <line x1="1" y1="10" x2="23" y2="10" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        </g>
        
        <!-- Gem/Diamond -->
        <g *ngSwitchCase="'gem'">
          <path d="M6 3h12l4 6-10 13L2 9l4-6z" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          <path d="M11 3L6 9l6 13" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          <path d="M13 3l5 6-6 13" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        </g>
        
        <!-- Arrow Down -->
        <g *ngSwitchCase="'arrow-down'">
          <line x1="12" y1="5" x2="12" y2="19" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          <polyline points="19 12 12 19 5 12" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        </g>
        
        <!-- Delete/Backspace -->
        <g *ngSwitchCase="'delete'">
          <path d="M21 4H8l-7 8 7 8h13a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2z" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          <line x1="18" y1="9" x2="12" y2="15" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          <line x1="12" y1="9" x2="18" y2="15" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        </g>
        
        <!-- Trend Up -->
        <g *ngSwitchCase="'trend-up'">
          <polyline points="23 6 13.5 15.5 8.5 10.5 1 18" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          <polyline points="17 6 23 6 23 12" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        </g>
        
        <!-- Trend Down -->
        <g *ngSwitchCase="'trend-down'">
          <polyline points="23 18 13.5 8.5 8.5 13.5 1 6" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          <polyline points="17 18 23 18 23 12" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        </g>
        
        <!-- Calendar -->
        <g *ngSwitchCase="'calendar'">
          <rect x="3" y="4" width="18" height="18" rx="2" ry="2" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          <line x1="16" y1="2" x2="16" y2="6" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          <line x1="8" y1="2" x2="8" y2="6" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          <line x1="3" y1="10" x2="21" y2="10" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        </g>
        
        <!-- Home -->
        <g *ngSwitchCase="'home'">
          <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          <polyline points="9 22 9 12 15 12 15 22" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        </g>
        
        <!-- Video -->
        <g *ngSwitchCase="'video'">
          <polygon points="23 7 16 12 23 17 23 7" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          <rect x="1" y="5" width="15" height="14" rx="2" ry="2" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        </g>
        
        <!-- Phone -->
        <g *ngSwitchCase="'phone'">
          <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        </g>
        
        <!-- Map Pin -->
        <g *ngSwitchCase="'map-pin'">
          <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          <circle cx="12" cy="10" r="3" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        </g>
        
        <!-- Check Circle -->
        <g *ngSwitchCase="'check-circle'">
          <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          <polyline points="22 4 12 14.01 9 11.01" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        </g>
        
        <!-- Shuffle -->
        <g *ngSwitchCase="'shuffle'">
          <polyline points="16 3 21 3 21 8" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          <line x1="4" y1="20" x2="21" y2="3" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          <polyline points="21 16 21 21 16 21" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          <line x1="15" y1="15" x2="21" y2="21" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          <line x1="4" y1="4" x2="9" y2="9" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        </g>
        
        <!-- Arrow Right -->
        <g *ngSwitchCase="'arrow-right'">
          <line x1="5" y1="12" x2="19" y2="12" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          <polyline points="12 5 19 12 12 19" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        </g>
        
        <!-- Microphone -->
        <g *ngSwitchCase="'mic'">
          <path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          <path d="M19 10v2a7 7 0 0 1-14 0v-2" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          <line x1="12" y1="19" x2="12" y2="23" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          <line x1="8" y1="23" x2="16" y2="23" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        </g>
        
        <!-- Image -->
        <g *ngSwitchCase="'image'">
          <rect x="3" y="3" width="18" height="18" rx="2" ry="2" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          <circle cx="8.5" cy="8.5" r="1.5" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          <polyline points="21 15 16 10 5 21" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        </g>
        
        <!-- File -->
        <g *ngSwitchCase="'file'">
          <path d="M13 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          <polyline points="13 2 13 9 20 9" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        </g>
        
        <!-- Send -->
        <g *ngSwitchCase="'send'">
          <line x1="22" y1="2" x2="11" y2="13" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          <polygon points="22 2 15 22 11 13 2 9 22 2" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        </g>
        
        <!-- Download -->
        <g *ngSwitchCase="'download'">
          <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          <polyline points="7 10 12 15 17 10" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          <line x1="12" y1="15" x2="12" y2="3" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        </g>
        
        <!-- Camera -->
        <g *ngSwitchCase="'camera'">
          <path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          <circle cx="12" cy="13" r="4" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        </g>
        
        <!-- Edit -->
        <g *ngSwitchCase="'edit'">
          <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        </g>
        
        <!-- Archive -->
        <g *ngSwitchCase="'archive'">
          <rect x="3" y="3" width="18" height="18" rx="2" ry="2" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          <polyline points="3 9 12 15 21 9" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        </g>
        
        <!-- Trash -->
        <g *ngSwitchCase="'trash'">
          <polyline points="3 6 5 6 21 6" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        </g>
        
        <!-- Maximize -->
        <g *ngSwitchCase="'maximize'">
          <path d="M8 3H5a2 2 0 0 0-2 2v3m18 0V5a2 2 0 0 0-2-2h-3m0 18h3a2 2 0 0 0 2-2v-3M3 16v3a2 2 0 0 0 2 2h3" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        </g>
        
        <!-- External Link -->
        <g *ngSwitchCase="'external-link'">
          <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          <polyline points="15 3 21 3 21 9" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          <line x1="10" y1="14" x2="21" y2="3" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        </g>
        
        <!-- Alert Circle -->
        <g *ngSwitchCase="'alert-circle'">
          <circle cx="12" cy="12" r="10" [attr.stroke]="color" stroke-width="2"/>
          <line x1="12" y1="8" x2="12" y2="12" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          <line x1="12" y1="16" x2="12.01" y2="16" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        </g>
        
        <!-- Zap - 4-pointed magic star with sparkles and dots -->
        <g *ngSwitchCase="'zap'">
          <!-- Main 4-pointed star shape -->
          <path d="M12 3 L14 10 L21 12 L14 14 L12 21 L10 14 L3 12 L10 10 Z" 
                [attr.stroke]="color" [attr.fill]="filled ? color : 'none'" stroke-width="2" stroke-linejoin="round" stroke-linecap="round"/>
          
          <!-- Small dots inside the star -->
          <circle cx="8" cy="12" r="1" [attr.fill]="color" opacity="0.8"/>
          <circle cx="12" cy="10" r="1" [attr.fill]="color" opacity="0.8"/>
          <circle cx="16" cy="12" r="1" [attr.fill]="color" opacity="0.8"/>
          <circle cx="10" cy="15" r="1" [attr.fill]="color" opacity="0.8"/>
          <circle cx="14" cy="15" r="1" [attr.fill]="color" opacity="0.8"/>

          <!-- Sparkle elements (four-pointed stars and plus signs) -->
          <!-- Top-left star -->
          <path d="M6 6 L7 7 L6 8 L5 7 Z" [attr.fill]="color"/>
          <!-- Top-right plus -->
          <g>
            <line x1="18" y1="4" x2="20" y2="4" [attr.stroke]="color" stroke-width="1.5"/>
            <line x1="19" y1="3" x2="19" y2="5" [attr.stroke]="color" stroke-width="1.5"/>
          </g>
          <!-- Bottom-left plus -->
          <g>
            <line x1="2" y1="13" x2="4" y2="13" [attr.stroke]="color" stroke-width="1.5"/>
            <line x1="3" y1="12" x2="3" y2="14" [attr.stroke]="color" stroke-width="1.5"/>
          </g>
          <!-- Bottom-right star -->
          <path d="M19 12 L20 13 L19 14 L18 13 Z" [attr.fill]="color"/>
        </g>
        
        <!-- Eye -->
        <g *ngSwitchCase="'eye'">
          <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          <circle cx="12" cy="12" r="3" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        </g>
        
        <!-- Heart -->
        <g *ngSwitchCase="'heart'">
          <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z" [attr.stroke]="color" [attr.fill]="filled ? color : 'none'" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        </g>
        
        <!-- Bookmark -->
        <g *ngSwitchCase="'bookmark'">
          <path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z" [attr.stroke]="color" [attr.fill]="filled ? color : 'none'" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        </g>
        
        <!-- Lightbulb -->
        <g *ngSwitchCase="'lightbulb'">
          <path d="M12 2a6 6 0 0 0-6 6c0 3.09 1.96 5.72 4.71 6.71.35.09.71-.09.71-.47v-1.35a1 1 0 0 0-.29-.71 3.93 3.93 0 0 1-1.42-3.04A3.93 3.93 0 0 1 12 6.58a3.93 3.93 0 0 1 3.93 3.93 3.93 3.93 0 0 1-1.42 3.04 1 1 0 0 0-.29.71v1.35c0 .38.36.56.71.47A7.48 7.48 0 0 0 18 8a6 6 0 0 0-6-6z" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          <path d="M9 21h6" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        </g>
        
        <!-- Folder -->
        <g *ngSwitchCase="'folder'">
          <path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        </g>
        
        <!-- Save -->
        <g *ngSwitchCase="'save'">
          <path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          <polyline points="17 21 17 13 7 13 7 21" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          <polyline points="7 3 7 8 15 8" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        </g>

        <!-- Copy -->
        <g *ngSwitchCase="'copy'">
          <rect x="9" y="9" width="13" height="13" rx="2" ry="2" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        </g>

        <!-- Refresh -->
        <g *ngSwitchCase="'refresh'">
          <path d="M21 12a9 9 0 1 1-2.64-6.36" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          <polyline points="21 3 21 9 15 9" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        </g>
        
        <!-- Check -->
        <g *ngSwitchCase="'check'">
          <polyline points="20 6 9 17 4 12" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        </g>

        <!-- File Text -->
        <g *ngSwitchCase="'file-text'">
          <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          <polyline points="14 2 14 8 20 8" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          <line x1="16" y1="13" x2="8" y2="13" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          <line x1="16" y1="17" x2="8" y2="17" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        </g>

        <!-- Maximize 2 -->
        <g *ngSwitchCase="'maximize-2'">
          <polyline points="15 3 21 3 21 9" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          <polyline points="9 21 3 21 3 15" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          <line x1="21" y1="3" x2="14" y2="10" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          <line x1="3" y1="21" x2="10" y2="14" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        </g>

        <!-- Message Square -->
        <g *ngSwitchCase="'message-square'">
          <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        </g>

        <!-- Search -->
        <g *ngSwitchCase="'search'">
          <circle cx="11" cy="11" r="8" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          <path d="m21 21-4.35-4.35" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        </g>

        <!-- Bell -->
        <g *ngSwitchCase="'bell'">
          <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          <path d="M13.73 21a2 2 0 0 1-3.46 0" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        </g>

        <!-- Bell Off -->
        <g *ngSwitchCase="'bell-off'">
          <path d="M13.73 21a2 2 0 0 1-3.46 0" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          <line x1="2" y1="2" x2="22" y2="22" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        </g>

        <!-- Loader -->
        <g *ngSwitchCase="'loader'">
          <path d="M21 12a9 9 0 1 1-6.219-8.56" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        </g>

        <!-- Edit 3 -->
        <g *ngSwitchCase="'edit-3'">
          <path d="M12 20h9" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          <path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4 12.5-12.5z" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        </g>

        <!-- Trash 2 -->
        <g *ngSwitchCase="'trash-2'">
          <polyline points="3 6 5 6 21 6" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          <line x1="10" y1="11" x2="10" y2="17" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          <line x1="14" y1="11" x2="14" y2="17" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        </g>

        <!-- List -->
        <g *ngSwitchCase="'list'">
          <line x1="8" y1="6" x2="21" y2="6" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          <line x1="8" y1="12" x2="21" y2="12" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          <line x1="8" y1="18" x2="21" y2="18" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          <line x1="3" y1="6" x2="3.01" y2="6" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          <line x1="3" y1="12" x2="3.01" y2="12" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          <line x1="3" y1="18" x2="3.01" y2="18" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        </g>

        <!-- User Check -->
        <g *ngSwitchCase="'user-check'">
          <path d="M16 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          <circle cx="8.5" cy="7" r="4" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          <polyline points="17 11 19 13 23 9" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        </g>

        <!-- Trending Up -->
        <g *ngSwitchCase="'trending-up'">
          <polyline points="23 6 13.5 15.5 8.5 10.5 1 18" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          <polyline points="17 6 23 6 23 12" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        </g>

        <!-- Share 2 -->
        <g *ngSwitchCase="'share-2'">
          <circle cx="18" cy="5" r="3" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          <circle cx="6" cy="12" r="3" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          <circle cx="18" cy="19" r="3" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          <line x1="8.59" y1="13.51" x2="15.42" y2="17.49" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          <line x1="15.41" y1="6.51" x2="8.59" y2="10.49" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        </g>

        <!-- Info -->
        <g *ngSwitchCase="'info'">
          <circle cx="12" cy="12" r="10" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          <line x1="12" y1="16" x2="12" y2="12" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          <line x1="12" y1="8" x2="12.01" y2="8" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        </g>

        <!-- Flag -->
        <g *ngSwitchCase="'flag'">
          <path d="M4 15s1-1 4-1 5 2 8 2 4-1 4-1V3s-1 1-4 1-5-2-8-2-4 1-4 1z" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          <line x1="4" y1="22" x2="4" y2="15" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        </g>

        <!-- Maximize 2 -->
        <g *ngSwitchCase="'maximize-2'">
          <polyline points="15 3 21 3 21 9" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          <polyline points="9 21 3 21 3 15" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          <line x1="21" y1="3" x2="14" y2="10" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          <line x1="3" y1="21" x2="10" y2="14" [attr.stroke]="color" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        </g>
      </ng-container>
    </svg>
  `,
  styles: [`
    :host {
      display: inline-flex;
      align-items: center;
      justify-content: center;
    }
    svg {
      display: block;
    }
  `]
})
export class IconComponent {
  @Input() name: string = 'grid';
  @Input() size: number = 24;
  @Input() color: string = 'currentColor';
  @Input() className: string = '';
  @Input() filled: boolean = false;
  
  get viewBox(): string {
    return `0 0 24 24`;
  }
}

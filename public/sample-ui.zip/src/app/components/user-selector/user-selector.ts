import { Component, Input, Output, EventEmitter, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { FamilyService, FamilyMemberInfo } from '../../services/family.service';
import { AuthService, User } from '../../services/auth.service';
import { ClickOutsideDirective } from '../../directives/click-outside.directive';
import { IconComponent } from '../icon/icon.component';

export interface SharePermission {
  userId: string;
  email: string;
  fullName?: string;
  permission: 'view' | 'edit';
}

@Component({
  selector: 'app-user-selector',
  standalone: true,
  imports: [CommonModule, FormsModule, ClickOutsideDirective, IconComponent],
  templateUrl: './user-selector.html',
  styleUrls: ['./user-selector.scss'],
})
export class UserSelectorComponent implements OnInit {
  @Input() selectedUsers: SharePermission[] = [];
  @Input() placeholder = 'Select users to share with...';
  @Input() showPermissions = true;
  @Input() singleSelect = false;
  @Output() selectionChanged = new EventEmitter<SharePermission[]>();

  availableUsers: FamilyMemberInfo[] = [];
  filteredUsers: FamilyMemberInfo[] = [];
  searchQuery = '';
  isDropdownOpen = false;
  currentUser: User | null = null;

  private familyService = inject(FamilyService);
  private authService = inject(AuthService);

  ngOnInit() {
    this.authService.currentUser$.subscribe(user => {
      this.currentUser = user;
      if (user) {
        this.loadFamilyMembers();
      }
    });
  }

  loadFamilyMembers() {
    this.familyService.getMyFamilyOverview().subscribe({
      next: (overview) => {
        // Filter out current user and get family members
        this.availableUsers = overview.members.filter(
          member => this.currentUser && member.user_id !== this.currentUser.id.toString()
        );
        this.filteredUsers = [...this.availableUsers];
      },
      error: (error) => {
        console.error('Failed to load family members:', error);
      }
    });
  }

  filterUsers() {
    if (!this.searchQuery.trim()) {
      this.filteredUsers = [...this.availableUsers];
    } else {
      const query = this.searchQuery.toLowerCase();
      this.filteredUsers = this.availableUsers.filter(user =>
        user.email.toLowerCase().includes(query) ||
        (user.full_name && user.full_name.toLowerCase().includes(query))
      );
    }
  }

  toggleDropdown() {
    this.isDropdownOpen = !this.isDropdownOpen;
  }

  selectUser(user: FamilyMemberInfo) {
    if (this.singleSelect) {
      // For single select mode (assignment), emit the user directly
      this.selectionChanged.emit([{
        userId: user.user_id,
        email: user.email,
        fullName: user.full_name || undefined,
        permission: 'view' // Default permission, but not used for assignment
      }]);
      this.isDropdownOpen = false;
      this.searchQuery = '';
    } else {
      // Multi-select mode (sharing)
      const existingIndex = this.selectedUsers.findIndex(u => u.userId === user.user_id);
      if (existingIndex === -1) {
        // Add user with default view permission
        const sharePermission: SharePermission = {
          userId: user.user_id,
          email: user.email,
          fullName: user.full_name || undefined,
          permission: 'view'
        };
        this.selectedUsers.push(sharePermission);
        this.selectionChanged.emit([...this.selectedUsers]);
      }
      this.searchQuery = '';
      this.isDropdownOpen = false;
      this.filterUsers();
    }
  }

  removeUser(userId: string) {
    this.selectedUsers = this.selectedUsers.filter(u => u.userId !== userId);
    this.selectionChanged.emit([...this.selectedUsers]);
  }

  changePermission(userId: string, permission: 'view' | 'edit') {
    const userIndex = this.selectedUsers.findIndex(u => u.userId === userId);
    if (userIndex !== -1) {
      this.selectedUsers[userIndex].permission = permission;
      this.selectionChanged.emit([...this.selectedUsers]);
    }
  }

  togglePermission(userId: string) {
    const userIndex = this.selectedUsers.findIndex(u => u.userId === userId);
    if (userIndex !== -1) {
      const currentPermission = this.selectedUsers[userIndex].permission;
      this.selectedUsers[userIndex].permission = currentPermission === 'view' ? 'edit' : 'view';
      this.selectionChanged.emit([...this.selectedUsers]);
    }
  }

  getDisplayName(user: SharePermission): string {
    return user.fullName || user.email;
  }

  isUserSelected(user: FamilyMemberInfo): boolean {
    return this.selectedUsers.some(u => u.userId === user.user_id);
  }

  onSearchInput(event: any) {
    this.searchQuery = event.target.value;
    this.filterUsers();
    if (!this.isDropdownOpen && this.searchQuery) {
      this.openDropdown();
    }
  }

  openDropdown() {
    this.isDropdownOpen = true;
  }

  closeDropdown() {
    this.isDropdownOpen = false;
  }
}
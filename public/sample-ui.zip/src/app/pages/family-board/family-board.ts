import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { IconComponent } from '../../components/icon/icon.component';

type TaskStatus = 'todo' | 'in-progress' | 'done';
type TaskPriority = 'high' | 'medium' | 'low';
type TaskCategory = 'chore' | 'shopping' | 'appointment' | 'school' | 'wellness' | 'family';

interface FamilyMember {
  id: string;
  name: string;
  relation: string;
  initials: string;
  color: string;
  points: number;
  focus: string;
}

interface FamilyTask {
  id: string;
  title: string;
  description: string;
  category: TaskCategory;
  priority: TaskPriority;
  status: TaskStatus;
  assigneeId: string;
  dueDate: string;
  rewardPoints: number;
}

interface FamilyReward {
  id: string;
  title: string;
  description: string;
  pointsRequired: number;
}

interface FamilyEvent {
  id: string;
  title: string;
  schedule: string;
  ownerId: string;
  notes: string;
}

interface FamilyHighlight {
  id: string;
  title: string;
  description: string;
  icon: string;
  accent: string;
}

interface TaskColumn {
  status: TaskStatus;
  label: string;
  icon: string;
  tasks: FamilyTask[];
}

@Component({
  selector: 'app-family-board',
  imports: [CommonModule, IconComponent],
  templateUrl: './family-board.html',
  styleUrl: './family-board.scss'
})
export class FamilyBoard implements OnInit {
  familyName = 'The Parker Family';
  familyPoints = 1280;
  weeklyGoal = 1500;
  activeChallenges = 3;
  focusAreas = ['Home Care', 'School Support', 'Wellness'];

  members: FamilyMember[] = [
    { id: 'alex', name: 'Alex Parker', relation: 'Dad', initials: 'AP', color: '#3d94ac', points: 420, focus: 'Weekly planning' },
    { id: 'maria', name: 'Maria Parker', relation: 'Mom', initials: 'MP', color: '#845ef7', points: 510, focus: 'Meal prep' },
    { id: 'lena', name: 'Lena Parker', relation: 'Daughter', initials: 'LP', color: '#f59f00', points: 210, focus: 'School projects' },
    { id: 'max', name: 'Max Parker', relation: 'Son', initials: 'MP', color: '#ff6b6b', points: 140, focus: 'Pet care' }
  ];

  tasks: FamilyTask[] = [
    {
      id: 'task-1',
      title: 'Grocery Run & Meal Prep',
      description: 'Pick up fresh produce and prep lunches for the week.',
      category: 'shopping',
      priority: 'high',
      status: 'in-progress',
      assigneeId: 'maria',
      dueDate: 'Today · 5:30 PM',
      rewardPoints: 35
    },
    {
      id: 'task-2',
      title: 'Laundry & Uniforms',
      description: 'Wash, fold, and prep school uniforms for Monday.',
      category: 'chore',
      priority: 'medium',
      status: 'todo',
      assigneeId: 'alex',
      dueDate: 'Tomorrow · 10:00 AM',
      rewardPoints: 20
    },
    {
      id: 'task-3',
      title: 'Science Fair Model',
      description: 'Finish the volcano model and rehearse the demo.',
      category: 'school',
      priority: 'high',
      status: 'in-progress',
      assigneeId: 'lena',
      dueDate: 'Friday · 7:00 PM',
      rewardPoints: 45
    },
    {
      id: 'task-4',
      title: 'Vet Appointment',
      description: 'Annual check-up for Milo at Greenway Vet Clinic.',
      category: 'wellness',
      priority: 'low',
      status: 'done',
      assigneeId: 'max',
      dueDate: 'Completed · Yesterday',
      rewardPoints: 15
    },
    {
      id: 'task-5',
      title: 'Family Budget Review',
      description: 'Review monthly expenses and plan savings goals.',
      category: 'family',
      priority: 'medium',
      status: 'todo',
      assigneeId: 'alex',
      dueDate: 'Wednesday · 8:00 PM',
      rewardPoints: 25
    },
    {
      id: 'task-6',
      title: 'Wellness Walk',
      description: 'Evening walk around the lake with the whole family.',
      category: 'wellness',
      priority: 'low',
      status: 'done',
      assigneeId: 'maria',
      dueDate: 'Completed · Sunday',
      rewardPoints: 10
    }
  ];

  rewards: FamilyReward[] = [
    { id: 'reward-1', title: 'Movie Night', description: 'Family movie night with snacks of choice.', pointsRequired: 1000 },
    { id: 'reward-2', title: 'Weekend Adventure', description: 'Choose a weekend activity or outing.', pointsRequired: 1500 },
    { id: 'reward-3', title: 'Staycation Day', description: 'Day off with favorite meals and games.', pointsRequired: 2000 }
  ];

  upcomingEvents: FamilyEvent[] = [
    { id: 'event-1', title: 'Parent-Teacher Conference', schedule: 'Tuesday · 3:30 PM', ownerId: 'alex', notes: 'Bring Lena’s progress folder.' },
    { id: 'event-2', title: 'Community Clean-up', schedule: 'Saturday · 9:00 AM', ownerId: 'maria', notes: 'Bring gloves and water bottles.' },
    { id: 'event-3', title: 'Grandma’s Birthday', schedule: 'Sunday · 1:00 PM', ownerId: 'maria', notes: 'Bake the lemon cake together.' }
  ];

  highlights: FamilyHighlight[] = [
    { id: 'highlight-1', title: 'Kitchen Refresh', description: 'Completed the pantry re-organization in record time.', icon: 'home', accent: '#845ef7' },
    { id: 'highlight-2', title: 'Health Streak', description: 'Family has kept the nightly walk streak for 10 days.', icon: 'heart', accent: '#ff6b6b' },
    { id: 'highlight-3', title: 'Homework Hero', description: 'Lena submitted the science project draft early.', icon: 'star', accent: '#f59f00' }
  ];

  taskColumns: TaskColumn[] = [];

  private readonly router = inject(Router);

  private readonly categoryMap: Record<TaskCategory, { label: string; className: string }> = {
    chore: { label: 'Chore', className: 'chore' },
    shopping: { label: 'Shopping', className: 'shopping' },
    appointment: { label: 'Appointment', className: 'appointment' },
    school: { label: 'School', className: 'school' },
    wellness: { label: 'Wellness', className: 'wellness' },
    family: { label: 'Family', className: 'family' }
  };

  private readonly priorityLabels: Record<TaskPriority, string> = {
    high: 'High Priority',
    medium: 'Medium Priority',
    low: 'Low Priority'
  };

  ngOnInit(): void {
    this.buildColumns();
  }

  get progressPercent(): number {
    const percent = Math.round((this.familyPoints / this.weeklyGoal) * 100);
    return Math.min(percent, 100);
  }

  get completedTaskCount(): number {
    return this.tasks.filter(task => task.status === 'done').length;
  }

  get activeTaskCount(): number {
    return this.tasks.filter(task => task.status !== 'done').length;
  }

  get nextReward(): FamilyReward | null {
    return this.rewards
      .filter(reward => reward.pointsRequired > this.familyPoints)
      .sort((a, b) => a.pointsRequired - b.pointsRequired)[0] ?? null;
  }

  get pointsToNextReward(): number {
    return this.nextReward ? Math.max(this.nextReward.pointsRequired - this.familyPoints, 0) : 0;
  }

  get nextRewardProgress(): number {
    if (!this.nextReward) {
      return 100;
    }
    const percent = (this.familyPoints / this.nextReward.pointsRequired) * 100;
    return Math.min(Math.max(percent, 0), 100);
  }

  get nextFocusTask(): FamilyTask | null {
    return this.tasks.find(task => task.status !== 'done') ?? null;
  }

  getMember(memberId: string): FamilyMember | undefined {
    return this.members.find(member => member.id === memberId);
  }

  getCategoryLabel(task: FamilyTask): string {
    return this.categoryMap[task.category]?.label ?? 'Task';
  }

  getCategoryClass(task: FamilyTask): string {
    return this.categoryMap[task.category]?.className ?? '';
  }

  getPriorityLabel(task: FamilyTask): string {
    return this.priorityLabels[task.priority];
  }

  navigateToDashboard(): void {
    this.router.navigate(['/dashboard']);
  }

  private buildColumns(): void {
    const config: Array<{ status: TaskStatus; label: string; icon: string }> = [
      { status: 'todo', label: 'To Do', icon: 'list' },
      { status: 'in-progress', label: 'In Progress', icon: 'loader' },
      { status: 'done', label: 'Completed', icon: 'check-circle' }
    ];

    this.taskColumns = config.map(column => ({
      ...column,
      tasks: this.tasks.filter(task => task.status === column.status)
    }));
  }
}

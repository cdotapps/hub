import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { AuthService } from '../../services/auth.service';
import { CommonModule } from '@angular/common';
import { finalize } from 'rxjs/operators';

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [ReactiveFormsModule, CommonModule, RouterLink],
  templateUrl: './register.html',
  styleUrls: ['./register.scss']
})
export class Register {
  registerForm: FormGroup;
  errorMessage: string = '';
  successMessage: string = '';
  isSubmitting: boolean = false;

  constructor(
    private fb: FormBuilder,
    private authService: AuthService,
    private router: Router
  ) {
    this.registerForm = this.fb.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(6)]],
      fullName: ['', Validators.required]
    });
  }

  private applyServerErrors(err: any): string {
    // Reset previous server errors
    Object.keys(this.registerForm.controls).forEach(key => {
      const control = this.registerForm.get(key);
      if (control && control.errors && control.errors['server']) {
        delete control.errors['server'];
        control.updateValueAndValidity({ onlySelf: true, emitEvent: false });
      }
    });

    if (!err || !err.error) {
      return err?.message || 'Registration failed';
    }

    const body = err.error;

    // FastAPI validation errors usually come as an array in detail
    if (Array.isArray(body?.detail)) {
      const messages: string[] = [];
      for (const d of body.detail) {
        const msg = d?.msg || d?.message || JSON.stringify(d);
        // loc might look like ['body','email'] or ['body','password']
        if (Array.isArray(d.loc) && d.loc.length >= 2) {
          const field = d.loc[d.loc.length - 1];
          // Try mapping to our form control names (fullName vs full_name)
          const controlName = field === 'full_name' ? 'fullName' : field;
          const control = this.registerForm.get(controlName);
          if (control) {
            control.setErrors({ ...control.errors, server: msg });
            control.markAsTouched();
            messages.push(`${field}: ${msg}`);
            continue;
          }
        }
        messages.push(msg);
      }
      return messages.join('; ');
    }

    // If detail is a string
    if (typeof body.detail === 'string') {
      return body.detail;
    }

    // Generic fallback
    return JSON.stringify(body);
  }

  onSubmit(): void {
    // Show validation messages if invalid
    if (this.registerForm.invalid) {
      this.registerForm.markAllAsTouched();
      return;
    }

    const { email, password, fullName } = this.registerForm.value;
    this.isSubmitting = true;
    this.errorMessage = '';
    this.successMessage = '';

    this.authService.register(email, password, fullName)
      .pipe(finalize(() => this.isSubmitting = false))
      .subscribe({
        next: () => {
          this.successMessage = 'Registration successful! Redirecting to login...';
          this.errorMessage = '';
          setTimeout(() => this.router.navigate(['/login']), 1500);
        },
        error: (err) => {
          console.error('Registration error:', err);
          // Map server validation errors to form controls
          this.errorMessage = this.applyServerErrors(err);
          this.successMessage = '';
        }
      });
  }
}
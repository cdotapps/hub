import { Component, OnInit, OnDestroy, AfterViewInit, ViewChild, ElementRef, ChangeDetectorRef, inject } from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { forkJoin, map, Subscription } from 'rxjs';
import { CatalogService, CatalogCreate, CatalogItem } from '../../services/catalog.service';
import { CatalogUtilityService } from '../../services/catalog-utility.service';
import { WebhookService, WebhookEvent } from '../../services/webhook.service';
import { AuthService, User } from '../../services/auth.service';
import { AgentService } from '../../services/agent.service';
import { NotificationService } from '../../services/notification.service';
import { IconComponent } from '../../components/icon/icon.component';
import { DashboardCardComponent } from '../../components/dashboard-card/dashboard-card.component';
import { CatalogDetailCardComponent } from '../../components/catalog-detail-card/catalog-detail-card.component';
import { ConfirmationDialogComponent } from '../../components/confirmation-dialog/confirmation-dialog.component';

@Component({
  selector: 'app-dashboard',
  imports: [CommonModule, FormsModule, DashboardCardComponent, IconComponent],
  templateUrl: './dashboard.html',
  styleUrl: './dashboard.scss',
})
export class Dashboard implements OnInit, OnDestroy, AfterViewInit {
  userName = '...';
  userEmail = '';
  currentUser: User | null = null;
  totalCatalogCount = 0;
  pendingRequestsCount = 0;
  pendingAgentRequestsCount = 0;
  inProgressAgentRequestsCount = 0;
  isAIModalOpen = false;
  isCatalogModalOpen = false;
  notificationMessage = '';
  
  typeCounts: {type: string, count: number}[] = [];

  aiTask = {
    title: '',
    content: '',
    type: '',
    category: ''
  };

  availableTypes: string[] = [];
  availableCategories: string[] = [];

  @ViewChild('catalogContentInput') catalogContentInput!: ElementRef<HTMLTextAreaElement>;
  @ViewChild('aiContentInput') aiContentInput!: ElementRef<HTMLTextAreaElement>;

  private authService = inject(AuthService);
  private router = inject(Router);
  private catalogService = inject(CatalogService);
  private catalogUtilityService = inject(CatalogUtilityService);
  private webhookService = inject(WebhookService);
  private agentService = inject(AgentService);
  private notificationService = inject(NotificationService);
  private cdr = inject(ChangeDetectorRef);
  
  private webhookSubscription?: Subscription;

  ngOnInit() {
    console.log('Dashboard ngOnInit - starting initialization');
    
    // Check if user is authenticated
    if (!this.authService.isAuthenticated) {
      console.log('User not authenticated, redirecting to login');
      this.router.navigate(['/login']);
      return;
    }

    console.log('User authenticated, proceeding with dashboard initialization');

    // Load available types
    this.loadAvailableTypes();

    // Subscribe to current user
    this.authService.currentUser$.subscribe(user => {
      console.log('Current user updated:', user);
      if (user) {
        this.currentUser = user;
        this.userName = user.full_name || user.email.split('@')[0];
        this.userEmail = user.email;
        this.loadCounts();
        this.cdr.detectChanges();
        
        // Setup webhook event listeners
        this.setupWebhookListeners();
      } else {
        // If no user but token exists, load profile
        if (this.authService.getToken()) {
          console.log('Token exists but no user data, loading profile...');
          this.authService.loadUserProfile().subscribe({
            next: (profile) => console.log('Profile loaded successfully:', profile),
            error: (error) => console.error('Error loading profile:', error)
          });
        } else {
          console.log('No token found, redirecting to login');
          this.router.navigate(['/login']);
        }
      }
    });
  }

  ngOnDestroy() {
    // Component cleanup
    if (this.webhookSubscription) {
      this.webhookSubscription.unsubscribe();
    }
    this.webhookService.stopPollingForChanges();
  }

  ngAfterViewInit() {
    // Component view initialized
  }

  refreshDashboard() {
    this.loadCounts();
  }
  
  setupWebhookListeners() {
    // Subscribe to catalog events
    const catalogSubscription = this.webhookService.getCatalogEvents().subscribe(
      (event: WebhookEvent) => {
        console.log('Dashboard received catalog event:', event);
        // Refresh catalog count when catalog events occur
        this.loadCounts();
      }
    );

    // Subscribe to agent request events
    const agentSubscription = this.webhookService.getAgentRequestStatusEvents().subscribe(
      (event: WebhookEvent) => {
        console.log('Dashboard received agent request event:', event);
        // Refresh agent request counts when agent request events occur
        this.loadCounts();
        
        // Show notification for status changes
        if (event.event === 'agent_request.status_changed') {
          const statusChange = event.data.status_change;
          this.notificationMessage = `Agent request status changed from ${statusChange.from} to ${statusChange.to}`;
          setTimeout(() => {
            this.notificationMessage = '';
          }, 5000);
        }
      }
    );

    // Subscribe to notification events
    const notificationSubscription = this.webhookService.getNotificationEvents().subscribe(
      (event: WebhookEvent) => {
        console.log('Dashboard received notification event:', event);
        // Refresh notification count through notification service
        if (this.currentUser) {
          this.notificationService.getUnreadNotificationCount(this.currentUser.id.toString()).subscribe();
        }
      }
    );

    // Store subscriptions for cleanup
    this.webhookSubscription = new Subscription();
    this.webhookSubscription.add(catalogSubscription);
    this.webhookSubscription.add(agentSubscription);
    this.webhookSubscription.add(notificationSubscription);
    
    // Start polling as a fallback method
    this.webhookService.startPolling();
  }
  
  handleWebhookEvent(event: WebhookEvent) {
    console.log('Dashboard received webhook event:', event);
  }

  toggleAIModal() {
    console.log('AI Modal toggle clicked - device:', navigator.userAgent.includes('Mobile') ? 'Mobile' : 'Desktop');
    console.log('Current isAIModalOpen state:', this.isAIModalOpen);
    
    this.isAIModalOpen = !this.isAIModalOpen;
    console.log('New isAIModalOpen state:', this.isAIModalOpen);
    
    if (this.isAIModalOpen) {
      // Load types when modal opens if not already loaded
      if (this.availableTypes.length === 0) {
        console.log('Loading available types...');
        this.loadAvailableTypes();
      }
      // Default to Note type
      this.aiTask.type = 'Note';
      this.onTypeChange();
      
      // Focus the content input after a short delay to ensure the modal is rendered
      setTimeout(() => {
        if (this.aiContentInput) {
          this.aiContentInput.nativeElement.focus();
        }
      }, 100);
    }
    
    // Force change detection for mobile
    this.cdr.detectChanges();
  }

  closeAIModal() {
    this.isAIModalOpen = false;
  }

  toggleCatalogModal() {
    this.isCatalogModalOpen = !this.isCatalogModalOpen;
    if (this.isCatalogModalOpen) {
      if (this.availableTypes.length === 0) {
        this.loadAvailableTypes();
      }
      
      // Focus the content input after a short delay to ensure the modal is rendered
      setTimeout(() => {
        if (this.catalogContentInput) {
          this.catalogContentInput.nativeElement.focus();
        }
      }, 100);
    }
    this.cdr.detectChanges();
  }

  closeCatalogModal() {
    this.isCatalogModalOpen = false;
  }

  submitAITask(event: Event) {
    event.preventDefault();
    
    if (!this.aiTask.content.trim()) {
      alert('Please enter some content to analyze.');
      return;
    }

    if (!this.aiTask.type.trim()) {
      alert('Please select a type for the content.');
      return;
    }

    if (!this.aiTask.category.trim()) {
      alert('Please select a category for the content.');
      return;
    }

    // Close modal immediately
    this.closeAIModal();

    // Create catalog entry
    const catalogItem: CatalogCreate = {
      type: this.aiTask.type,
      category: this.aiTask.category,
      title: this.aiTask.title || `AI Analysis - ${new Date().toLocaleDateString()}`,
      content: this.aiTask.content,
      status: 'Draft',
      is_private: true
    };
    
    this.catalogService.createCatalogItem(catalogItem).subscribe({
      next: (createdItem) => {
        console.log('Catalog item created:', createdItem);
        
        // Reset form
        this.aiTask = {
          title: '',
          content: '',
          type: '',
          category: ''
        };
        
        // Refresh dashboard counts to reflect new item
        this.loadCounts();
        
        // Show agent notification
        this.notificationMessage = 'Content added to catalog! AI agent will analyze it shortly.';
        setTimeout(() => {
          this.notificationMessage = '';
        }, 5000);
      },
      error: (error) => {
        console.error('Error creating catalog item:', error);
        console.error('Error details:', error.error);
        console.error('Error status:', error.status);
        alert('Failed to add content to catalog. Please try again.');
        // Reopen modal on error
        this.isAIModalOpen = true;
      }
    });
  }

  submitCatalogTask(event: Event) {
    event.preventDefault();
    
    if (!this.aiTask.content.trim()) {
      alert('Please enter some content.');
      return;
    }

    if (!this.aiTask.type.trim()) {
      alert('Please select a type for the content.');
      return;
    }

    if (!this.aiTask.category.trim()) {
      alert('Please select a category for the content.');
      return;
    }

    // Close modal immediately
    this.closeCatalogModal();

    // Create catalog entry
    const catalogItem: CatalogCreate = {
      type: this.aiTask.type,
      category: this.aiTask.category,
      title: this.aiTask.title || `Catalog Item - ${new Date().toLocaleDateString()}`,
      content: this.aiTask.content,
      status: 'Draft',
      is_private: true
    };
    
    this.catalogService.createCatalogItem(catalogItem).subscribe({
      next: (createdItem) => {
        console.log('Catalog item created:', createdItem);
        
        // Reset form
        this.aiTask = {
          title: '',
          content: '',
          type: '',
          category: ''
        };
        
        // Refresh dashboard counts to reflect new item
        this.loadCounts();
        
        // Show agent notification
        this.notificationMessage = 'Content added to catalog!';
        setTimeout(() => {
          this.notificationMessage = '';
        }, 5000);
      },
      error: (error) => {
        console.error('Error creating catalog item:', error);
        alert('Failed to add content to catalog. Please try again.');
        // Reopen modal on error
        this.isCatalogModalOpen = true;
      }
    });
  }

  loadAvailableTypes() {
    console.log('Loading available types...');
    this.catalogUtilityService.getAllTypes().subscribe({
      next: (types) => {
        console.log('Types loaded successfully:', types);
        this.availableTypes = types;
        this.cdr.detectChanges();
      },
      error: (error) => {
        console.error('Error loading types:', error);
        console.error('API URL might be unreachable on mobile');
        // Don't block the app if API fails
        this.availableTypes = ['Task', 'Note', 'Document', 'Meeting']; // Fallback types
        this.cdr.detectChanges();
      }
    });
  }

  onTypeChange() {
    if (this.aiTask.type) {
      this.catalogUtilityService.getAllCategories(this.aiTask.type).subscribe(categories => {
        this.availableCategories = categories;
        // Reset category if it's not in the new list
        if (this.aiTask.category && !categories.includes(this.aiTask.category)) {
          this.aiTask.category = '';
        }
        // Default to first category
        if (!this.aiTask.category && categories.length > 0) {
          this.aiTask.category = categories[0];
        }
      });
    } else {
      this.availableCategories = [];
      this.aiTask.category = '';
    }
  }

  loadCounts() {
    // Load catalog count (excluding notifications)
    this.catalogService.getCatalogItems().subscribe(items => {
      // Filter out notifications from catalog (they're handled in header)
      const nonNotificationItems = items.filter(item => item.type !== 'Notification');
      this.totalCatalogCount = nonNotificationItems.length;
      this.cdr.detectChanges();
    });
    
    // Load pending agent requests count
    this.agentService.getRequestsCountByStatus('Pending').subscribe(count => {
      this.pendingAgentRequestsCount = count;
      this.cdr.detectChanges();
    });
    
    // Load in-progress agent requests count
    this.agentService.getInProgressRequestsCount().subscribe(count => {
      this.inProgressAgentRequestsCount = count;
      this.cdr.detectChanges();
    });
    
    // Load type counts (excluding notifications)
    const defaultTypes = this.catalogUtilityService.getDefaultDashboardTypes();
    const countObservables = defaultTypes.map(type => 
      this.catalogService.getCatalogCount(type).pipe(
        map(count => ({ type, count }))
      )
    );
    
    if (countObservables.length > 0) {
      forkJoin(countObservables).subscribe({
        next: (counts) => {
          // Filter out any notification type counts and ensure we only have dashboard types
          this.typeCounts = counts.filter(count => 
            defaultTypes.includes(count.type) && count.type !== 'Notification'
          );
          this.cdr.detectChanges();
        },
        error: (error) => {
          console.error('Error loading type counts:', error);
        }
      });
    }
  }

  getIconForType(type: string): string {
    const map: Record<string, string> = {
      'Task': 'check-circle',
      'Note': 'note',
      'Event': 'calendar',
      'Meeting': 'person'
    };
    return map[type] || 'file'; // default
  }

  navigateToMypad() {
    this.router.navigate(['/mypad']);
  }

  navigateToFamilyBoard() {
    this.router.navigate(['/family-board']);
  }
}

import { Component, OnDestroy, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { CatalogDetailCardComponent } from '../../components/catalog-detail-card/catalog-detail-card.component';
import { CatalogItem, CatalogService } from '../../services/catalog.service';

@Component({
  selector: 'app-catalog-detail-page',
  standalone: true,
  imports: [CommonModule, CatalogDetailCardComponent],
  templateUrl: './catalog-detail.html',
  styleUrls: ['./catalog-detail.scss']
})
export class CatalogDetailPage implements OnInit, OnDestroy {
  item: CatalogItem | null = null;
  isLoading = true;
  errorMessage = '';

  private route = inject(ActivatedRoute);
  private router = inject(Router);
  private catalogService = inject(CatalogService);
  private routeSub?: Subscription;

  ngOnInit() {
    const navigationState = this.router.getCurrentNavigation()?.extras.state as { item?: CatalogItem } | undefined;
    const stateItem = navigationState?.item || (history.state?.item as CatalogItem | undefined);
    if (stateItem) {
      this.item = stateItem;
      this.isLoading = false;
    }

    this.routeSub = this.route.paramMap.subscribe(params => {
      const itemId = params.get('id');
      if (!itemId) {
        this.errorMessage = 'Catalog item not found.';
        this.isLoading = false;
        return;
      }
      this.fetchItem(itemId);
    });
  }

  ngOnDestroy() {
    this.routeSub?.unsubscribe();
  }

  fetchItem(itemId: string) {
    this.isLoading = !this.item;
    this.errorMessage = '';
    this.catalogService.getCatalogItem(itemId).subscribe({
      next: item => {
        this.item = item;
        this.isLoading = false;
      },
      error: () => {
        this.errorMessage = 'Unable to load this catalog item.';
        this.isLoading = false;
      }
    });
  }

  handleClose() {
    this.router.navigate(['/catalog']);
  }

  handleSave(item: CatalogItem) {
    if (!item.id) return;
    this.catalogService.updateCatalogItem(item.id, item).subscribe({
      next: updated => {
        this.item = updated;
      },
      error: () => {
        this.errorMessage = 'Unable to save changes.';
      }
    });
  }

  handleDelete(item: CatalogItem) {
    if (!item.id) return;
    this.catalogService.deleteCatalogItem(item.id).subscribe({
      next: () => {
        this.router.navigate(['/catalog']);
      },
      error: () => {
        this.errorMessage = 'Unable to delete this item.';
      }
    });
  }

  handleToggleFavorite(item: CatalogItem) {
    if (!item.id) return;
    const updatedItem = { ...item, is_favorite: !item.is_favorite };
    this.catalogService.updateCatalogItem(item.id, updatedItem).subscribe({
      next: updated => {
        this.item = updated;
      },
      error: () => {
        this.errorMessage = 'Unable to update favorite.';
      }
    });
  }

  handleToggleArchive(item: CatalogItem) {
    if (!item.id) return;
    const updatedItem = { ...item, is_archived: !item.is_archived };
    this.catalogService.updateCatalogItem(item.id, updatedItem).subscribe({
      next: updated => {
        this.item = updated;
      },
      error: () => {
        this.errorMessage = 'Unable to update archive status.';
      }
    });
  }
}

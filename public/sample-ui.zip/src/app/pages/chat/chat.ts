import { Component, ViewChild, ElementRef, AfterViewChecked } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { IconComponent } from '../../components/icon/icon.component';

interface AIMessage {
  text: string;
  time: string;
  isUser: boolean;
  attachment?: {
    name: string;
    type: string;
    size?: number;
    url?: string;
  };
  attachments?: Array<{
    name: string;
    type: string;
    size: number;
    url: string;
    preview?: string;
  }>;
}

@Component({
  selector: 'app-chat',
  standalone: true,
  imports: [CommonModule, FormsModule, IconComponent],
  templateUrl: './chat.html',
  styleUrls: ['./chat.scss']
})
export class ChatComponent implements AfterViewChecked {
  @ViewChild('chatMessages') private chatMessagesContainer!: ElementRef;
  @ViewChild('messageInput') private messageInput!: ElementRef;
  @ViewChild('fileInput') private fileInput!: ElementRef;
  
  private shouldScrollToBottom = false;

  activeView: string = 'notifications';
  currentAIMessage = '';
  aiTyping = false;
  isRecording = false;
  recordingDuration = 0;
  recordingInterval: any;
  attachedFiles: Array<{
    name: string;
    type: string;
    size: number;
    url: string;
    preview?: string;
    file?: File;
  }> = [];
  
  aiMessages: AIMessage[] = [
    {
      text: 'Hello! I\'m your AI assistant. How can I help you today?',
      time: '09:00',
      isUser: false
    }
  ];
  
  sendAIMessage() {
    if (this.currentAIMessage.trim() || this.attachedFiles.length > 0) {
      // Add user message
      const userMsg: AIMessage = {
        text: this.currentAIMessage || 'Sent attachments',
        time: new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: false }),
        isUser: true,
        attachments: this.attachedFiles.length > 0 ? [...this.attachedFiles] : undefined
      };

      this.aiMessages.push(userMsg);
      this.shouldScrollToBottom = true;
      
      const userMessage = this.currentAIMessage;
      const hasAttachments = this.attachedFiles.length > 0;
      this.currentAIMessage = '';
      this.attachedFiles = [];
      
      // Simulate AI typing
      this.aiTyping = true;
      setTimeout(() => {
        this.aiTyping = false;
        this.aiMessages.push({
          text: this.generateAIResponse(userMessage, hasAttachments),
          time: new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: false }),
          isUser: false
        });
        this.shouldScrollToBottom = true;
      }, 1500);
    }
  }

  sendSuggestion(suggestion: string) {
    this.currentAIMessage = suggestion;
    this.sendAIMessage();
  }

  generateAIResponse(message: string, hasAttachments: boolean = false): string {
    if (hasAttachments) {
      return 'I\'ve received your attachments. I can analyze documents, images, and other files to help you better. What would you like me to do with these files? 📎';
    }
    
    const lowerMessage = message.toLowerCase();
    
    if (lowerMessage.includes('spending') || lowerMessage.includes('analyze')) {
      return 'Based on your recent activity, you\'ve spent $1,234 this month. Your top categories are: Dining ($450), Shopping ($380), and Transportation ($280). You\'re 15% under your budget - great job! 📊';
    } else if (lowerMessage.includes('transaction') || lowerMessage.includes('recent')) {
      return 'Here are your recent transactions:\n• $45.20 - Grocery Store (Today)\n• $120.00 - Online Shopping (Yesterday)\n• $32.50 - Restaurant (2 days ago)\nWould you like more details? 💳';
    } else if (lowerMessage.includes('investment') || lowerMessage.includes('advice')) {
      return 'Your portfolio is well-diversified! Consider:\n• Increasing your emergency fund to 6 months\n• Dollar-cost averaging into index funds\n• Reviewing your asset allocation quarterly\nRemember, I can\'t provide financial advice, but these are general tips! 📈';
    } else {
      return 'I understand you\'re asking about "' + message + '". I can help you with:\n• Analyzing your spending patterns\n• Viewing recent transactions\n• Investment tips and portfolio insights\n• Budget planning and tracking\nWhat would you like to know more about? 🤖';
    }
  }

  onEnterPress(event: KeyboardEvent) {
    if (event.shiftKey) {
      // Allow Shift+Enter for new line
      return;
    } else {
      // Send message on Enter
      event.preventDefault();
      this.sendAIMessage();
    }
  }

  // Voice recording methods
  startRecording() {
    if (!this.isRecording) {
      this.isRecording = true;
      this.recordingDuration = 0;
      this.recordingInterval = setInterval(() => {
        this.recordingDuration++;
      }, 1000);
      console.log('Recording started');
    }
  }

  stopRecording() {
    if (this.isRecording) {
      this.isRecording = false;
      clearInterval(this.recordingInterval);
      
      if (this.recordingDuration > 0) {
        // Create voice message
        const voiceMsg: AIMessage = {
          text: 'Voice message',
          time: new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: false }),
          isUser: true,
          attachment: {
            name: `Voice_${this.recordingDuration}s.mp3`,
            type: 'audio',
            size: this.recordingDuration * 16000 // Approximate size
          }
        };
        
        this.aiMessages.push(voiceMsg);
        this.shouldScrollToBottom = true;
        
        // AI response to voice message
        this.aiTyping = true;
        setTimeout(() => {
          this.aiTyping = false;
          this.aiMessages.push({
            text: 'I received your voice message! However, I\'m currently in text mode. Could you please type your message instead? 🎤',
            time: new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: false }),
            isUser: false
          });
          this.shouldScrollToBottom = true;
        }, 1500);
      }
      
      this.recordingDuration = 0;
      console.log('Recording stopped');
    }
  }

  async copyAIMessage(text: string) {
    try {
      await navigator.clipboard.writeText(text);
      console.log('AI message copied to clipboard');
      // Optional: Show a success toast/feedback
      // You could add a temporary "Copied!" indicator
    } catch (err) {
      console.error('Failed to copy AI message:', err);
      // Fallback for older browsers
      this.fallbackCopyToClipboard(text);
    }
  }

  private fallbackCopyToClipboard(text: string) {
    const textArea = document.createElement('textarea');
    textArea.value = text;
    textArea.style.position = 'fixed';
    textArea.style.left = '-999999px';
    document.body.appendChild(textArea);
    textArea.focus();
    textArea.select();
    
    try {
      document.execCommand('copy');
      console.log('AI message copied using fallback method');
    } catch (err) {
      console.error('Fallback copy failed:', err);
    }
    
    document.body.removeChild(textArea);
  }

  // File attachment methods
  triggerFileInput() {
    if (this.fileInput) {
      this.fileInput.nativeElement.click();
    }
  }

  onFileSelected(event: Event) {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files.length > 0) {
      Array.from(input.files).forEach(file => {
        this.addAttachment(file);
      });
      // Reset input
      input.value = '';
    }
  }

  addAttachment(file: File) {
    const fileUrl = URL.createObjectURL(file);
    const attachment: any = {
      name: file.name,
      type: this.getFileType(file),
      size: file.size,
      url: fileUrl,
      file: file
    };

    // Create preview for images
    if (file.type.startsWith('image/')) {
      attachment.preview = fileUrl;
    }

    this.attachedFiles.push(attachment);
  }

  removeAttachment(index: number) {
    // Revoke object URL to free memory
    if (this.attachedFiles[index].url) {
      URL.revokeObjectURL(this.attachedFiles[index].url);
    }
    this.attachedFiles.splice(index, 1);
  }

  getFileType(file: File): string {
    if (file.type.startsWith('image/')) return 'image';
    if (file.type.startsWith('video/')) return 'video';
    if (file.type.startsWith('audio/')) return 'audio';
    if (file.type.includes('pdf')) return 'pdf';
    if (file.type.includes('text') || file.type.includes('json')) return 'text';
    if (file.type.includes('zip') || file.type.includes('compressed')) return 'archive';
    return 'file';
  }

  getFileIcon(type: string): string {
    switch (type) {
      case 'image': return 'image';
      case 'video': return 'video';
      case 'audio': return 'mic';
      case 'pdf': return 'file';
      case 'text': return 'file-text';
      case 'archive': return 'archive';
      default: return 'file';
    }
  }

  formatFileSize(bytes: number): string {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return Math.round(bytes / Math.pow(k, i) * 100) / 100 + ' ' + sizes[i];
  }

  downloadAttachment(attachment: any) {
    const link = document.createElement('a');
    link.href = attachment.url;
    link.download = attachment.name;
    link.click();
  }

  scrollToBottom(): void {
    try {
      if (this.chatMessagesContainer) {
        const element = this.chatMessagesContainer.nativeElement;
        element.scrollTop = element.scrollHeight;
      }
    } catch (err) {
      console.error('Error scrolling to bottom:', err);
    }
  }

  ngAfterViewChecked() {
    if (this.shouldScrollToBottom) {
      this.scrollToBottom();
      this.shouldScrollToBottom = false;
    }
  }
}

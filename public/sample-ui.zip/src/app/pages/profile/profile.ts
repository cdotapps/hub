import { Component, OnInit, OnDestroy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService, User } from '../../services/auth.service';
import { CatalogUtilityService } from '../../services/catalog-utility.service';
import { IconComponent } from '../../components/icon/icon.component';
import {
  FamilyService,
  Family,
  FamilyInvitation,
  FamilyMemberInfo
} from '../../services/family.service';

interface FamilyMemberRow {
  id: string;
  email: string;
  fullName: string;
  role: string;
  relation?: string | null;
  status: 'active' | 'pending' | 'invited';
  joinedAt?: Date;
  invitedAt?: Date;
  invitationId?: string;
}

@Component({
  selector: 'app-profile',
  imports: [CommonModule, FormsModule, IconComponent],
  templateUrl: './profile.html',
  styleUrl: './profile.scss'
})
export class Profile implements OnInit, OnDestroy {
  currentUser: User | null = null;
  isSaving = false;
  saveMessage = '';
  activeTab = 'personal';
  
  // Profile form data
  profileForm = {
    resume: '',
    likes: '',
    dislikes: '',
    catalogTypes: [] as string[],
    apiKey: ''
  };
  
  availableTypes: string[] = [];
  familyMembers: FamilyMemberRow[] = [];
  family: Family | null = null;
  familyInvitations: FamilyInvitation[] = [];
  pendingInvitations: FamilyInvitation[] = [];
  canManageFamily = false;
  createFamilyForm = {
    name: '',
    description: ''
  };
  editFamilyForm = {
    name: '',
    description: ''
  };
  isEditingFamily = false;
  joinCode = '';
  lastInviteCode = '';
  familyLoading = false;
  familyError = '';
  searchQuery = '';
  inviteEmail = '';
  isInviting = false;
  inviteMessage = '';
  relationDrafts: Record<string, string> = {};
  isEditingMembers = false;
  
  private authService = inject(AuthService);
  private router = inject(Router);
  private catalogUtilityService = inject(CatalogUtilityService);
  private familyService = inject(FamilyService);

  ngOnInit() {
    // Check if user is authenticated
    if (!this.authService.isAuthenticated) {
      this.router.navigate(['/login']);
      return;
    }

    // Load current user data
    this.authService.currentUser$.subscribe(user => {
      if (user) {
        setTimeout(() => {
          this.currentUser = user;
          this.loadProfileData();
          this.loadFamilyOverview();
        }, 0);
      }
    });

    // Load available catalog types
    this.loadAvailableTypes();
  }

  ngOnDestroy() {
  }

  switchTab(tab: string) {
    this.activeTab = tab;
    if (tab === 'family' && this.currentUser) {
      this.loadFamilyOverview();
    }
  }

  loadFamilyOverview() {
    this.familyLoading = true;
    this.familyError = '';
    this.familyService.getMyFamilyOverview().subscribe({
      next: (overview) => {
        this.family = overview.family;
        this.familyInvitations = overview.invitations || [];
        this.pendingInvitations = overview.my_invitations || [];

        this.editFamilyForm = {
          name: overview.family?.name || '',
          description: overview.family?.description || ''
        };
        this.isEditingFamily = false;

        const members = (overview.members || []).map((member: FamilyMemberInfo) => ({
          id: member.id,
          email: member.email,
          fullName: member.full_name || member.email.split('@')[0],
          role: member.role,
          relation: member.relation || null,
          status: 'active' as const,
          joinedAt: new Date(member.joined_at)
        }));

        const invites = (overview.invitations || []).map((invite) => ({
          id: invite.id,
          email: invite.invited_email,
          fullName: invite.invited_email.split('@')[0],
          role: 'invited',
          relation: null,
          status: 'invited' as const,
          invitedAt: new Date(invite.created_at),
          invitationId: invite.id
        }));

        this.familyMembers = [...members, ...invites];
        this.relationDrafts = this.familyMembers.reduce((acc, member) => {
          if (member.status === 'active') {
            acc[member.id] = member.relation || '';
          }
          return acc;
        }, {} as Record<string, string>);
        this.canManageFamily = this.isCurrentUserAdmin(members);
        this.familyLoading = false;
      },
      error: (error) => {
        console.error('Error loading family overview:', error);
        this.familyError = 'Unable to load family data';
        this.familyMembers = [];
        this.familyInvitations = [];
        this.pendingInvitations = [];
        this.family = null;
        this.canManageFamily = false;
        this.isEditingFamily = false;
        this.relationDrafts = {};
        this.familyLoading = false;
      }
    });
  }

  private isCurrentUserAdmin(members: FamilyMemberRow[]): boolean {
    if (!this.currentUser) {
      return false;
    }
    const current = members.find(member => member.email === this.currentUser?.email);
    return current?.role === 'owner' || current?.role === 'admin';
  }

  searchUsers() {
    // TODO: Implement user search API call
    console.log('Searching for users with query:', this.searchQuery);
  }

  inviteUser() {
    if (!this.inviteEmail.trim()) {
      this.inviteMessage = 'Please enter an email address';
      return;
    }

    this.isInviting = true;
    this.inviteMessage = '';

    this.familyService.createInvitation(this.inviteEmail, this.family?.id).subscribe({
      next: (invitation) => {
        this.lastInviteCode = invitation.invitation_code;
        this.inviteEmail = '';
        this.isInviting = false;
        this.inviteMessage = `Invitation sent. Invite key: ${invitation.invitation_code}`;
        this.loadFamilyOverview();

        setTimeout(() => {
          this.inviteMessage = '';
        }, 4000);
      },
      error: (error) => {
        console.error('Error sending invitation:', error);
        this.isInviting = false;
        this.inviteMessage = 'Failed to send invitation';
      }
    });
  }

  removeInvitation(invitationId: string) {
    this.familyService.deleteInvitation(invitationId).subscribe({
      next: () => {
        this.inviteMessage = 'Invitation removed';
        this.loadFamilyOverview();
        setTimeout(() => {
          this.inviteMessage = '';
        }, 3000);
      },
      error: (error) => {
        console.error('Error deleting invitation:', error);
        this.inviteMessage = 'Failed to remove invitation';
      }
    });
  }

  acceptInvitation(invitation: FamilyInvitation) {
    this.familyService.acceptInvitation(invitation.id).subscribe({
      next: () => {
        this.pendingInvitations = this.pendingInvitations.filter(item => item.id !== invitation.id);
        this.inviteMessage = 'Invitation accepted';
        setTimeout(() => {
          this.loadFamilyOverview();
        }, 300);
        setTimeout(() => {
          this.inviteMessage = '';
        }, 3000);
      },
      error: (error) => {
        console.error('Error accepting invitation:', error);
        this.inviteMessage = 'Failed to accept invitation';
      }
    });
  }

  updateFamilyDetails() {
    if (!this.family || !this.canManageFamily) {
      return;
    }
    this.familyService.updateFamily(this.family.id, {
      name: this.editFamilyForm.name,
      description: this.editFamilyForm.description
    }).subscribe({
      next: (updated) => {
        this.family = updated;
        this.inviteMessage = 'Family updated successfully';
        this.isEditingFamily = false;
        this.loadFamilyOverview();
        setTimeout(() => {
          this.inviteMessage = '';
        }, 3000);
      },
      error: (error) => {
        console.error('Error updating family:', error);
        this.inviteMessage = 'Failed to update family';
      }
    });
  }

  startFamilyEdit() {
    if (!this.family || !this.canManageFamily) {
      return;
    }
    this.isEditingFamily = true;
    this.editFamilyForm = {
      name: this.family.name,
      description: this.family.description || ''
    };
  }

  cancelFamilyEdit() {
    this.isEditingFamily = false;
    if (this.family) {
      this.editFamilyForm = {
        name: this.family.name,
        description: this.family.description || ''
      };
    }
  }

  updateMemberRole(member: FamilyMemberRow, role: string) {
    if (!this.canManageFamily || member.role === role || member.status !== 'active') {
      return;
    }
    this.familyService.updateMember(member.id, { role }).subscribe({
      next: () => {
        member.role = role;
        this.inviteMessage = 'Role updated';
        setTimeout(() => {
          this.inviteMessage = '';
        }, 3000);
      },
      error: (error) => {
        console.error('Error updating role:', error);
        this.inviteMessage = 'Failed to update role';
      }
    });
  }

  updateMemberRelation(member: FamilyMemberRow, relation: string) {
    if (!this.canManageFamily || member.status !== 'active') {
      return;
    }
    if ((member.relation || '') === relation) {
      return;
    }
    this.familyService.updateMember(member.id, { relation }).subscribe({
      next: () => {
        member.relation = relation;
        this.relationDrafts[member.id] = relation;
        this.inviteMessage = 'Relationship updated';
        setTimeout(() => {
          this.inviteMessage = '';
        }, 3000);
      },
      error: (error) => {
        console.error('Error updating relation:', error);
        this.inviteMessage = 'Failed to update relationship';
      }
    });
  }

  startMembersEdit() {
    if (!this.canManageFamily) {
      return;
    }
    this.relationDrafts = {};
    this.familyMembers.forEach(member => {
      this.relationDrafts[member.id] = member.relation || '';
    });
    this.isEditingMembers = true;
  }

  saveMembersEdit() {
    for (const member of this.familyMembers) {
      const newRelation = this.relationDrafts[member.id];
      if (newRelation !== (member.relation || '')) {
        this.updateMemberRelation(member, newRelation);
      }
    }
    this.isEditingMembers = false;
    this.relationDrafts = {};
    this.loadFamilyOverview(); // Refresh the list to ensure UI is updated with latest data
  }

  cancelMembersEdit() {
    this.isEditingMembers = false;
    this.relationDrafts = {};
  }

  createFamily() {
    if (!this.createFamilyForm.name.trim()) {
      this.inviteMessage = 'Please enter a family name';
      return;
    }

    this.familyService.createFamily(this.createFamilyForm.name, this.createFamilyForm.description).subscribe({
      next: () => {
        this.inviteMessage = 'Family created successfully';
        this.createFamilyForm = { name: '', description: '' };
        this.loadFamilyOverview();
        setTimeout(() => {
          this.inviteMessage = '';
        }, 3000);
      },
      error: (error) => {
        console.error('Error creating family:', error);
        this.inviteMessage = 'Failed to create family';
      }
    });
  }

  joinWithCode() {
    if (!this.joinCode.trim()) {
      this.inviteMessage = 'Please enter an invite key';
      return;
    }

    this.familyService.joinWithCode(this.joinCode.trim()).subscribe({
      next: () => {
        this.inviteMessage = 'Joined family successfully';
        this.joinCode = '';
        this.loadFamilyOverview();
        setTimeout(() => {
          this.inviteMessage = '';
        }, 3000);
      },
      error: (error) => {
        console.error('Error joining family:', error);
        this.inviteMessage = 'Failed to join family';
      }
    });
  }

  loadAvailableTypes() {
    this.catalogUtilityService.getAllTypes().subscribe({
      next: (types) => {
        this.availableTypes = types;
      },
      error: (error) => {
        console.error('Error loading types:', error);
        this.availableTypes = ['Task', 'Note', 'Document', 'Meeting']; // Fallback types
      }
    });
  }

  loadProfileData() {
    // Load user's current profile settings
    // For now, we'll use mock data since the User interface doesn't include profile fields
    // In a real implementation, this would come from a profile API endpoint
    if (this.currentUser) {
      // TODO: Load actual profile data from API
      // For now, initialize with empty values
      this.profileForm = {
        resume: '',
        likes: '',
        dislikes: '',
        catalogTypes: [],
        apiKey: ''
      };
      
      // Load saved profile from localStorage as fallback
      const savedProfile = localStorage.getItem(`user_profile_${this.currentUser.id}`);
      if (savedProfile) {
        try {
          const parsed = JSON.parse(savedProfile);
          this.profileForm = { ...this.profileForm, ...parsed };
        } catch (error) {
          console.error('Error parsing saved profile:', error);
        }
      }
    }
  }

  onCatalogTypeChange(type: string, event: Event) {
    const isChecked = (event.target as HTMLInputElement).checked;
    if (isChecked) {
      if (!this.profileForm.catalogTypes.includes(type)) {
        this.profileForm.catalogTypes.push(type);
      }
    } else {
      const index = this.profileForm.catalogTypes.indexOf(type);
      if (index > -1) {
        this.profileForm.catalogTypes.splice(index, 1);
      }
    }
  }

  saveProfile() {
    this.isSaving = true;
    this.saveMessage = '';

    // Save profile to localStorage as fallback
    if (this.currentUser) {
      localStorage.setItem(`user_profile_${this.currentUser.id}`, JSON.stringify(this.profileForm));
    }

    // TODO: Call API to save profile
    // For now, we'll simulate a save operation
    setTimeout(() => {
      this.isSaving = false;
      this.saveMessage = 'Profile saved successfully!';
      
      // Clear success message after 3 seconds
      setTimeout(() => {
        this.saveMessage = '';
      }, 3000);
    }, 1500);
  }

  cancel() {
    this.router.navigate(['/dashboard']);
  }
}

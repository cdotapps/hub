import { Component, OnInit, OnDestroy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { NotificationService, Notification } from '../../services/notification.service';
import { AuthService, User } from '../../services/auth.service';
import { IconComponent } from '../../components/icon/icon.component';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-notifications',
  standalone: true,
  imports: [CommonModule, FormsModule, IconComponent],
  templateUrl: './notifications.html',
  styleUrls: ['./notifications.scss']
})
export class Notifications implements OnInit, OnDestroy {
  currentUser: User | null = null;
  notifications: Notification[] = [];
  filteredNotifications: Notification[] = [];
  currentFilter: 'all' | 'unread' | 'read' = 'unread';
  searchQuery = '';
  currentPage = 0;
  pageSize = 20;
  totalCount = 0;
  hasMore = false;

  private authService = inject(AuthService);
  private router = inject(Router);
  private notificationService = inject(NotificationService);
  private subscriptions: Subscription[] = [];

  ngOnInit() {
    // Get current user
    this.authService.currentUser$.subscribe(user => {
      this.currentUser = user;
      if (user) {
        this.loadNotifications();
      }
    });

    // Subscribe to unread count changes
    const unreadSub = this.notificationService.unreadCount$.subscribe(count => {
      // Unread count is tracked in the service
    });
    
    this.subscriptions.push(unreadSub);
  }

  ngOnDestroy() {
    this.subscriptions.forEach(sub => sub.unsubscribe());
  }

  loadNotifications(reset: boolean = true) {
    if (!this.currentUser) return;

    if (reset) {
      this.currentPage = 0;
      this.notifications = [];
      this.filteredNotifications = [];
    }

    this.notificationService.getAllNotifications(
      this.currentUser.id.toString(),
      this.currentPage * this.pageSize,
      this.pageSize,
      this.currentFilter
    ).subscribe({
      next: (notifications) => {
        if (reset) {
          this.notifications = notifications;
        } else {
          this.notifications = [...this.notifications, ...notifications];
        }
        
        this.applyFilters();
        this.hasMore = notifications.length === this.pageSize;
      },
      error: (error) => {
        console.error('Error loading notifications:', error);
      }
    });
  }

  loadMore() {
    if (!this.hasMore) return;
    this.currentPage++;
    this.loadNotifications(false);
  }

  applyFilters() {
    let filtered = this.notifications;

    // Apply read/unread filter
    if (this.currentFilter === 'unread') {
      filtered = filtered.filter(n => !n.is_read);
    } else if (this.currentFilter === 'read') {
      filtered = filtered.filter(n => n.is_read);
    }

    // Apply search filter
    if (this.searchQuery.trim()) {
      const searchLower = this.searchQuery.toLowerCase();
      filtered = filtered.filter(n => 
        n.title?.toLowerCase().includes(searchLower) ||
        n.description?.toLowerCase().includes(searchLower) ||
        n.content?.toLowerCase().includes(searchLower)
      );
    }

    this.filteredNotifications = filtered;
  }

  onFilterChange() {
    this.loadNotifications();
  }

  onSearchChange() {
    this.applyFilters();
  }

  markAsRead(notificationId: string) {
    this.notificationService.markAsRead(notificationId).subscribe({
      next: () => {
        // Update local notification
        const notification = this.notifications.find(n => n.id === notificationId);
        if (notification) {
          notification.is_read = true;
          this.applyFilters();
        }
      },
      error: (error) => {
        console.error('Error marking notification as read:', error);
      }
    });
  }

  markAllAsRead() {
    if (!this.currentUser) return;

    this.notificationService.markAllAsRead(this.currentUser.id.toString()).subscribe({
      next: () => {
        // Update local notifications
        this.notifications.forEach(n => n.is_read = true);
        this.applyFilters();
      },
      error: (error) => {
        console.error('Error marking all notifications as read:', error);
      }
    });
  }

  deleteNotification(notificationId: string, event: Event) {
    event.stopPropagation();

    if (confirm('Are you sure you want to delete this notification?')) {
      this.notificationService.deleteNotification(notificationId).subscribe({
        next: () => {
          // Remove from local notifications
          this.notifications = this.notifications.filter(n => n.id !== notificationId);
          this.applyFilters();
        },
        error: (error) => {
          console.error('Error deleting notification:', error);
        }
      });
    }
  }

  deleteAllReadNotifications() {
    // This method is removed since we don't need bulk delete functionality
    // Individual delete is available on each notification
  }

  getNotificationIcon(notification: Notification): string {
    if (notification.category === 'AI Action') {
      return 'zap';
    }
    
    const content = notification.content?.toLowerCase() || '';
    const title = notification.title?.toLowerCase() || '';
    
    if (content.includes('meeting') || title.includes('meeting')) {
      return 'calendar';
    }
    if (content.includes('grammar') || title.includes('grammar')) {
      return 'check-circle';
    }
    if (content.includes('summarize') || title.includes('summarize')) {
      return 'file-text';
    }
    if (content.includes('expand') || title.includes('expand')) {
      return 'maximize-2';
    }
    if (content.includes('research') || title.includes('research')) {
      return 'search';
    }
    
    return 'bell';
  }

  getRelativeTime(date?: Date): string {
    if (!date) return '';
    
    const now = new Date();
    const notificationDate = new Date(date);
    const diffInMs = now.getTime() - notificationDate.getTime();
    const diffInMins = Math.floor(diffInMs / 60000);
    const diffInHours = Math.floor(diffInMs / 3600000);
    const diffInDays = Math.floor(diffInMs / 86400000);

    if (diffInMins < 1) return 'Just now';
    if (diffInMins < 60) return `${diffInMins}m ago`;
    if (diffInHours < 24) return `${diffInHours}h ago`;
    if (diffInDays < 7) return `${diffInDays}d ago`;
    
    return notificationDate.toLocaleDateString();
  }

  goBack() {
    this.router.navigate(['/dashboard']);
  }

  getUnreadCount(): number {
    return this.notifications.filter(n => !n.is_read).length;
  }

  getReadCount(): number {
    return this.notifications.filter(n => n.is_read).length;
  }
}

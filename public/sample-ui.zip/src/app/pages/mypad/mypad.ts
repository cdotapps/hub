import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { CatalogService, CatalogCreate, CatalogUpdate } from '../../services/catalog.service';
import { AuthService } from '../../services/auth.service';
import { IconComponent } from '../../components/icon/icon.component';
import { TimeAgoPipe } from '../../pipes/time-ago.pipe';

@Component({
  selector: 'app-mypad',
  imports: [CommonModule, FormsModule, IconComponent],
  templateUrl: './mypad.html',
  styleUrl: './mypad.scss',
})
export class Mypad {
  title: string = 'Untitled';
  content: string = '';

  lastSaved: Date | null = null;
  hasTyped: boolean = false;
  private saveTimer: any;
  itemId: string | null = null;
  isSaving: boolean = false;

  private catalogService = inject(CatalogService);
  private authService = inject(AuthService);
  private router = inject(Router);

  onChange() {
    if (!this.hasTyped) {
      this.hasTyped = true;
      this.save(); // Create catalog item immediately on first typing
    } else {
      this.debouncedSave();
    }
  }

  private debouncedSave() {
    if (this.saveTimer) {
      clearTimeout(this.saveTimer);
    }
    this.saveTimer = setTimeout(() => {
      this.save();
    }, 2000); // Save after 2 seconds of no typing
  }

  private save() {
    if (!this.authService.isAuthenticated || this.isSaving) {
      return;
    }

    this.isSaving = true;

    const title = this.title || 'Untitled';
    const content = this.content;

    if (this.itemId) {
      const updateItem: CatalogUpdate = {
        title,
        content,
      };
      this.catalogService.updateCatalogItem(this.itemId, updateItem).subscribe({
        next: () => {
          this.lastSaved = new Date();
          this.isSaving = false;
        },
        error: (error) => {
          console.error('Error updating catalog item:', error);
          this.isSaving = false;
        }
      });
    } else {
      const createItem: CatalogCreate = {
        type: 'Note',
        category: 'Personal',
        title,
        content,
        status: 'Draft',
        is_private: true
      };
      this.catalogService.createCatalogItem(createItem).subscribe({
        next: (created) => {
          this.itemId = created.id!;
          this.lastSaved = new Date();
          this.isSaving = false;
        },
        error: (error) => {
          console.error('Error creating catalog item:', error);
          this.isSaving = false;
        }
      });
    }
  }

  saveToCatalog() {
    this.save();
    this.router.navigate(['/catalog']);
  }

  close() {
    if (this.saveTimer) {
      clearTimeout(this.saveTimer);
      this.save();
    }
    this.router.navigate(['/catalog']);
  }
}
import { Component, OnInit, OnDestroy, ChangeDetectorRef, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { CatalogService, CatalogItem } from '../../services/catalog.service';
import { AuthService, User } from '../../services/auth.service';
import { IconComponent } from '../../components/icon/icon.component';

@Component({
  selector: 'app-feedback',
  imports: [CommonModule, FormsModule, IconComponent],
  templateUrl: './feedback.html',
  styleUrl: './feedback.scss'
})
export class Feedback implements OnInit, OnDestroy {
  feedbackItems: CatalogItem[] = [];
  filteredFeedbackItems: CatalogItem[] = [];
  isLoading = false;
  editingStatusId: string | null = null;
  updatingStatusId: string | null = null;
  oldStatus = '';
  searchQuery = '';
  sortBy = 'created_at_desc';
  currentUser: User | null = null;

  private catalogService = inject(CatalogService);
  private authService = inject(AuthService);
  private cdr = inject(ChangeDetectorRef);
  public router = inject(Router);

  private catalogChangedSubscription?: Subscription;

  ngOnInit() {
    this.authService.currentUser$.subscribe(user => {
      this.currentUser = user;
      if (user) {
        this.loadFeedbackItems();
      } else {
        if (this.authService.getToken()) {
          this.authService.loadUserProfile().subscribe({
            next: () => this.cdr.detectChanges(),
            error: () => undefined
          });
        }
      }
    });

    this.catalogChangedSubscription = this.catalogService.catalogChanged$.subscribe(() => {
      this.loadFeedbackItems();
    });
  }

  ngOnDestroy() {
    if (this.catalogChangedSubscription) {
      this.catalogChangedSubscription.unsubscribe();
    }
  }

  loadFeedbackItems() {
    this.isLoading = true;
    this.catalogService.getCatalogItems().subscribe({
      next: (items) => {
        this.feedbackItems = items.filter(item => item.type === 'Feedback');
        this.applySearch();
        this.isLoading = false;
        this.cdr.detectChanges();
      },
      error: (error) => {
        console.error('Error loading feedback items:', error);
        this.isLoading = false;
        this.cdr.detectChanges();
      }
    });
  }

  applySearch() {
    if (this.searchQuery) {
      const query = this.searchQuery.toLowerCase();
      this.filteredFeedbackItems = this.feedbackItems.filter(item =>
        item.title?.toLowerCase().includes(query) ||
        item.content?.toLowerCase().includes(query)
      );
    } else {
      this.filteredFeedbackItems = [...this.feedbackItems];
    }

    // Apply sorting
    this.filteredFeedbackItems.sort((a, b) => {
      let aVal: any, bVal: any;
      switch (this.sortBy) {
        case 'created_at_desc':
          aVal = new Date(a.created_at || 0).getTime();
          bVal = new Date(b.created_at || 0).getTime();
          return bVal - aVal;
        case 'created_at_asc':
          aVal = new Date(a.created_at || 0).getTime();
          bVal = new Date(b.created_at || 0).getTime();
          return aVal - bVal;
        case 'title_asc':
          aVal = a.title || '';
          bVal = b.title || '';
          return aVal.localeCompare(bVal);
        case 'title_desc':
          aVal = a.title || '';
          bVal = b.title || '';
          return bVal.localeCompare(aVal);
        case 'status_asc':
          aVal = a.status || '';
          bVal = b.status || '';
          return aVal.localeCompare(bVal);
        case 'status_desc':
          aVal = a.status || '';
          bVal = b.status || '';
          return bVal.localeCompare(aVal);
        default:
          return 0;
      }
    });
  }

  startEditingStatus(item: CatalogItem) {
    this.editingStatusId = item.id!;
    this.oldStatus = item.status || 'Draft';
  }

  stopEditingStatus() {
    this.editingStatusId = null;
    this.updatingStatusId = null;
  }

  updateStatus(item: CatalogItem) {
    this.updatingStatusId = item.id!;
    this.catalogService.updateCatalogItem(item.id!, { status: item.status }).subscribe({
      next: (updated) => {
        const index = this.feedbackItems.findIndex(i => i.id === item.id);
        if (index !== -1) {
          Object.assign(this.feedbackItems[index], updated);
        }
        this.stopEditingStatus();
        this.cdr.detectChanges();
      },
      error: (error) => {
        console.error('Error updating status:', error);
        item.status = this.oldStatus;
        this.stopEditingStatus();
        this.cdr.detectChanges();
      }
    });
  }

  deleteFeedback(item: CatalogItem) {
    if (confirm('Are you sure you want to delete this feedback?')) {
      this.catalogService.deleteCatalogItem(item.id!).subscribe({
        next: () => {
          this.feedbackItems = this.feedbackItems.filter(i => i.id !== item.id);
          this.applySearch();
          this.cdr.detectChanges();
        },
        error: (error) => {
          console.error('Error deleting feedback:', error);
        }
      });
    }
  }

  getInitials(item: CatalogItem): string {
    const name = item.owner_full_name || item.owner_email || '';
    return name ? name.charAt(0).toUpperCase() : '?';
  }
}
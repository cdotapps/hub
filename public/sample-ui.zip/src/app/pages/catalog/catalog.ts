import { Component, OnInit, OnDestroy, ChangeDetectorRef, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { CatalogService, CatalogItem, CatalogCreate } from '../../services/catalog.service';
import { AuthService, User } from '../../services/auth.service';
import { WebhookService, WebhookEvent } from '../../services/webhook.service';
import { Subscription } from 'rxjs';
import { CatalogCardComponent } from '../../components/catalog-card/catalog-card.component';
import { IconComponent } from '../../components/icon/icon.component';
import { ConfirmationDialogComponent } from '../../components/confirmation-dialog/confirmation-dialog.component';

@Component({
  selector: 'app-catalog',
  standalone: true,
  imports: [CommonModule, FormsModule, CatalogCardComponent, IconComponent, ConfirmationDialogComponent],
  templateUrl: './catalog.html',
  styleUrls: ['./catalog.scss'],
})
export class Catalog implements OnInit, OnDestroy {
  userName = '...';
  userEmail = '';
  currentUser: User | null = null;

  catalogItems: CatalogItem[] = [];
  filteredItems: CatalogItem[] = [];
  selectedType = '';
  selectedCategory = '';
  searchQuery = '';
  availableTypes: string[] = [];
  availableCategories: string[] = [];
  isAddModalOpen = false;
  isLoading = false; // Loading state for catalog items
  isRefreshing = false; // Loading state for refresh action
  addTask = {
    title: '',
    content: '',
    type: '',
    category: ''
  };
  addAvailableCategories: string[] = [];
  flippedCards: Set<string> = new Set();
  isFullView = false; // Full view mode toggle
  showDeleteConfirmation = false;
  itemToDelete: CatalogItem | null = null;

  private catalogService = inject(CatalogService);
  private authService = inject(AuthService);
  private webhookService = inject(WebhookService);
  private router = inject(Router);
  private cdr = inject(ChangeDetectorRef);
  
  private webhookSubscription?: Subscription;
  private catalogChangedSubscription?: Subscription;

  ngOnInit() {
    if (!this.authService.isAuthenticated) {
      this.router.navigate(['/login']);
      return;
    }

    this.authService.currentUser$.subscribe(user => {
      if (user) {
        this.currentUser = user;
        this.userName = user.full_name || user.email.split('@')[0];
        this.userEmail = user.email;
        this.cdr.detectChanges();
      } else {
        if (this.authService.getToken()) {
          this.authService.loadUserProfile().subscribe({
            next: () => this.cdr.detectChanges(),
            error: () => undefined
          });
        }
      }
    });

    this.loadCatalogItems();
    this.loadAvailableTypes();

    this.catalogChangedSubscription = this.catalogService.catalogChanged$.subscribe(() => {
      this.refreshCatalog();
    });
    
    // Setup webhook event listeners
    this.setupWebhookListeners();
  }

  ngOnDestroy() {
    // Component cleanup
    if (this.webhookSubscription) {
      this.webhookSubscription.unsubscribe();
    }
    if (this.catalogChangedSubscription) {
      this.catalogChangedSubscription.unsubscribe();
    }
    this.webhookService.stopPollingForChanges();
  }

  loadCatalogItems() {
    this.isLoading = true;
    this.catalogService.getCatalogItems().subscribe({
      next: items => {
        // Filter out notifications and feedback from catalog (they're handled separately)
        this.catalogItems = items.filter(item => item.type !== 'Notification' && item.type !== 'Feedback');
        this.filteredItems = this.catalogItems;
        this.isLoading = false;
        this.cdr.detectChanges();
      },
      error: error => {
        console.error('Error loading catalog items:', error);
        this.isLoading = false;
        this.cdr.detectChanges();
      }
    });
  }

  refreshCatalog() {
    this.isRefreshing = true;
    this.catalogService.getCatalogItems().subscribe({
      next: items => {
        // Filter out notifications and feedback from catalog (they're handled separately)
        this.catalogItems = items.filter(item => item.type !== 'Notification' && item.type !== 'Feedback');
        this.filteredItems = this.catalogItems;
        this.isRefreshing = false;
        this.cdr.detectChanges();
      },
      error: error => {
        console.error('Error refreshing catalog items:', error);
        this.isRefreshing = false;
        this.cdr.detectChanges();
      }
    });
  }
  
  setupWebhookListeners() {
    // Subscribe to catalog events for real-time updates
    this.webhookSubscription = this.webhookService.getCatalogEvents().subscribe(
      (event: WebhookEvent) => {
        this.handleWebhookEvent(event);
      }
    );
    
    // Start polling as a fallback method
    this.webhookService.startPolling();
  }
  
  handleWebhookEvent(event: WebhookEvent) {
    console.log('Catalog received webhook event:', event);
    
    switch (event.event) {
      case 'catalog.created':
      case 'catalog.updated':
      case 'catalog.deleted':
      case 'catalog.shared':
      case 'catalog.unshared':
      case 'catalog.assigned':
        // Refresh the entire catalog list
        this.refreshCatalog();
        break;
      case 'system.refresh':
        // Generic refresh event
        this.refreshCatalog();
        break;
    }
  }

  loadAvailableTypes() {
    this.catalogService.getCatalogTypes().subscribe(types => {
      this.availableTypes = types;
      this.cdr.detectChanges();
    });
  }

  openAddModal() {
    this.isAddModalOpen = true;
    if (this.availableTypes.length === 0) {
      this.loadAvailableTypes();
    }
  }

  closeAddModal() {
    this.isAddModalOpen = false;
  }

  onAddTypeChange() {
    if (this.addTask.type) {
      this.catalogService.getCatalogCategories(this.addTask.type).subscribe(categories => {
        this.addAvailableCategories = categories;
        if (this.addTask.category && !categories.includes(this.addTask.category)) {
          this.addTask.category = '';
        }
        this.cdr.detectChanges();
      });
    } else {
      this.addAvailableCategories = [];
      this.addTask.category = '';
    }
  }

  submitAddItem(event: Event) {
    event.preventDefault();

    if (!this.addTask.content.trim()) {
      alert('Please enter some content to analyze.');
      return;
    }

    if (!this.addTask.type.trim()) {
      alert('Please select a type for the content.');
      return;
    }

    if (!this.addTask.category.trim()) {
      alert('Please select a category for the content.');
      return;
    }

    this.closeAddModal();

    const catalogItem: CatalogCreate = {
      type: this.addTask.type,
      category: this.addTask.category,
      title: this.addTask.title || `AI Analysis - ${new Date().toLocaleDateString()}`,
      content: this.addTask.content,
      status: 'Draft',
      is_private: true
    };

    this.catalogService.createCatalogItem(catalogItem).subscribe({
      next: () => {
        this.addTask = {
          title: '',
          content: '',
          type: '',
          category: ''
        };
        this.addAvailableCategories = [];
        this.loadCatalogItems();
        this.cdr.detectChanges();
      },
      error: (error) => {
        console.error('Error creating catalog item:', error);
        alert('Failed to add content to catalog. Please try again.');
        this.isAddModalOpen = true;
        this.cdr.detectChanges();
      }
    });
  }

  onTypeChange() {
    if (this.selectedType) {
      this.catalogService.getCatalogCategories(this.selectedType).subscribe(categories => {
        this.availableCategories = categories;
        if (this.addTask.category && !categories.includes(this.addTask.category)) {
          this.addTask.category = '';
        }
        this.cdr.detectChanges();
      });
    } else {
      this.availableCategories = [];
      this.addTask.category = '';
    }
    this.applyFilters();
  }

  onCategoryChange() {
    this.applyFilters();
  }

  onSearchChange() {
    this.applyFilters();
  }

  applyFilters() {
    this.filteredItems = this.catalogItems.filter(item => {
      // Exclude notifications and feedback from catalog (they're handled separately)
      if (item.type === 'Notification' || item.type === 'Feedback') {
        return false;
      }
      
      // Type filter
      if (this.selectedType && item.type !== this.selectedType) {
        return false;
      }
      
      // Category filter
      if (this.selectedCategory && item.category !== this.selectedCategory) {
        return false;
      }
      
      // Search filter
      if (this.searchQuery) {
        const searchLower = this.searchQuery.toLowerCase();
        const titleMatch = item.title?.toLowerCase().includes(searchLower);
        const contentMatch = item.content?.toLowerCase().includes(searchLower);
        if (!titleMatch && !contentMatch) {
          return false;
        }
      }
      
      return true;
    });
    
    this.cdr.detectChanges();
  }

  trackByItemId(index: number, item: CatalogItem): string {
    return item.id || index.toString();
  }

  trackBySkeletonId(index: number, item: number): number {
    return index;
  }

  toggleCardFlip(itemId: string | undefined) {
    if (itemId) {
      if (this.flippedCards.has(itemId)) {
        this.flippedCards.delete(itemId);
      } else {
        this.flippedCards.add(itemId);
      }
    }
  }

  isCardFlipped(itemId: string | undefined): boolean {
    return itemId ? this.flippedCards.has(itemId) : false;
  }

  getIconForType(type: string): string {
    const map: Record<string, string> = {
      'Task': 'check-circle',
      'Note': 'message',
      'Document': 'file',
      'Meeting': 'calendar'
    };
    return map[type] || 'file';
  }

  toggleViewMode() {
    this.isFullView = !this.isFullView;
  }

  onShowDetail(item: CatalogItem) {
    if (item.id) {
      this.router.navigate(['/catalog', item.id], { state: { item } });
    }
  }

  onDeleteItem(item: CatalogItem) {
    this.itemToDelete = item;
    this.showDeleteConfirmation = true;
  }

  confirmDelete() {
    if (this.itemToDelete?.id) {
      this.catalogService.deleteCatalogItem(this.itemToDelete.id).subscribe({
        next: () => {
          // Remove the item from local arrays
          this.catalogItems = this.catalogItems.filter(i => i.id !== this.itemToDelete?.id);
          this.filteredItems = this.filteredItems.filter(i => i.id !== this.itemToDelete?.id);
          console.log('Item deleted successfully');
          
          // Refresh catalog items from server to ensure consistency
          this.loadCatalogItems();
        },
        error: (error) => {
          console.error('Error deleting item:', error);
          // Handle CORS error gracefully
          if (error.status === 0) {
            console.warn('CORS error detected. This might be a backend configuration issue.');
            // For now, just remove from local UI to provide better UX
            this.catalogItems = this.catalogItems.filter(i => i.id !== this.itemToDelete?.id);
            this.filteredItems = this.filteredItems.filter(i => i.id !== this.itemToDelete?.id);
          }
        }
      });
    }
    this.showDeleteConfirmation = false;
    this.itemToDelete = null;
  }

  cancelDelete() {
    this.showDeleteConfirmation = false;
    this.itemToDelete = null;
  }

  onToggleFavoriteItem(item: CatalogItem) {
    if (item.id) {
      const updatedItem = { ...item, is_favorite: !item.is_favorite };
      this.catalogService.updateCatalogItem(item.id, updatedItem).subscribe({
        next: (updated) => {
          const index = this.catalogItems.findIndex(i => i.id === item.id);
          if (index !== -1) {
            this.catalogItems[index] = updated;
          }
          const filteredIndex = this.filteredItems.findIndex(i => i.id === item.id);
          if (filteredIndex !== -1) {
            this.filteredItems[filteredIndex] = updated;
          }
          console.log('Favorite status updated');
        },
        error: (error) => {
          console.error('Error updating favorite status:', error);
        }
      });
    }
  }

  onToggleArchiveItem(item: CatalogItem) {
    if (item.id) {
      const updatedItem = { ...item, is_archived: !item.is_archived };
      this.catalogService.updateCatalogItem(item.id, updatedItem).subscribe({
        next: (updated) => {
          const index = this.catalogItems.findIndex(i => i.id === item.id);
          if (index !== -1) {
            this.catalogItems[index] = updated;
          }
          const filteredIndex = this.filteredItems.findIndex(i => i.id === item.id);
          if (filteredIndex !== -1) {
            this.filteredItems[filteredIndex] = updated;
          }
          console.log('Archive status updated');
        },
        error: (error) => {
          console.error('Error updating archive status:', error);
        }
      });
    }
  }

  navigateToMypad() {
    this.router.navigate(['/mypad']);
  }
}
import { Routes } from '@angular/router';
import { Login } from './pages/login/login';
import { Register } from './pages/register/register';
import { Dashboard } from './pages/dashboard/dashboard';
import { AuthGuard } from './services/auth.guard';
import { Catalog } from './pages/catalog/catalog';
import { CatalogDetailPage } from './pages/catalog-detail/catalog-detail';
import { ChatComponent } from './pages/chat/chat';
import { Notifications } from './pages/notifications/notifications';
import { Profile } from './pages/profile/profile';
import { Mypad } from './pages/mypad/mypad';
import { Feedback } from './pages/feedback/feedback';
import { FamilyBoard } from './pages/family-board/family-board';

export const routes: Routes = [
  { path: '', redirectTo: '/login', pathMatch: 'full' },
  { path: 'login', component: Login },
  { path: 'register', component: Register },
  { path: 'dashboard', component: Dashboard, canActivate: [AuthGuard] },
  { path: 'catalog', component: Catalog, canActivate: [AuthGuard] },
  { path: 'catalog/:id', component: CatalogDetailPage, canActivate: [AuthGuard] },
  { path: 'chat', component: ChatComponent, canActivate: [AuthGuard] },
  { path: 'notifications', component: Notifications, canActivate: [AuthGuard] },
  { path: 'profile', component: Profile, canActivate: [AuthGuard] },
  { path: 'mypad', component: Mypad, canActivate: [AuthGuard] },
  { path: 'feedback', component: Feedback, canActivate: [AuthGuard] },
  { path: 'family-board', component: FamilyBoard, canActivate: [AuthGuard] },
  { path: '**', redirectTo: '/login' }
];

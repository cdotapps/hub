import { inject } from '@angular/core';
import { HttpRequest, HttpHandlerFn, HttpEvent, HttpResponse, HttpErrorResponse } from '@angular/common/http';
import { Observable } from 'rxjs';
import { tap } from 'rxjs/operators';
import { environment } from '../../environments/environment';

export const loggingInterceptor = (req: HttpRequest<unknown>, next: HttpHandlerFn): Observable<HttpEvent<unknown>> => {
  const start = Date.now();

  if (environment.debug) {
    try {
      console.debug('[HTTP] Request:', req.method, req.urlWithParams, {
        headers: req.headers.keys(),
        body: req.body
      });
    } catch (e) {
      console.debug('[HTTP] Request:', req.method, req.urlWithParams);
    }
  }

  return next(req).pipe(
    tap({
      next: (event) => {
        if (event instanceof HttpResponse && environment.debug) {
          console.debug('[HTTP] Response:', req.method, req.urlWithParams, `status=${event.status}`, `time=${Date.now() - start}ms`, event.body);
        }
      },
      error: (err) => {
        if (err instanceof HttpErrorResponse && environment.debug) {
          console.error('[HTTP] Error:', req.method, req.urlWithParams, `status=${err.status}`, err.error || err.message);
        }
      }
    })
  );
};
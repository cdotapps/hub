import { Injectable } from '@angular/core';
import { Observable, map, of } from 'rxjs';
import { CatalogService } from './catalog.service';

@Injectable({
  providedIn: 'root'
})
export class CatalogUtilityService {
  private defaultTypes = ['Task', 'Note', 'Meeting'];

  private defaultCategories: { [key: string]: string[] } = {
    'Task': ['Work', 'Personal', 'Shopping', 'Health'],
    'Note': ['Personal', 'Work', 'Ideas', 'Reminders'],
    'Meeting': ['Work', 'Personal', 'Client', 'Team'],
    'Reminder': ['Personal', 'Work', 'Health', 'Bills']
  };

  constructor(private catalogService: CatalogService) {}

  getDefaultTypes(): string[] {
    return [...this.defaultTypes];
  }
  getDefaultDashboardTypes(): string[] {
    return ['Note', 'Meeting', 'Event','Task'];
  }

  getDefaultCategories(type: string): string[] {
    return this.defaultCategories[type] || [];
  }

  getUniqueTypes(): Observable<string[]> {
    return this.catalogService.getCatalogTypes();
  }

  getUniqueCategories(type?: string): Observable<string[]> {
    return this.catalogService.getCatalogCategories(type);
  }

  getAllTypes(): Observable<string[]> {
    return this.getUniqueTypes().pipe(
      map(uniqueTypes => {
        const allTypes = new Set([...this.defaultTypes, ...uniqueTypes]);
        return Array.from(allTypes).sort();
      })
    );
  }

  getAllCategories(type: string): Observable<string[]> {
    return this.getUniqueCategories(type).pipe(
      map(uniqueCategories => {
        const defaultCats = this.getDefaultCategories(type);
        const allCategories = new Set([...defaultCats, ...uniqueCategories]);
        return Array.from(allCategories).sort();
      })
    );
  }
}
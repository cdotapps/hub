import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable, BehaviorSubject } from 'rxjs';
import { map } from 'rxjs/operators';
import { environment } from '../../environments/environment';
import { CatalogItem } from './catalog.service';

export interface Notification extends CatalogItem {
  // Additional notification-specific properties can be added here
}

@Injectable({
  providedIn: 'root'
})
export class NotificationService {
  private baseApi = `${environment.apiUrl}${environment.apiBase}`;
  private catalogApi = `${this.baseApi}/catalog`;
  
  // BehaviorSubject to track unread notification count
  private unreadCountSubject = new BehaviorSubject<number>(0);
  public unreadCount$ = this.unreadCountSubject.asObservable();
  
  // BehaviorSubject to track notifications
  private notificationsSubject = new BehaviorSubject<Notification[]>([]);
  public notifications$ = this.notificationsSubject.asObservable();

  constructor(private http: HttpClient) {}

  /**
   * Get filtered notifications for dropdown (unread + last 6 read)
   * @param userId - The user ID to fetch notifications for
   * @returns Observable array of filtered notifications
   */
  getDropdownNotifications(userId: string): Observable<Notification[]> {
    let params = new HttpParams()
      .set('skip', '0')
      .set('limit', '100')  // Get more to filter properly
      .set('type_filter', 'Notification')
      .set('owner_id', userId);

    return this.http.get<CatalogItem[]>(this.catalogApi, { params }).pipe(
      map(items => {
        const notifications = items as Notification[];
        
        // Separate unread and read notifications
        const unreadNotifications = notifications.filter(n => !n.is_read);
        const readNotifications = notifications.filter(n => n.is_read);
        
        // Sort read notifications by created_at descending and take last 6
        const lastReadNotifications = readNotifications
          .sort((a, b) => {
            const dateA = a.created_at ? new Date(a.created_at).getTime() : 0;
            const dateB = b.created_at ? new Date(b.created_at).getTime() : 0;
            return dateB - dateA; // Most recent first
          })
          .slice(0, 6);
        
        // Combine unread notifications with last 6 read notifications
        const filteredNotifications = [...unreadNotifications, ...lastReadNotifications];
        
        // Update the notifications subject
        this.notificationsSubject.next(filteredNotifications);
        // Update the unread count
        this.updateUnreadCount(notifications);
        
        return filteredNotifications;
      })
    );
  }

  /**
   * Get all notifications for the notifications page
   * @param userId - The user ID to fetch notifications for
   * @param skip - Number of items to skip (for pagination)
   * @param limit - Maximum number of items to return
   * @param filter - Optional filter ('all', 'unread', 'read')
   * @returns Observable array of notifications
   */
  getAllNotifications(
    userId: string, 
    skip: number = 0, 
    limit: number = 50,
    filter: 'all' | 'unread' | 'read' = 'all'
  ): Observable<Notification[]> {
    let params = new HttpParams()
      .set('skip', skip.toString())
      .set('limit', limit.toString())
      .set('type_filter', 'Notification')
      .set('owner_id', userId);

    if (filter === 'unread') {
      params = params.set('is_read', 'false');
    } else if (filter === 'read') {
      params = params.set('is_read', 'true');
    }

    return this.http.get<CatalogItem[]>(this.catalogApi, { params }).pipe(
      map(items => {
        const notifications = items as Notification[];
        // Sort by created_at descending (newest first)
        return notifications.sort((a, b) => {
          const dateA = a.created_at ? new Date(a.created_at).getTime() : 0;
          const dateB = b.created_at ? new Date(b.created_at).getTime() : 0;
          return dateB - dateA;
        });
      })
    );
  }

  /**
   * Get unread notifications for the current user
   * @param userId - The user ID to fetch notifications for
   * @returns Observable array of unread notifications
   */
  getUnreadNotifications(userId: string): Observable<Notification[]> {
    let params = new HttpParams()
      .set('skip', '0')
      .set('limit', '100')  // Get more to ensure we catch all unread
      .set('type_filter', 'Notification')
      .set('owner_id', userId)
      .set('is_read', 'false');  // Filter for unread only

    return this.http.get<CatalogItem[]>(this.catalogApi, { params }).pipe(
      map(items => {
        const notifications = items as Notification[];
        // Update the unread count directly since these are all unread
        this.unreadCountSubject.next(notifications.length);
        return notifications;
      })
    );
  }

  /**
   * Get count of unread notifications
   * @param userId - The user ID to count notifications for
   * @returns Observable number of unread notifications
   */
  getUnreadNotificationCount(userId: string): Observable<number> {
    let params = new HttpParams()
      .set('type_filter', 'Notification')
      .set('owner_id', userId)
      .set('is_read', 'false');

    return this.http.get<number>(`${this.catalogApi}/count`, { params }).pipe(
      map(count => {
        // Update the unread count subject
        this.unreadCountSubject.next(count);
        return count;
      })
    );
  }

  /**
   * Mark a notification as read
   * @param notificationId - The ID of the notification to mark as read
   * @returns Observable of the updated notification
   */
  markAsRead(notificationId: string): Observable<Notification> {
    return this.http.put<Notification>(`${this.catalogApi}/${notificationId}`, {
      is_read: true
    }).pipe(
      map(updatedNotification => {
        // Update the unread count by decrementing it
        const currentCount = this.unreadCountSubject.value;
        this.unreadCountSubject.next(Math.max(0, currentCount - 1));
        return updatedNotification;
      })
    );
  }

  /**
   * Mark all notifications as read for a user
   * @param userId - The user ID whose notifications should be marked as read
   * @returns Observable of the bulk update operation
   */
  markAllAsRead(userId: string): Observable<any> {
    // This would need a custom endpoint on the backend for bulk updates
    // For now, we'll mark them individually
    return this.getUnreadNotifications(userId).pipe(
      map(notifications => {
        notifications.forEach(notification => {
          this.markAsRead(notification.id!).subscribe();
        });
        // Set unread count to 0 since we're marking all as read
        this.unreadCountSubject.next(0);
        return notifications.length;
      })
    );
  }

  /**
   * Delete a notification
   * @param notificationId - The ID of the notification to delete
   * @returns Observable of void
   */
  deleteNotification(notificationId: string): Observable<void> {
    return this.http.delete<void>(`${this.catalogApi}/${notificationId}`);
  }

  /**
   * Refresh notifications and update the unread count
   * @param userId - The user ID to refresh notifications for
   */
  refreshNotifications(userId: string): void {
    this.getDropdownNotifications(userId).subscribe(notifications => {
      this.notificationsSubject.next(notifications);
      this.updateUnreadCount(notifications);
    });
  }

  /**
   * Update the unread count based on notifications array
   * @param notifications - Array of notifications to count
   */
  private updateUnreadCount(notifications: Notification[]): void {
    const unreadCount = notifications.filter(n => !n.is_read).length;
    this.unreadCountSubject.next(unreadCount);
  }

  /**
   * Start polling for new notifications (optional, for real-time updates)
   * @param userId - The user ID to poll for
   * @param interval - Polling interval in milliseconds (default: 30000 = 30 seconds)
   */
  startPolling(userId: string, interval: number = 30000): void {
    setInterval(() => {
      this.getUnreadNotificationCount(userId).subscribe(count => {
        this.unreadCountSubject.next(count);
      });
    }, interval);
  }
}

import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';

export interface Family {
  id: string;
  name: string;
  description?: string | null;
  created_by: string;
  created_at: string;
}

export interface FamilyMemberInfo {
  id: string;
  user_id: string;
  email: string;
  full_name?: string | null;
  role: string;
  relation?: string | null;
  joined_at: string;
  status: string;
}

export interface FamilyInvitation {
  id: string;
  family_id: string;
  invited_by: string;
  invited_by_name?: string | null;
  family_name?: string | null;
  invited_email: string;
  invitation_code: string;
  status: string;
  expires_at: string;
  created_at: string;
}

export interface FamilyOverview {
  family: Family | null;
  members: FamilyMemberInfo[];
  invitations: FamilyInvitation[];
  my_invitations: FamilyInvitation[];
}

@Injectable({
  providedIn: 'root'
})
export class FamilyService {
  private baseApi = `${environment.apiUrl}${environment.apiBase}`;
  private familiesApi = `${this.baseApi}/families`;

  constructor(private http: HttpClient) {}

  getMyFamilyOverview(): Observable<FamilyOverview> {
    return this.http.get<FamilyOverview>(`${this.familiesApi}/me`);
  }

  createFamily(name: string, description?: string): Observable<Family> {
    return this.http.post<Family>(this.familiesApi, { name, description });
  }

  createInvitation(invitedEmail: string, familyId?: string): Observable<FamilyInvitation> {
    return this.http.post<FamilyInvitation>(`${this.familiesApi}/invitations`, {
      invited_email: invitedEmail,
      family_id: familyId
    });
  }

  joinWithCode(invitationCode: string): Observable<{ message: string; family_id: string }>{
    return this.http.post<{ message: string; family_id: string }>(`${this.familiesApi}/join`, {
      invitation_code: invitationCode
    });
  }

  acceptInvitation(invitationId: string): Observable<{ message: string; family_id: string }>{
    return this.http.post<{ message: string; family_id: string }>(
      `${this.familiesApi}/invitations/${invitationId}/accept`,
      {}
    );
  }

  deleteInvitation(invitationId: string): Observable<{ message: string }>{
    return this.http.delete<{ message: string }>(`${this.familiesApi}/invitations/${invitationId}`);
  }

  updateFamily(familyId: string, payload: { name?: string; description?: string }): Observable<Family> {
    return this.http.patch<Family>(`${this.familiesApi}/${familyId}`, payload);
  }

  updateMember(memberId: string, payload: { role?: string; relation?: string | null }): Observable<{ message: string }>{
    return this.http.patch<{ message: string }>(`${this.familiesApi}/members/${memberId}`, payload);
  }
}

import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, tap, BehaviorSubject } from 'rxjs';
import { Router } from '@angular/router';
import { environment } from '../../environments/environment';

interface LoginResponse {
  access_token: string;
  token_type: string;
}

interface RegisterResponse {
  id: number;
  email: string;
  full_name: string;
  is_active: boolean;
}

export interface User {
  id: number;
  email: string;
  full_name: string;
  is_active: boolean;
  is_superuser: boolean;
}

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  // Build URLs from environment
  private baseApi = `${environment.apiUrl}${environment.apiBase}`;
  private authApi = `${this.baseApi}/auth`;
  private usersApi = `${this.baseApi}/users`;

  private currentUserSubject = new BehaviorSubject<User | null>(null);
  public currentUser$ = this.currentUserSubject.asObservable();

  constructor(private http: HttpClient, private router: Router) {}

  login(email: string, password: string): Observable<LoginResponse> {
    return this.http.post<LoginResponse>(`${this.authApi}/login`, new URLSearchParams({
      username: email,
      password: password
    }), {
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
    }).pipe(
      tap(response => {
        localStorage.setItem('access_token', response.access_token);
        this.loadUserProfile().subscribe(() => {
          this.router.navigate(['/dashboard']);
        });
      })
    );
  }

  register(email: string, password: string, fullName: string): Observable<RegisterResponse> {
    return this.http.post<RegisterResponse>(`${this.authApi}/register`, {
      email,
      password,
      full_name: fullName
    });
  }

  logout(): void {
    localStorage.removeItem('access_token');
    this.currentUserSubject.next(null);
    this.router.navigate(['/login']);
  }

  get isAuthenticated(): boolean {
    return !!localStorage.getItem('access_token');
  }

  getToken(): string | null {
    return localStorage.getItem('access_token');
  }

  initializeAuth(): void {
    if (this.isAuthenticated) {
      this.loadUserProfile().subscribe();
    }
  }

  loadUserProfile(): Observable<User> {
    return this.http.get<User>(`${this.usersApi}/me`).pipe(
      tap(user => this.currentUserSubject.next(user))
    );
  }
}
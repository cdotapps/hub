import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, Subject, timer } from 'rxjs';
import { switchMap, takeUntil, filter } from 'rxjs/operators';
import { environment } from '../../environments/environment';

export interface WebhookEvent {
  event: string;
  data: any;
  user_id: string;
  timestamp: string;
}

export interface WebhookRegistration {
  url: string;
  events: string[];
  secret?: string;
}

@Injectable({
  providedIn: 'root'
})
export class WebhookService {
  private baseApi = `${environment.apiUrl}${environment.apiBase}`;
  private webhookApi = `${this.baseApi}/webhooks`;
  private eventSubject = new Subject<WebhookEvent>();
  private isPolling = false;
  private pollInterval = 30000; // 30 seconds
  private stopPolling = new Subject<void>();

  constructor(private http: HttpClient) {}

  // Public event stream that components can subscribe to
  public events$ = this.eventSubject.asObservable();

  // Register a webhook for the current user
  registerWebhook(webhook: WebhookRegistration): Observable<any> {
    return this.http.post(this.webhookApi, webhook);
  }

  // Get all webhooks for current user
  getWebhooks(): Observable<any[]> {
    return this.http.get<any[]>(this.webhookApi);
  }

  // Delete a webhook
  deleteWebhook(webhookId: string): Observable<void> {
    return this.http.delete<void>(`${this.webhookApi}/${webhookId}`);
  }

  // Test a webhook
  testWebhook(webhookId: string): Observable<any> {
    return this.http.post(`${this.webhookApi}/${webhookId}/test`, {});
  }

  // Get available events
  getAvailableEvents(): Observable<string[]> {
    return this.http.get<string[]>(`${this.webhookApi}/events`);
  }

  // Start polling for webhook events (fallback method)
  startPolling(): void {
    if (this.isPolling) {
      return;
    }

    this.isPolling = true;
    
    // Poll every 30 seconds for changes
    timer(0, this.pollInterval).pipe(
      switchMap(() => this.checkForChanges()),
      takeUntil(this.stopPolling)
    ).subscribe();
  }

  // Stop polling
  stopPollingForChanges(): void {
    this.isPolling = false;
    this.stopPolling.next();
  }

  // Simulate receiving webhook events (for development)
  // In production, this would be handled by a real webhook receiver
  private checkForChanges(): Observable<any> {
    // This is a placeholder - in a real implementation, you would:
    // 1. Have a server-sent events endpoint
    // 2. Use WebSockets
    // 3. Or poll for changes with timestamps
    
    // For now, we'll use a simple approach with catalog count changes
    return this.http.get(`${this.baseApi}/catalog/count`).pipe(
      switchMap(count => {
        // Emit a generic refresh event if count changed
        this.eventSubject.next({
          event: 'system.refresh',
          data: { catalogCount: count },
          user_id: 'current',
          timestamp: new Date().toISOString()
        });
        return [];
      })
    );
  }

  // Handle incoming webhook events (call this from your webhook receiver)
  handleWebhookEvent(event: WebhookEvent): void {
    // Only process events for current user
    if (event.user_id === 'current' || this.isCurrentUserEvent(event)) {
      this.eventSubject.next(event);
    }
  }

  // Check if event is relevant to current user
  private isCurrentUserEvent(event: WebhookEvent): boolean {
    // In a real implementation, you'd compare with actual user ID
    // For now, we'll process all events
    return true;
  }

  // Filter events by type
  getEventsByType(eventType: string): Observable<WebhookEvent> {
    return this.events$.pipe(
      filter(event => event.event === eventType)
    );
  }

  // Get catalog-specific events
  getCatalogEvents(): Observable<WebhookEvent> {
    return this.events$.pipe(
      filter(event => 
        event.event.startsWith('catalog.') || 
        event.event === 'system.refresh'
      )
    );
  }

  // Get agent request events
  getAgentRequestEvents(): Observable<WebhookEvent> {
    return this.events$.pipe(
      filter(event => event.event.startsWith('agent_request.'))
    );
  }

  // Setup automatic webhook registration for development
  setupDevelopmentWebhook(): Observable<any> {
    const webhookUrl = `${window.location.origin}/api/webhooks/receiver`;
    const events = [
      'catalog.created', 
      'catalog.updated', 
      'catalog.deleted', 
      'agent_request.created',
      'agent_request.updated',
      'agent_request.status_changed',
      'notification.created',
      'notification.updated'
    ];
    
    return this.registerWebhook({
      url: webhookUrl,
      events: events,
      secret: 'dev-secret'
    });
  }

  // Get notification events
  getNotificationEvents(): Observable<WebhookEvent> {
    return this.events$.pipe(
      filter(event => 
        event.event.startsWith('notification.') ||
        event.event === 'system.refresh'
      )
    );
  }

  // Get agent request status change events
  getAgentRequestStatusEvents(): Observable<WebhookEvent> {
    return this.events$.pipe(
      filter(event => 
        event.event === 'agent_request.status_changed' ||
        event.event.startsWith('agent_request.')
      )
    );
  }
}

import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable, of, forkJoin, Subject } from 'rxjs';
import { switchMap, map } from 'rxjs/operators';
import { environment } from '../../environments/environment';

export interface CatalogItem {
  id?: string;
  group_key?: string;
  type: string;
  category?: string;
  title: string;
  description?: string;
  content?: string;
  content_html?: string;
  links?: string[];
  severity?: string;
  priority?: string;
  status?: string;
  is_important?: boolean;
  is_urgent?: boolean;
  is_private?: boolean;
  is_read?: boolean;
  is_favorite?: boolean;
  is_archived?: boolean;
  tags?: string[];
  likes?: number;
  dislikes?: number;
  item_data?: any;
  ai_summary?: string;
  ai_data?: any;
  ai_responses?: any[];
  original_content?: string;
  parent_id?: string;
  assigned_to?: string[];
  start_date?: Date;
  due_date?: Date;
  end_date?: Date;
  completed_at?: Date;
  shared_with?: any[];
  progress?: number;
  agent_updated_at?: Date;
  agent_updated_by?: string;
  owner_id?: string;
  owner_email?: string;
  owner_full_name?: string;
  owner_avatar?: string;
  share_count?: number;
  view_count?: number;
  like_count?: number;
  user_permission?: 'view' | 'edit'; // Permission for current user on shared items
  points?: number;
  custom?: any;
  image_url?: string;
  created_at?: Date;
  created_by?: string;
  updated_at?: Date;
  updated_by?: string;
  deleted_at?: Date;
  deleted_by?: string;
}

export interface CatalogCreate {
  group_key?: string;
  type: string;
  category?: string;
  title: string;
  description?: string;
  content?: string;
  content_html?: string;
  links?: string[];
  severity?: string;
  priority?: string;
  status?: string;
  is_important?: boolean;
  is_urgent?: boolean;
  is_private?: boolean;
  is_read?: boolean;
  is_favorite?: boolean;
  is_archived?: boolean;
  tags?: string[];
  item_data?: any;
  ai_summary?: string;
  ai_data?: any;
  ai_responses?: any[];
  original_content?: string;
  parent_id?: string;
  assigned_to?: string[];
  start_date?: Date;
  due_date?: Date;
  end_date?: Date;
  completed_at?: Date;
  shared_with?: any[];
  progress?: number;
  points?: number;
  custom?: any;
  agent_updated_at?: Date;
  agent_updated_by?: string;
  initial_owner_id?: string;
}

export type AgentRequestType = 'Grammer' | 'Summarize' | 'Expand' | 'Minutes' | 'Notes' | 'Research';

export interface AgentRequestCreate {
  catalog_id: string;
  request_type: AgentRequestType;
  request_data?: Record<string, any>;
}

export interface CatalogUpdate {
  group_key?: string;
  type?: string;
  category?: string;
  title?: string;
  description?: string;
  content?: string;
  content_html?: string;
  links?: string[];
  severity?: string;
  priority?: string;
  status?: string;
  is_important?: boolean;
  is_urgent?: boolean;
  is_private?: boolean;
  is_read?: boolean;
  is_favorite?: boolean;
  is_archived?: boolean;
  tags?: string[];
  item_data?: any;
  ai_summary?: string;
  ai_data?: any;
  ai_responses?: any[];
  original_content?: string;
  parent_id?: string;
  assigned_to?: string[];
  start_date?: Date;
  due_date?: Date;
  end_date?: Date;
  completed_at?: Date;
  shared_with?: any[];
  progress?: number;
  points?: number;
  custom?: any;
  agent_updated_at?: Date;
  agent_updated_by?: string;
}

@Injectable({
  providedIn: 'root'
})
export class CatalogService {
  private baseApi = `${environment.apiUrl}${environment.apiBase}`;
  private catalogApi = `${this.baseApi}/catalog/`;
  private agentRequestsApi = `${this.baseApi}/agent-requests`;
  private catalogChangedSubject = new Subject<string>();
  catalogChanged$ = this.catalogChangedSubject.asObservable();

  constructor(private http: HttpClient) {}

  notifyCatalogChanged(reason: string = 'updated') {
    this.catalogChangedSubject.next(reason);
  }

  createCatalogItem(item: CatalogCreate): Observable<CatalogItem> {
    return this.http.post<CatalogItem>(this.catalogApi, item);
  }

  createAgentRequest(
    catalogId: string,
    requestType: AgentRequestType = 'Grammer',
    requestData: Record<string, any> = {}
  ): Observable<any> {
    const payload: AgentRequestCreate = {
      catalog_id: catalogId,
      request_type: requestType,
      request_data: requestData
    };

    return this.http.post<any>(this.agentRequestsApi, payload);
  }

  getCatalogItems(
    skip: number = 0,
    limit: number = 100,
    typeFilter?: string,
    statusFilter?: string,
    isArchived?: boolean
  ): Observable<CatalogItem[]> {
    let params = new HttpParams()
      .set('skip', skip.toString())
      .set('limit', limit.toString());

    if (typeFilter) {
      params = params.set('type_filter', typeFilter);
    }
    if (statusFilter) {
      params = params.set('status_filter', statusFilter);
    }
    if (isArchived !== undefined) {
      params = params.set('is_archived', isArchived.toString());
    }

    return this.http.get<CatalogItem[]>(this.catalogApi, { params }).pipe(
      map(items => {
        // Sort by created_at descending (newest first)
        return items.sort((a, b) => {
          const dateA = a.created_at ? new Date(a.created_at).getTime() : 0;
          const dateB = b.created_at ? new Date(b.created_at).getTime() : 0;
          return dateB - dateA; // Descending order (newest first)
        });
      })
    );
  }

  getCatalogItem(itemId: string): Observable<CatalogItem> {
    return this.http.get<CatalogItem>(`${this.catalogApi}${itemId}`);
  }

  updateCatalogItem(itemId: string, item: CatalogUpdate): Observable<CatalogItem> {
    return this.http.put<CatalogItem>(`${this.catalogApi}${itemId}`, item);
  }

  deleteCatalogItem(itemId: string): Observable<void> {
    return this.http.delete<void>(`${this.catalogApi}${itemId}`);
  }

  getCatalogTypes(): Observable<string[]> {
    return this.http.get<string[]>(`${this.catalogApi}types`);
  }

  getCatalogCategories(typeFilter?: string): Observable<string[]> {
    let params = new HttpParams();
    if (typeFilter) {
      params = params.set('type_filter', typeFilter);
    }
    return this.http.get<string[]>(`${this.catalogApi}categories`, { params });
  }

  getCatalogCount(typeFilter?: string, statusFilter?: string, isArchived?: boolean): Observable<number> {
    let params = new HttpParams();
    if (typeFilter) {
      params = params.set('type_filter', typeFilter);
    }
    if (statusFilter) {
      params = params.set('status_filter', statusFilter);
    }
    if (isArchived !== undefined) {
      params = params.set('is_archived', isArchived.toString());
    }
    return this.http.get<number>(`${this.catalogApi}count`, { params });
  }

  shareCatalogItem(itemId: string, sharedWith: any[]): Observable<CatalogItem> {
    return this.http.put<CatalogItem>(`${this.catalogApi}${itemId}/share`, { shared_with: sharedWith });
  }

  shareWithAllFamily(itemId: string, permission: 'view' | 'edit'): Observable<CatalogItem> {
    return this.http.put<CatalogItem>(`${this.catalogApi}${itemId}/share-all-family`, { permission });
  }

  unshareCatalogItem(itemId: string, userId: string): Observable<CatalogItem> {
    return this.http.put<CatalogItem>(`${this.catalogApi}${itemId}/unshare`, { user_id: userId });
  }

  assignCatalogItem(itemId: string, newOwnerId: string): Observable<CatalogItem> {
    return this.http.put<CatalogItem>(`${this.catalogApi}${itemId}/assign`, { new_owner_id: newOwnerId });
  }

  getTypeCounts(): Observable<{type: string, count: number}[]> {
    return this.getCatalogTypes().pipe(
      switchMap(types => {
        if (types.length === 0) {
          return of([]);
        }
        const countObservables = types.map(type => 
          this.getCatalogCount(type).pipe(
            map(count => ({ type, count }))
          )
        );
        return forkJoin(countObservables);
      })
    );
  }
}
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map, take, switchMap } from 'rxjs/operators';
import { AuthService, User } from './auth.service';
import { environment } from '../../environments/environment';

export type AgentRequestStatus = 'Pending' | 'Processing' | 'Completed' | 'Failed' | 'Cancelled';

export interface AgentRequest {
  id: string;
  catalog_id: string;
  request_type: string;
  status: AgentRequestStatus;
  request_data: any;
  response_data: any;
  error_message?: string;
  created_at: string;
  created_by?: string;
  owner_id: string;
  updated_at: string;
}

@Injectable({
  providedIn: 'root'
})
export class AgentService {
  private apiUrl = `${environment.apiUrl}${environment.apiBase}/agent-requests`;

  constructor(
    private http: HttpClient,
    private authService: AuthService
  ) {}

  /**
   * Get the count of agent requests by status for the current user
   * @param status The status to filter by (Pending, Processing, Completed, Failed, Cancelled)
   */
  getRequestsCountByStatus(status: AgentRequestStatus): Observable<number> {
    return this.http.get<{status: string, count: number}>(`${this.apiUrl}/status/${status}/count`).pipe(
      map(response => response.count || 0)
    );
  }

  /**
   * Get the count of in-progress agent requests for the current user
   */
  getInProgressRequestsCount(): Observable<number> {
    return this.getRequestsCountByStatus('Processing');
  }

  /**
   * Get agent requests by status for the current user
   * @param status The status to filter by (Pending, Processing, Completed, Failed, Cancelled)
   */
  getAgentRequestsByStatus(status: AgentRequestStatus): Observable<AgentRequest[]> {
    return this.http.get<AgentRequest[]>(`${this.apiUrl}/status/${status}`);
  }

  /**
   * Get the count of pending agent requests for the current user
   * @deprecated Use getRequestsCountByStatus('Pending') instead
   */
  getPendingRequestsCount(): Observable<number> {
    return this.getRequestsCountByStatus('Pending');
  }

  /**
   * Get agent requests, optionally filtered by status
   * @param status Optional status to filter by
   */
  getAgentRequests(status?: AgentRequestStatus): Observable<AgentRequest[]> {
    return this.authService.currentUser$.pipe(
      // Get the first emission of the current user
      take(1),
      // Switch to the HTTP request
      switchMap((currentUser: User | null) => {
        let url = this.apiUrl;
        
        // Build query parameters
        const params: {[key: string]: string} = {};
        
        if (status) {
          params['status'] = status;
        }
        
        // Get current user email from the auth service
        if (currentUser?.email) {
          params['created_by'] = currentUser.email;
        }
        
        // Convert params object to URLSearchParams
        const queryParams = new URLSearchParams(params).toString();
        if (queryParams) {
          url += `?${queryParams}`;
        }
        
        return this.http.get<AgentRequest[]>(url).pipe(
          // Ensure we always return an array, even if the response is null/undefined
          map(requests => requests || [])
        );
      })
    );
  }

  /**
   * Create a new agent request
   * @param request The agent request data
   */
  createAgentRequest(request: {
    request_type: string;
    request_data: any;
    catalog_id: string;
  }): Observable<AgentRequest> {
    return this.http.post<AgentRequest>(this.apiUrl, request);
  }
}

import { Pipe, PipeTransform } from '@angular/core';
import { marked } from 'marked';
import { DomSanitizer, SafeHtml } from '@angular/platform-browser';

@Pipe({
  name: 'markdown',
  standalone: true
})
export class MarkdownPipe implements PipeTransform {
  constructor(private sanitizer: DomSanitizer) {}

  transform(value: string | undefined | null): SafeHtml {
    if (!value) {
      return this.sanitizer.bypassSecurityTrustHtml('');
    }
    
    try {
      // Clean up the markdown content
      let cleanedValue = value
        // Remove excessive empty lines at the beginning
        .replace(/^\s*\n+/gm, '')
        // Replace multiple consecutive empty lines with single line break
        .replace(/\n{3,}/g, '\n\n')
        // Remove trailing whitespace
        .trim();
      
      // Configure marked options for better rendering
      marked.setOptions({
        breaks: true, // Convert line breaks to <br>
        gfm: true, // GitHub Flavored Markdown
      });
      
      const html = marked.parse(cleanedValue) as string;
      
      // Wrap the content in a special class to avoid conflicts
      const wrappedHtml = `<div class="catalog-markdown-content">${html}</div>`;
      
      return this.sanitizer.bypassSecurityTrustHtml(wrappedHtml);
    } catch (error) {
      console.error('Error parsing markdown:', error);
      // Return original text wrapped in the special class
      return this.sanitizer.bypassSecurityTrustHtml(
        `<div class="catalog-markdown-content">${value.replace(/\n/g, '<br>')}</div>`
      );
    }
  }
}

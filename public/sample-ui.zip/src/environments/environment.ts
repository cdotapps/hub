export const environment = {
  production: false,
  // Base URL for the backend API
  apiUrl: 'http://192.168.50.242:8000',
  // API base prefix (useful if you want to switch between versions)
  apiBase: '/api/v1',
  // Application-level defaults
  appName: 'MyPA',
  logoPath: '/mypa.png',
  // Enable debug logging in development
  debug: true,
  demousers:[{user: 'suresh@mypa.com', password: 'suresh123'},
    {user: 'nitin@mypa.com', password: 'nitin123'},
    {user: 'ganga@mypa.com', password: 'ganga123'},
    {user: 'hasini@mypa.com', password: 'hasini123'}
    ]
};